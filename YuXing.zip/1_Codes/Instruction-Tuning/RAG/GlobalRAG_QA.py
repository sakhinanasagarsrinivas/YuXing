import os
import json
import sys
import logging
import typing as t
import pandas as pd
from llama_index.llms.openai import OpenAI
from llama_index.core import SimpleDirectoryReader, VectorStoreIndex
from llama_index.core.evaluation import DatasetGenerator
from llama_index.core.node_parser import SentenceSplitter
from llama_index.core.retrievers import BaseRetriever
from llama_index.core.query_engine import RetrieverQueryEngine
from llama_index.core.schema import (
    QueryBundle,
    TextNode,
    BaseNode,
    NodeWithScore,
)
from llama_index.core.vector_stores.types import (
    VectorStoreQuery,
    VectorStoreQueryResult,
    BasePydanticVectorStore,
)
from llama_index.core.indices.query.embedding_utils import get_top_k_embeddings
from llama_index.core.settings import Settings, embed_model_from_settings_or_context, llm_from_settings_or_context
from llama_index.core.llms import LLM
from huggingface_hub import login
from datasets import Dataset

# Constants
DEFAULT_CHUNK_SIZE = 2048
DEFAULT_MAX_GROUP_SIZE = 4
DEFAULT_SMALL_CHUNK_SIZE = 512
DEFAULT_TOP_K = 3

# Logging configuration
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))

# Define or load your LLM
os.environ['OPENAI_API_KEY'] = ''
llm = OpenAI(model="gpt-4o-mini", temperature=0.1, max_tokens=2048, top_p=1.0, frequency_penalty=0.0, presence_penalty=0.0)  # Replace with your LLM initialization

def evaluate_answer_with_context_in_prompt(model, question, context, answer):
    """
    Evaluates a generated answer by embedding the retrieved context directly into the prompt
    and instructing the reward model to evaluate the quality of the response based on the question
    and the provided context. Includes error handling for API calls.
    
    Args:
        client (OpenAI): The OpenAI client used for API calls.
        model (str): The model to be used for scoring the response.
        question (str): The original question.
        context (str): The retrieved context relevant to the question.
        response_content (str): The generated response content.

    Returns:
        dict: A dictionary containing the response content, scores, and context, or None if an error occurs.
    """
    
    # Combine the context with the question and add an instruction to the prompt
    question_with_context = (
        f"Context: {context}\n\n"
        f"Question: {question}\n\n"
        "Instruction: Assess the response based on how accurately it answers the question and how well the information is grounded in the provided context."
    )

    # Create the messages payload with the combined prompt
    messages = [
        {"role": "user", "content": question_with_context},
        {"role": "assistant", "content": answer},
    ]
    try:
        # Send the combined prompt and response to the model and get the response
        response = nvidia_client.chat.completions.create(model=model, messages=messages)
        
        # Extract log probabilities from the response
        logprobs = response.choices[0].logprobs.content
        score_dict = {score.token: score.logprob for score in logprobs}
        
        # Return the response content, context, and scores
        return {"scores": score_dict}
    
    except Exception as e:
        # Error handling: Log the error and return None
        print(f"Error evaluating answer with context in prompt: {e}")
        return None

def generate_evaluation_questions(data_dir: str) -> t.List[str]:
    """
    Load documents from a specified directory, generate evaluation questions, and return them as a list.

    Args:
        data_dir (str): The directory containing the documents.

    Returns:
        List[str]: A list of generated evaluation questions.
    """
    try:
        reader = SimpleDirectoryReader(data_dir)
        documents = reader.load_data()

        data_generator = DatasetGenerator.from_documents(documents)
        eval_questions = data_generator.generate_questions_from_nodes()

        for question in eval_questions:
            print(question)

        return eval_questions

    except FileNotFoundError as fnf_error:
        logging.error(f"Directory not found: {data_dir}. Error: {fnf_error}")
        raise
    except Exception as e:
        logging.error(f"An error occurred while generating evaluation questions: {e}")
        raise


def split_doc(chunk_size: int, documents: t.List[BaseNode]) -> t.List[TextNode]:
    """
    Splits documents into smaller pieces based on the chunk size.

    Args:
        chunk_size (int): The maximum size of each document chunk.
        documents (List[BaseNode]): The list of documents to be split.

    Returns:
        List[TextNode]: A list of smaller text nodes.
    """
    text_parser = SentenceSplitter(chunk_size=chunk_size)
    return text_parser.get_nodes_from_documents(documents)


def group_docs(nodes: t.List[str], adj: t.Dict[str, t.List[str]], max_group_size: t.Optional[int] = DEFAULT_MAX_GROUP_SIZE) -> t.Set[t.FrozenSet[str]]:
    """
    Group documents based on their relationships and a maximum group size.

    Args:
        nodes (List[str]): List of document IDs.
        adj (Dict[str, List[str]]): Adjacency list representing relationships between documents.
        max_group_size (Optional[int]): Maximum number of documents in a group. Defaults to 4.

    Returns:
        Set[FrozenSet[str]]: A set of grouped document IDs.
    """
    try:
        docs = sorted(nodes, key=lambda node: len(adj[node]))
        groups = set()
        for d in docs:
            related_groups = set()
            for r in adj[d]:
                for g in groups:
                    if r in g:
                        related_groups = related_groups.union(frozenset([g]))

            gnew = {d}
            related_groupsl = sorted(related_groups, key=lambda el: len(el))
            for g in related_groupsl:
                if max_group_size is None or len(gnew) + len(g) <= max_group_size:
                    gnew = gnew.union(g)
                    if g in groups:
                        groups.remove(g)

            groups.add(frozenset(gnew))

        return groups
    except Exception as e:
        logging.error(f"Error occurred while grouping documents: {e}")
        raise


def get_grouped_docs(nodes: t.List[TextNode], max_group_size: t.Optional[int] = DEFAULT_MAX_GROUP_SIZE) -> t.List[TextNode]:
    """
    Retrieve and group documents based on relationships.

    Args:
        nodes (List[TextNode]): List of document nodes.
        max_group_size (Optional[int]): Maximum size of each group. Defaults to 4.

    Returns:
        List[TextNode]: A list of grouped text nodes.
    """
    try:
        nodes_str = [node.id_ for node in nodes]
        adj: t.Dict[str, t.List[str]] = {
            node.id_: [val.node_id for val in node.relationships.values()] for node in nodes
        }
        nodes_dict = {node.id_: node for node in nodes}

        res = group_docs(nodes_str, adj, max_group_size)

        ret_nodes = []
        for g in res:
            cur_node = TextNode()

            for node_id in g:
                cur_node.text += nodes_dict[node_id].text + "\n\n"
                cur_node.metadata.update(nodes_dict[node_id].metadata)

            ret_nodes.append(cur_node)

        return ret_nodes

    except KeyError as ke:
        logging.error(f"Key error during document grouping: {ke}")
        raise
    except Exception as e:
        logging.error(f"An error occurred while grouping documents: {e}")
        raise


def query(query: VectorStoreQuery, embeddings: t.Dict[str, t.List[float]]) -> VectorStoreQueryResult:
    """
    Query the vector store and retrieve the most similar embeddings.

    Args:
        query (VectorStoreQuery): The query object containing the query embedding.
        embeddings (Dict[str, List[float]]): A dictionary of embeddings keyed by node IDs.

    Returns:
        VectorStoreQueryResult: The result containing similarities and node IDs.
    """
    try:
        query_embedding = query.query_embedding

        emb_list: t.List[t.List[float]] = []
        node_ids: t.List[str] = []

        for id_, emb in embeddings.items():
            node_ids.append(id_)
            emb_list.append(emb)

        top_similarities, top_ids = get_top_k_embeddings(
            query_embedding,
            embeddings=emb_list,
            embedding_ids=node_ids,
        )

        return VectorStoreQueryResult(similarities=top_similarities, ids=top_ids)

    except Exception as e:
        logging.error(f"An error occurred while querying the vector store: {e}")
        raise


class LongRAGRetriever(BaseRetriever):
    """Long RAG Retriever class responsible for retrieving relevant nodes from grouped documents."""

    def __init__(self, grouped_nodes: t.List[TextNode], small_toks: t.List[TextNode], vector_store: BasePydanticVectorStore, similarity_top_k: int = DEFAULT_TOP_K) -> None:
        """
        Initialize the Long RAG Retriever with grouped nodes and a vector store.

        Args:
            grouped_nodes (List[TextNode]): Grouped text nodes.
            small_toks (List[TextNode]): Smaller text nodes for retrieval.
            vector_store (BasePydanticVectorStore): The vector store instance.
            similarity_top_k (int): Number of top similar nodes to retrieve.
        """
        self._grouped_nodes = grouped_nodes
        self._grouped_nodes_dict = {node.id_: node for node in grouped_nodes}
        self._small_toks = small_toks
        self._small_toks_dict = {node.id_: node for node in self._small_toks}
        self._similarity_top_k = similarity_top_k
        self._vec_store = vector_store
        self._embed_model = embed_model_from_settings_or_context(Settings, None)

    def _retrieve(self, query_bundle: QueryBundle) -> t.List[NodeWithScore]:
        """
        Retrieve relevant nodes based on the query.

        Args:
            query_bundle (QueryBundle): The query bundle containing the query string.

        Returns:
            List[NodeWithScore]: A list of nodes with their similarity scores.
        """
        try:
            query_embedding = self._embed_model.get_query_embedding(query_bundle.query_str)
            vector_store_query = VectorStoreQuery(query_embedding=query_embedding, similarity_top_k=500)

            query_res = self._vec_store.query(vector_store_query)

            top_parents_set: t.Set[str] = set()
            top_parents: t.List[NodeWithScore] = []
            for id_, similarity in zip(query_res.ids, query_res.similarities):
                cur_node = self._small_toks_dict[id_]
                parent_id = cur_node.ref_doc_id
                if parent_id not in top_parents_set:
                    top_parents_set.add(parent_id)

                    parent_node = self._grouped_nodes_dict[parent_id]
                    node_with_score = NodeWithScore(node=parent_node, score=similarity)
                    top_parents.append(node_with_score)

                    if len(top_parents_set) >= self._similarity_top_k:
                        break

            assert len(top_parents) == min(self._similarity_top_k, len(self._grouped_nodes))

            return top_parents

        except KeyError as ke:
            logging.error(f"Key error during retrieval: {ke}")
            raise
        except Exception as e:
            logging.error(f"An error occurred during retrieval: {e}")
            raise


class LongRAG:
    """Implements the Long RAG (Retrieval-Augmented Generation) pipeline."""

    def __init__(self, data_dir: str, llm: t.Optional[LLM] = None, chunk_size: t.Optional[int] = DEFAULT_CHUNK_SIZE, similarity_top_k: int = DEFAULT_TOP_K, small_chunk_size: int = DEFAULT_SMALL_CHUNK_SIZE, index: t.Optional[VectorStoreIndex] = None, index_kwargs: t.Optional[t.Dict[str, t.Any]] = None):
        """
        Initialize the Long RAG pipeline with necessary parameters.

        Args:
            data_dir (str): Directory containing the data.
            llm (Optional[LLM]): The LLM to be used. Defaults to None.
            chunk_size (Optional[int]): The chunk size for splitting documents. Defaults to 2048.
            similarity_top_k (int): The number of top similar nodes to retrieve. Defaults to 3.
            small_chunk_size (int): The size of smaller document chunks. Defaults to 512.
            index (Optional[VectorStoreIndex]): An optional vector store index. Defaults to None.
            index_kwargs (Optional[Dict[str, Any]]): Additional arguments for the index. Defaults to None.
        """
        self._data_dir = data_dir
        self._llm = llm or llm_from_settings_or_context(Settings, None)
        self._chunk_size = chunk_size
        self._similarity_top_k = similarity_top_k
        self._small_chunk_size = small_chunk_size

        if not index:
            docs = SimpleDirectoryReader(self._data_dir).load_data()
            if self._chunk_size is not None:
                nodes = split_doc(self._chunk_size, docs)
                grouped_nodes = get_grouped_docs(nodes)
            else:
                grouped_nodes = docs

            small_nodes = split_doc(small_chunk_size, grouped_nodes)
            index_kwargs = index_kwargs or {}
            self._index = VectorStoreIndex(small_nodes, **index_kwargs)
        else:
            self._index = index
            small_nodes = self._index.docstore.docs.values()
            grouped_nodes = get_grouped_docs(small_nodes, None)

        self._retriever = LongRAGRetriever(
            grouped_nodes=grouped_nodes,
            small_toks=small_nodes,
            similarity_top_k=self._similarity_top_k,
            vector_store=self._index.vector_store,
        )
        self._query_eng = RetrieverQueryEngine.from_args(self._retriever, llm=self._llm)

    def get_modules(self) -> t.Dict[str, t.Any]:
        """
        Retrieve the key modules used in the Long RAG pipeline.

        Returns:
            Dict[str, Any]: A dictionary containing the query engine, LLM, retriever, and index.
        """
        return {
            "query_engine": self._query_eng,
            "llm": self._llm,
            "retriever": self._retriever,
            "index": self._index,
        }

    def run(self, query: str, *args: t.Any, **kwargs: t.Any) -> t.Any:
        """
        Execute the Long RAG pipeline with a specified query.

        Args:
            query (str): The query string to execute.
            *args (Any): Additional arguments.
            **kwargs (Any): Additional keyword arguments.

        Returns:
            Any: The result of the query execution.
        """
        try:
            return self._query_eng.query(query)
        except Exception as e:
            logging.error(f"An error occurred while running the Long RAG pipeline: {e}")
            raise


def save_qna_pairs_to_json(
    questions: t.List[str],
    answers: t.List[t.Any],
    ratings: t.List[t.Dict[str, int]],
    scores: t.List[t.Dict[str, float]],  # New input for scores
    file_path: str
):
    """
    Save question, answer pairs, ratings, and scores to a JSON file.

    Args:
        questions (List[str]): A list of questions.
        answers (List[Any]): A list of answers corresponding to the questions.
        ratings (List[Dict[str, int]]): A list of ratings corresponding to the answers.
        scores (List[Dict[str, float]]): A list of scores corresponding to the answers.
        file_path (str): The file path where the JSON output will be saved.
    """
    try:
        serializable_answers = []
        for answer in answers:
            try:
                json.dumps(answer)  # Check if the answer is serializable
                serializable_answers.append(answer)
            except TypeError:
                serializable_answers.append(str(answer))

        qna_pairs = [
            {
                "question": question,
                "answer": answer,
                "rating": rating,
                "score": score  # Added score to the JSON structure
            } 
            for question, answer, rating, score in zip(questions, serializable_answers, ratings, scores)
        ]

        with open(file_path, 'w') as json_file:
            json.dump(qna_pairs, json_file, indent=4)

        logging.info(f"Question, answer pairs, ratings, and scores saved to {file_path}")
    except IOError as io_error:
        logging.error(f"Error writing to file {file_path}: {io_error}")
        raise
    except Exception as e:
        logging.error(f"An error occurred while saving Q&A pairs to JSON: {e}")
        raise


def push_dataset_to_hub(file_path: str, token: str, repo_name: str):
    """
    Push a dataset to Hugging Face Hub.

    Args:
        file_path (str): The file path to the dataset in JSON format.
        token (str): The Hugging Face Hub authentication token.
        repo_name (str): The repository name on Hugging Face Hub.

    Raises:
        Exception: If any error occurs during the process.
    """
    try:
        with open(file_path, 'r') as f:
            data = json.load(f)  # Load the entire JSON array as a list of dictionaries

        dataset = Dataset.from_list(data)

        # Log in to Hugging Face Hub
        login(token=token)

        # Push the dataset to Hugging Face Hub
        dataset.push_to_hub(repo_name)
        logging.info(f"Dataset pushed to Hugging Face Hub repository: {repo_name}")

    except IOError as io_error:
        logging.error(f"Error reading from file {file_path}: {io_error}")
        raise
    except Exception as e:
        logging.error(f"An error occurred while pushing the dataset to Hugging Face Hub: {e}")
        raise


def critique(question: str, answer: str, context: str) -> t.Dict[str, int]:
    """
    Rates the answer to a question using the NVIDIA nemotron-4-340b-instruct model, 
    based on Relevance, Accuracy, Faithfulness, and Coherence using a Likert scale.

    Args:
        question (str): The original question.
        answer (str): The generated answer that needs to be rated.
        context (str): The document context retrieved for the question.

    Returns:
        Dict[str, int]: A dictionary containing the ratings for Relevance, Accuracy, Faithfulness, and Coherence.
    """
    # Combine question, answer, and context to form the input prompt for the NVIDIA LLM
    prompt = f"""
    Question: {question}
    Answer: {answer}
    Context: {context}

    Please rate the quality of the answer based on the following criteria using a Likert scale from 1 (Strongly Disagree) to 5 (Strongly Agree):
    1. Relevance: How relevant is the answer to the question?
    2. Accuracy: How accurate is the answer in relation to the provided context?
    3. Faithfulness: How faithful is the answer to the information provided in the context?
    4. Coherence: How coherent and well-structured is the answer?

    IMPORTANT: Your response MUST strictly follow the format below. Any deviation from this format will be considered invalid. Do NOT include any additional information, explanations, or comments outside of the exact format specified:

    Relevance: [1-5]
    Accuracy: [1-5]
    Faithfulness: [1-5]
    Coherence: [1-5]

    Your response should only contain these four lines in the exact format above. No other text is permitted.
    """
    
    # Use the NVIDIA API to generate the ratings
    try:
        # LLM-As-A-Judge
        completion = nvidia_client.chat.completions.create(
            model="nvidia/nemotron-4-340b-instruct",
            messages=[{"role": "user", "content": prompt}],
            temperature=0.2,
            top_p=0.7,
            max_tokens=100
        )
        # Extract the response content
        response_content = completion.choices[0].message.content

       # Extract ratings from the response content
        ratings = {
            "Relevance": int(response_content.split("Relevance: ")[1].split("\n")[0]),
            "Accuracy": int(response_content.split("Accuracy: ")[1].split("\n")[0]),
            "Faithfulness": int(response_content.split("Faithfulness: ")[1].split("\n")[0]),
            "Coherence": int(response_content.split("Coherence: ")[1].split("\n")[0])
        }
        # Reward-As-A-Judge usage:
        result = evaluate_answer_with_context_in_prompt("nvidia/nemotron-4-340b-reward", question, context, answer)    
        rewardmodel_scores = result['scores']    

    except (IndexError, ValueError) as e:
        logging.error(f"Error extracting ratings from NVIDIA LLM response: {e}")
        ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}
    except Exception as e:
        logging.error(f"An error occurred during NVIDIA LLM completion: {e}")
        ratings = {"Relevance": None, "Accuracy": None, "Faithfulness": None, "Coherence": None}

    return ratings, rewardmodel_scores

# Extracting text from all nodes in the context
def extract_text_from_context(context):
    extracted_texts = []
    
    # Iterate through each NodeWithScore object in the context
    for node_with_score in context:
        text_node = node_with_score.node  # Access the TextNode
        extracted_texts.append(text_node.text)  # Extract and store the text
    
    return extracted_texts[0]  


from openai import OpenAI

# Initialize the NVIDIA API client
nvidia_client = OpenAI(
  base_url="https://integrate.api.nvidia.com/v1",
  api_key=""  # Replace with your actual API key
)


# Example usage
if __name__ == "__main__":
    try:
        # Initialize LongRAG with the data directory and LLM
        long_rag = LongRAG(data_dir="./data", llm=llm)
    except FileNotFoundError as fnf_error:
        logging.error(f"Data directory not found: {fnf_error}")
        sys.exit(1)  # Exit the script if critical components fail to initialize
    except Exception as e:
        logging.error(f"An error occurred during LongRAG initialization: {e}")
        sys.exit(1)

    # Assuming 'questions' is a list of generated questions
    questions = generate_evaluation_questions("./data")[:5]

    # Generate answers for each question
    answers = []
    ratings = []
    scores = []
    for question in questions:
        print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
        print(f"Question: {question}")
        answer = long_rag.run(question)  
        print(f"Answer: {answer}")
        answers.append(answer.response)
        print('@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@')
        # Retrieve relevant context (e.g., document context) for the question
        context = long_rag._retriever._retrieve(QueryBundle(question))  # Retrieve context for rating
        # Assuming `context` contains the NodeWithScore objects
        context = extract_text_from_context(context)
        
        # Rate the answer using the critique
        rating, rewardmodel_score = critique(question, answer.response, context)
        ratings.append(rating)
        scores.append(rewardmodel_score)

    # Save the question-answer pairs to a JSON file
    save_qna_pairs_to_json(questions, answers, ratings, scores, "GlobalRAFT.json")

    token = ""
    repo_name = ""
    push_dataset_to_hub("GlobalRAFT.json", token, repo_name)
