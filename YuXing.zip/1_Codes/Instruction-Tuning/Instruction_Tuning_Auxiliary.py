


from unsloth import FastLanguageModel

def load_model_and_generate_response(model_dir, question):
    """
    Loads a fine-tuned model and tokenizer from the specified directory and generates a response to a given question.

    Args:
        model_dir (str): Directory containing the saved model and tokenizer.
        question (str): The input question to generate a response for.

    Returns:
        tuple: A tuple containing the original question and the generated response.

    Raises:
        FileNotFoundError: If the model directory is not found.
        ValueError: If the model or tokenizer fails to load correctly.
        Exception: For any other errors during model loading or inference.
    """
    try:
        # Load the saved model and tokenizer
        model, tokenizer = FastLanguageModel.from_pretrained(model_dir)

        # Enable native 2x faster inference
        FastLanguageModel.for_inference(model)

        # Define the prompt template
        alpaca_prompt = """You will be provided with a question. Your task is to generate the correct response based on the question.

        ### Question:
        {}

        ### Response:
        {}"""

        # Prepare the input for inference
        inputs = tokenizer(
            [
                alpaca_prompt.format(
                    question,  # Question
                    "",  # Output - leave this blank for generation!
                )
            ], return_tensors="pt").to("cuda")

        # Generate the response
        outputs = model.generate(**inputs, max_new_tokens=64, use_cache=True)
        response = tokenizer.batch_decode(outputs, skip_special_tokens=True)[0]

        # Extract the relevant portion of the response
        response = response.split("### Response:")[-1].strip()

        return question, response

    except FileNotFoundError as e:
        print(f"Error: Model directory not found. {e}")
        raise
    except ValueError as e:
        print(f"Error: Invalid model or tokenizer configuration. {e}")
        raise
    except Exception as e:
        print(f"An error occurred during model loading or inference: {e}")
        raise

# Example usage
if __name__ == "__main__":
    model_dir = "lora_model"
    question = "What is the primary goal of supervised learning?"
    try:
        question, answer = load_model_and_generate_response(model_dir, question)
        print(f"Question: {question}\nAnswer: {answer}")
    except Exception as e:
        print(f"An error occurred in the workflow: {e}")



