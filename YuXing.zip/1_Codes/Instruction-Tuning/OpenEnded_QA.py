
# Requirements
# pip install -qU openai

############################################# Dataset Generation
from rich import print
import os
import openai
import json
import logging
import sys
from openai import OpenAI
from datasets import Dataset
from huggingface_hub import login, HfApi  # Import available classes and functions

# Set up logging to print logs to stdout and ensure visibility
logging.basicConfig(stream=sys.stdout, level=logging.INFO)
logging.getLogger().addHandler(logging.StreamHandler(stream=sys.stdout))


# Define an error handler decorator to handle exceptions and log errors
def error_handler(func):
    """
    A decorator to wrap functions with error handling. Catches and logs specific errors related to API rate limits, 
    timeouts, general API issues, file handling, and network-related errors. If an error occurs, the function 
    returns None and logs the error.

    Args:
        func (function): The function to be wrapped with error handling.

    Returns:
        function: The wrapped function with error handling.
    """
    def wrapper(*args, **kwargs):
        try:
            # Attempt to run the wrapped function
            return func(*args, **kwargs)
        except openai.RateLimitError as e:
            logging.error(f"Rate limit exceeded in {func.__name__}: {str(e)}. Please try again later.")
            return None
        except openai.Timeout as e:
            logging.error(f"Timeout occurred in {func.__name__}: {str(e)}. The request took too long to complete.")
            return None
        except openai.APIError as e:
            logging.error(f"API error occurred in {func.__name__}: {str(e)}. Please check the API call.")
            return None
        except openai.OpenAIError as e:
            logging.error(f"OpenAI error occurred in {func.__name__}: {str(e)}. Please check your request and API settings.")
            return None
        except FileNotFoundError as e:
            logging.error(f"File not found: {str(e)}. Please check the file path.")
            return None
        except json.JSONDecodeError as e:
            logging.error(f"JSON decode error: {str(e)}. Please check the file format.")
            return None
        except Exception as e:
            logging.error(f"Unexpected error occurred in {func.__name__}: {str(e)}")
            return None  # Return None if an exception occurs
    return wrapper


@error_handler
def dataset_generation(client, topic, n_subtopics, n_questions, threshold=3.0):
    """
    Generates a synthetic dataset based on a given topic. The dataset includes subtopics, questions, and responses 
    generated using an AI model. It also scores and filters the generated data based on a threshold.
    
    Args:
        client (OpenAI): The OpenAI client used for API calls.
        topic (str): The main topic for which subtopics and questions will be generated.
        n_subtopics (int): The number of subtopics to generate.
        n_questions (int): The number of questions to generate for each subtopic.
        threshold (float): The minimum score threshold for filtering responses.

    Returns:
        None
    """
    # 1. Subtopics Generation
    TOPIC_GENERATION_PROMPT_TEMPLATE = """\
    You must generate exactly {n_subtopics} subtopics related to the given topic. No more, no less.

    The topic is: {topic}

    The list must contain exactly {n_subtopics} subtopics. Each subtopic should be separated by a comma. There should be no numbers, no descriptions, and no additional text other than the subtopics themselves.

    Do not include any subtopics other than the {n_subtopics} requested. Failure to generate exactly {n_subtopics} subtopics will be considered incorrect.
    """
    
    @error_handler
    def generate_subtopics(client, topic, n_subtopics):
        """
        Generates a list of subtopics related to a given topic using the OpenAI API.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            topic (str): The main topic for which subtopics will be generated.
            n_subtopics (int): The number of subtopics to generate.

        Returns:
            response (dict): The API response containing the generated subtopics, or None if an error occurs.
        """
        prompt = TOPIC_GENERATION_PROMPT_TEMPLATE.format(topic=topic, n_subtopics=n_subtopics)
        response = client.chat.completions.create(
            model="meta/llama-3.1-405b-instruct",
            messages=[
                {"role": "user",
                 "content": prompt}
            ],
            temperature=0.2,  # Lower temperature for more deterministic output
            top_p=0.7,
            max_tokens=4096,  # Limit the number of tokens in the response
        )
        return response  # Return the API response

    responses = generate_subtopics(client, topic=topic, n_subtopics=n_subtopics)
    if not responses:
        logging.error("Failed to generate subtopics.")
        return

    subtopics_str = responses.choices[0].message.content
    subtopic_list = subtopics_str.split(',')

    # 2. Questions Generation
    QUESTION_PROMPT_TEMPLATE = """\
    You must generate exactly {n_questions} questions that are strictly and directly related to the specific subtopic provided. No tangential, broad, or off-topic questions are allowed.

    The subtopic is: {sub_topic}

    Your response must consist of precisely {n_questions} questions, each directly pertaining to the subtopic, separated by a newline character, with absolutely no additional text, numbering, explanations, or any other characters.

    Deviation from the subtopic or any failure to generate exactly {n_questions} questions as instructed will result in the output being considered invalid.
    """
    
    @error_handler
    def generate_questions(client, sub_topic, n_questions):
        """
        Generates a list of questions related to a given subtopic using the OpenAI API.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            sub_topic (str): The specific subtopic for which questions will be generated.
            n_questions (int): The number of questions to generate.

        Returns:
            str: The generated questions, or None if an error occurs.
        """
        prompt = QUESTION_PROMPT_TEMPLATE.format(sub_topic=sub_topic, n_questions=n_questions)
        response = client.chat.completions.create(
            model="meta/llama-3.1-405b-instruct",
            messages=[
                {"role": "user",
                 "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content if response else None

    @error_handler
    def question_generator(client, subtopic_list, n_question):
        """
        Generates questions for a list of subtopics using the OpenAI API.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            subtopic_list (list): A list of subtopics for which questions will be generated.
            n_question (int): The number of questions to generate for each subtopic.

        Returns:
            list: A list of generated questions, or an empty list if an error occurs.
        """
        tasks = [generate_questions(client, subtopic, n_question) for subtopic in subtopic_list]
        if None in tasks:
            logging.error("Failed to generate questions for some subtopics.")
            return []
        return tasks

    question_list = question_generator(client, subtopic_list, n_questions)
    if not question_list:
        logging.error("No questions generated.")
        return
    
    question_list_formatted = [question.strip() for questions in question_list for question in questions.split("\n") if question]

    # 3. Responses Generation
    RESPONSE_PROMPT_TEMPLATE = """\
    Generate a single, concise, and relevant response to the given question. The response should be directly related to the question, clear, and free of any unnecessary information.

    The question is: {question}

    Provide only one response in plain text, with no additional explanations, introductions, or concluding remarks.
    """
    
    @error_handler
    def generate_responses(client, question):
        """
        Generates a response to a given question using the OpenAI API.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            question (str): The question for which a response will be generated.

        Returns:
            str: The generated response, or None if an error occurs.
        """
        prompt = RESPONSE_PROMPT_TEMPLATE.format(question=question)
        response = client.chat.completions.create(
            model="meta/llama-3.1-405b-instruct",
            messages=[
                {"role": "user",
                 "content": prompt}
            ],
            temperature=0.2,
            top_p=0.7,
            max_tokens=4096,
        )
        return response.choices[0].message.content if response else None

    @error_handler
    def response_generator(client, question_list):
        """
        Generates responses for a list of questions using the OpenAI API.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            question_list (list): A list of questions for which responses will be generated.

        Returns:
            list: A list of generated responses, or an empty list if an error occurs.
        """
        tasks = [generate_responses(client, question) for question in question_list]
        if None in tasks:
            logging.error("Failed to generate responses for some questions.")
            return []
        return tasks

    question_response_list = response_generator(client, question_list_formatted)
    if not question_response_list:
        logging.error("No responses generated.")
        return
    
    question_response_pair_list = [{"question": question, "response": response.strip()} for question, response in zip(question_list_formatted, question_response_list)]

    # 4. Scoring and Filtering
    @error_handler
    def get_scores_from_response(openai_response_template):
        """
        Extracts log probabilities from the response to calculate scores.
        
        Args:
            openai_response_template (dict): The API response template containing log probabilities.

        Returns:
            dict: A dictionary of tokens and their corresponding log probabilities.
        """
        logprobs = openai_response_template.choices[0].logprobs.content
        score_dict = {score.token: score.logprob for score in logprobs}
        return score_dict

    @error_handler
    def get_response_and_scores(client, model, question, response_content):
        """
        Sends a question and response pair to the API to get associated scores.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            model (str): The model to be used for scoring the response.
            question (str): The original question.
            response_content (str): The generated response content.

        Returns:
            dict: A dictionary containing the response and its scores, or None if an error occurs.
        """
        messages = [
            {"role": "user", "content": question},
            {"role": "assistant", "content": response_content},
        ]
        response = client.chat.completions.create(model=model, messages=messages)
        scores = get_scores_from_response(response)
        return {"response": response_content, "scores": scores}

    @error_handler
    def process_question_response_pairs(client, model, question_response_score_list):
        """
        Processes all question-response pairs and calculates their scores.
        
        Args:
            client (OpenAI): The OpenAI client used for API calls.
            model (str): The model to be used for scoring the responses.
            question_response_score_list (list): A list of question-response pairs to be scored.

        Returns:
            None
        """
        for question_response_pair in question_response_score_list:
            question = question_response_pair["question"]
            response_content = question_response_pair["response"]
            result = get_response_and_scores(client, model, question, response_content)
            if result:
                question_response_pair.update(result)

    process_question_response_pairs(client, "nvidia/nemotron-4-340b-reward", question_response_pair_list)

    # 5. Save the Filtered Data
    @error_handler
    def save_filtered_data(question_response_pair_list, threshold):
        """
        Saves the filtered data to a JSONL file, including only responses that meet the minimum score threshold.
        
        Args:
            question_response_pair_list (list): A list of question-response pairs with scores.
            threshold (float): The minimum score threshold for filtering responses.

        Returns:
            None
        """
        with open(f'synthetic_data_with_scores_filtered-{threshold}.json', 'w') as f:
            for item in question_response_pair_list:
                if item["scores"].get("helpfulness", 0) < threshold:
                    continue
                f.write(json.dumps(item))
                f.write('\n')

    save_filtered_data(question_response_pair_list, threshold)

    print("Synthetic dataset generated successfully.")


@error_handler
def upload_dataset_to_hub(threshold, file_path, token, repo_name):
    """
    Load data from a JSON lines file, create a dataset, log in to Hugging Face, and push the dataset to the Hub.

    Args:
        threshold (float): The threshold value to filter the dataset.
        file_path (str): The path to the JSON lines file.
        token (str): Your Hugging Face API token.
        repo_name (str): The name of the repository to push the dataset to (format: "username/repo_name").

    Returns:
        None
    """
    try:
        # Load data from JSON lines file
        with open(file_path, 'r') as f:
            data = [json.loads(line) for line in f]

        # Create a dataset from the list
        dataset = Dataset.from_list(data)

        # Log in to Hugging Face Hub
        login(token=token)

        # Push the dataset to Hugging Face Hub
        dataset.push_to_hub(repo_name)
        print(f"Dataset successfully uploaded to {repo_name} on Hugging Face Hub.")
    
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logging.error(f"Error with file handling: {str(e)}")
    except Exception as e:  # Handle general exceptions
        logging.error(f"Unexpected error during dataset upload: {str(e)}")


# Example usage of dataset generation
client = OpenAI(base_url="https://integrate.api.nvidia.com/v1", api_key="")
dataset_generation(client, topic="Machine Learning", n_subtopics=2, n_questions=5, threshold=3.0)

# Example usage of uploading dataset to Hugging Face Hub
upload_dataset_to_hub(
    threshold=3.0,
    file_path='synthetic_data_with_scores_filtered-3.0.json',
    token="",
    repo_name=""
)




