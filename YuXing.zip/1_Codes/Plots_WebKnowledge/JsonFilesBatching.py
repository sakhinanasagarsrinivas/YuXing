import os
import shutil

# Input folder containing JSON files
input_folder = '/content/jsonFolder'

# Output base folder where batched subfolders will be created
output_base_folder = '/content/jsonFolderBatched'
os.makedirs(output_base_folder, exist_ok=True)  # Ensure the output base folder exists

# Number of files per subfolder
files_per_folder = 250

# List all JSON files in the input folder
all_files = [f for f in os.listdir(input_folder) if f.endswith('.json')]

# Calculate the total number of subfolders required
num_subfolders = (len(all_files) + files_per_folder - 1) // files_per_folder

# Create subfolders and move files into them
for i in range(num_subfolders):
    # Define the name and path for the current subfolder (e.g., subfolder_1, subfolder_2, ...)
    subfolder_name = f"subfolder_{i + 1}"
    subfolder_path = os.path.join(output_base_folder, subfolder_name)
    os.makedirs(subfolder_path, exist_ok=True)  # Ensure the subfolder exists

    # Determine the range of files to move into this subfolder
    start_index = i * files_per_folder
    end_index = min(start_index + files_per_folder, len(all_files))
    files_to_move = all_files[start_index:end_index]

    # Move each file to the subfolder
    for file_name in files_to_move:
        src_path = os.path.join(input_folder, file_name)  # Source file path
        dest_path = os.path.join(subfolder_path, file_name)  # Destination file path
        shutil.move(src_path, dest_path)  # Move the file

    # Log the number of files moved
    print(f"Moved {len(files_to_move)} files to {subfolder_name}")

print("Splitting completed!")

# Path to the folder you want to compress into a ZIP file
folder_to_zip = output_base_folder  # Path to the folder to be zipped
zip_file_name = 'jsonFolderBatched.zip'  # Desired name of the ZIP file

# Create a ZIP archive of the folder
shutil.make_archive(zip_file_name.replace('.zip', ''), 'zip', folder_to_zip)

# Download the ZIP file to the local machine
files.download(zip_file_name)


