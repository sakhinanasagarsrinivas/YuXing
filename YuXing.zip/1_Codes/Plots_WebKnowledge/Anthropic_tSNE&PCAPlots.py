# !pip install openai==0.28 PyMuPDF kneed

import os
import fitz
import time
import openai
import numpy as np
from kneed import KneeLocator
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

OPENAI_API_KEY = userdata.get("OpenAI_API_Key")
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
openai.api_key = OPENAI_API_KEY

# Set OpenAI API key for authentication
OPENAI_API_KEY = userdata.get("OpenAI_API_Key")  # Retrieve API key from user data
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY  # Set the API key in the environment variables
openai.api_key = OPENAI_API_KEY  # Set the API key for OpenAI library

# Path to the folder containing PDF files
pdf_folder = r'/content/drive/MyDrive/Project 1/FinalData/GPT_PDF'
pdf_embeddings = []  # List to store embeddings for each PDF

def get_gpt_embedding(text, max_retries=3, backoff_factor=2):
    """
    Generates the embedding for the provided text using OpenAI's text-embedding-3-small model.
    Implements retry logic and timeout handling for robustness.

    Args:
        text (str): Input text for which the embedding is generated.
        max_retries (int): Maximum number of retries for handling timeouts or errors.
        backoff_factor (int): Backoff factor for exponential retry delays.

    Returns:
        list: The embedding vector as a list.
    """
    for attempt in range(max_retries):
        try:
            # Generate embedding using OpenAI model
            response = openai.Embedding.create(
                input=text,
                model="text-embedding-3-small",
                request_timeout=60  # Set timeout to 60 seconds
            )
            return response['data'][0]['embedding']
        except openai.error.Timeout as e:
            print(f"Timeout error on attempt {attempt + 1}/{max_retries}: {e}")
            if attempt < max_retries - 1:
                time.sleep(backoff_factor ** attempt)  # Exponential backoff
            else:
                raise  # Re-raise the error if max retries are exhausted
        except openai.error.OpenAIError as e:
            print(f"OpenAI API error: {e}")
            raise

# Process each PDF file in the specified folder
for pdf_file in os.listdir(pdf_folder):
    if pdf_file.endswith('.pdf'):  # Check if the file is a PDF
        pdf_path = os.path.join(pdf_folder, pdf_file)  # Get the full path of the PDF
        text = ""  # Initialize an empty string to hold the text for the entire PDF
        with fitz.open(pdf_path) as doc:  # Open the PDF using PyMuPDF
            for page in doc:
                text += page.get_text()  # Extract and concatenate text from all pages
        embedding = get_gpt_embedding(text)  # Convert the entire PDF text to an embedding
        pdf_embeddings.append(embedding)  # Store the embedding

# Perform PCA (Principal Component Analysis) on PDF embeddings
pca = PCA(n_components=2)  # Reduce dimensionality to 2 components
pca_result = pca.fit_transform(pdf_embeddings)

# Determine perplexity dynamically based on the number of samples
n_samples = len(pdf_embeddings)  # Get the number of samples
perplexity_value = max(5, min(n_samples // 3, 50))  # Set perplexity within a reasonable range

# Perform t-SNE (t-Distributed Stochastic Neighbor Embedding) on PCA results
tsne = TSNE(n_components=2, perplexity=perplexity_value, max_iter=1000, random_state=42)
tsne_result = tsne.fit_transform(pca_result)

# Visualize PCA and t-SNE results
plt.figure(figsize=(16, 8))

# PCA scatter plot
plt.subplot(1, 2, 1)
plt.scatter(pca_result[:, 0], pca_result[:, 1], cmap='viridis')
plt.title('PCA of PDF Embeddings')

# t-SNE scatter plot
plt.subplot(1, 2, 2)
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], cmap='viridis')
plt.title('t-SNE of PDF Embeddings')

plt.show()

# Determine optimal number of clusters using the Elbow Method
max_clusters = min(10, n_samples)  # Limit the number of clusters based on sample size
sse = []  # List to store Sum of Squared Errors for each k
for k in range(1, max_clusters + 1):
    kmeans = KMeans(n_clusters=k, random_state=42)  # Perform K-means clustering
    kmeans.fit(pdf_embeddings)
    sse.append(kmeans.inertia_)  # Append the SSE for the current number of clusters

# Plot the SSE values to visualize the elbow point
plt.plot(range(1, max_clusters + 1), sse)
plt.xlabel('Number of clusters')
plt.ylabel('SSE')
plt.title('Elbow Method For Optimal k')
plt.show()

# Use the KneeLocator to determine the optimal number of clusters
kl = KneeLocator(range(1, max_clusters + 1), sse, curve="convex", direction="decreasing")
optimal_k = kl.elbow  # Get the elbow point
print(f"Optimal number of clusters: {optimal_k}")

# Visualize t-SNE results with K-means clusters
plt.figure(figsize=(12, 10))
plt.scatter(tsne_result[:, 0], tsne_result[:, 1], cmap='viridis', s=50, alpha=1)
plt.title('t-Distributed Stochastic Neighbor Embedding', fontsize=20, fontweight='bold')
plt.xlabel('t-SNE Dimension 1', fontsize=18, fontweight='bold', labelpad=20)
plt.ylabel('t-SNE Dimension 2', fontsize=18, fontweight='bold', labelpad=20)
plt.tight_layout()
plt.savefig('anthropic_tsne_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()

# Visualize PCA results with K-means clusters
plt.figure(figsize=(12, 10))
plt.scatter(pca_result[:, 0], pca_result[:, 1], cmap='viridis', s=50, alpha=1)
plt.title(f'Principal Component Analysis', fontsize=20, fontweight='bold')
plt.xlabel('Principal Component 1', fontsize=18, fontweight='bold', labelpad=20)
plt.ylabel('Principal Component 2', fontsize=18, fontweight='bold', labelpad=20)
plt.tight_layout()
plt.savefig('anthropic_pca_plot.pdf', format='pdf', bbox_inches='tight')
plt.show()



