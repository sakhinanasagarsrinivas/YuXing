# !pip install fpdf openai==0.28

import os
import re
import json
import openai
import pandas as pd
from fpdf import FPDF

# Set OpenAI API key from user-provided data
OPENAI_API_KEY = userdata.get("OpenAI_API_Key")  # Retrieve API key from user data
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY  # Set API key as an environment variable
openai.api_key = OPENAI_API_KEY  # Assign the API key to the OpenAI client

# Define paths for input and output files
csv_file_path = r'/content/drive/MyDrive/Project 1/FinalData/ChemList.csv'  # Input CSV containing chemical names
folder_path = r'/content/drive/MyDrive/Project 1/FinalData/All'  # Directory with existing data files
output_csv_path = r'/content/drive/MyDrive/Project 1/FinalData/RemChemList.csv'  # Path for remaining chemicals CSV
output_json_directory = r'/content/drive/MyDrive/Project 1/FinalData/MissingChem_data'  # Directory to save JSON files
output_pdf_directory = r'/content/drive/MyDrive/Project 1/FinalData/MissingChem_data'  # Directory to save PDF files

# Create directories for outputs if they don't exist
os.makedirs(output_json_directory, exist_ok=True)
os.makedirs(output_pdf_directory, exist_ok=True)

# Load the list of chemical names from the CSV file
chemicals_df = pd.read_csv(csv_file_path, encoding='ISO-8859-1')  # Read CSV with proper encoding
chemical_names = chemicals_df['Chemical_Names'].tolist()  # Extract the column containing chemical names

def clean_name(name):
    """
    Clean the given chemical name by:
    - Removing text within parentheses.
    - Replacing unsupported characters, e.g., '/' with '_'.
    - Stripping leading and trailing whitespace.

    Args:
        name (str): Original chemical name.

    Returns:
        str: Cleaned chemical name.
    """
    cleaned_name = re.sub(r'\s*\(.*?\)', '', name).strip()  # Remove text within parentheses
    cleaned_name = cleaned_name.replace('/', '_')  # Replace unsupported characters
    return cleaned_name

def get_final_answer(chemical_name):
    """
    Generate a detailed professional report for the given chemical name using OpenAI GPT-4.

    The report includes:
    1. Synthesis Description
    2. Process Flow Diagram (PFD)
    3. Piping and Instrumentation Diagram (P&ID) Suggestions

    Args:
        chemical_name (str): Name of the chemical.

    Returns:
        str: Generated report text.
    """
    prompt_text = f"""
    You are requested to act as a chemical engineering expert, synthesizing the specified information into a cohesive and detailed professional report on {chemical_name}.
    Focus exclusively on the designated chemical compound.
    Do not include chemical formulas of the compound in the final generated text.
    Your response should be formatted in well-structured paragraphs that maintain coherence and logical progression throughout the report.
    Avoid bullet points or numbered lists, and do not include any chemical equations and formulas. You can replace the chemical formulas with the chemical name instead.
    The formatting should be precise, with minimal gaps between section headings and their respective content to ensure a polished appearance.

    The report must encompass three distinct sections as follows:

    1. **Synthesis Description**
      - Provide a multi-step process overview of the synthesis.
      - Describe each step in detail, including reactions, reactors, operating conditions, and catalysts.
      - Outline and detail purification steps such as crystallization, filtration, and drying.
      - Include information about equipment used in these processes.
      - Discuss the by-products and waste generated during the synthesis, including their handling and treatment.
      - Describe any recycling loops and heat exchange systems that optimize energy use and minimize waste.

    2. **Process Flow Diagram (PFD)**
      - Provide a detailed textual description of a PFD, including raw material storage, synthesis steps, purification processes, and waste handling.
      - Mention potential bottlenecks and optimization opportunities.

    3. **Piping and Instrumentation Diagram (P&ID) Suggestions**
      - Outline the structure of the P&ID, including instrumentation, control systems, safety measures, and material specifications.
      - Describe the integration with control systems and provide necessary details for each section of the P&ID.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        max_tokens=8092,
        messages=[{"role": "user", "content": prompt_text}]
    )
    return response['choices'][0]['message']['content']

def format_json_and_save(chemical_name, response_text, output_json_directory):
    """
    Format the response into JSON format and save it to a file.

    Args:
        chemical_name (str): Name of the chemical.
        response_text (str): Generated response text.
        output_json_directory (str): Directory to save the JSON file.
    """
    json_data = {
        "chemical_name": chemical_name,
        "Question": f"Generate the synthesis description, Process Flow Diagram (PFD) and Piping and Instrumentation Diagram (P&ID) for {chemical_name}.",
        "Answer": response_text
    }
    json_filename = os.path.join(output_json_directory, f"{chemical_name}.json")
    with open(json_filename, 'w', encoding='utf-8') as json_file:
        json.dump(json_data, json_file, indent=4)  # Save JSON with indentation for readability
    print(f"JSON saved to {json_filename}")

def save_response_as_pdf(response_text, pdf_filename):
    """
    Save the generated response text as a PDF file.

    Args:
        response_text (str): Generated response text.
        pdf_filename (str): File path for the output PDF.
    """
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    # Split the response text into paragraphs based on double newlines
    paragraphs = response_text.split('\n\n')

    for paragraph in paragraphs:
        # Remove "####" symbols and strip leading/trailing whitespace
        clean_paragraph = paragraph.replace("####", "").strip()

        # Replace unsupported characters with safe alternatives
        clean_paragraph = (
            clean_paragraph
            .replace("—", "-")   # em dash to hyphen
            .replace("“", "'")    # left double quote to double quote
            .replace("”", "'")    # right double quote to double quote
            .replace("’", "'")    # right single quote to apostrophe
            .replace("‘", "'")    # left single quote to apostrophe
            .replace("–", "-")    # en dash to hyphen
            .replace("α", "a")    # Greek alpha to 'a'
            .replace("β", "b")    # Greek beta to 'b'
            .replace("γ", "g")    # Greek gamma to 'g'
            # Add more replacements as needed
        )

        # Add extra line before specific headings
        if clean_paragraph.startswith("1. Synthesis Description"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        elif clean_paragraph.startswith("2. Process Flow Diagram (PFD)"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        elif clean_paragraph.startswith("3. Piping and Instrumentation Diagram (P&ID) Suggestions"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        else:
            pdf.multi_cell(0, 10, clean_paragraph)

    pdf.output(pdf_filename)  # Save the PDF file
    print(f"PDF saved to {pdf_filename}")

# Process each chemical name in the list
for chemical in chemical_names:
    clean_chemical = clean_name(chemical)  # Clean the chemical name
    pdf_path = os.path.join(folder_path, f"{clean_chemical}.pdf")  # Path for PDF file
    json_path = os.path.join(folder_path, f"{clean_chemical}.json")  # Path for JSON file

    if not os.path.exists(pdf_path) or not os.path.exists(json_path):
        response_text = get_final_answer(chemical)  # Generate the report
        format_json_and_save(clean_chemical, response_text, output_json_directory)  # Save as JSON
        pdf_filename = os.path.join(output_pdf_directory, f"{clean_chemical}.pdf")
        save_response_as_pdf(response_text, pdf_filename)  # Save as PDF



