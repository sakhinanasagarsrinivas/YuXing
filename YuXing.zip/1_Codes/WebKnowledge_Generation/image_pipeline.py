import os
import time
import base64
import torch
import requests
import numpy as np
import pandas as pd
from PIL import Image
from io import BytesIO
import matplotlib.pyplot as plt
from serpapi import GoogleSearch
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage
from sklearn.metrics.pairwise import cosine_similarity
from transformers import CLIPProcessor, CLIPModel

# Load the CLIP model and processor
# Determine the device (GPU or CPU) for model loading
device = "cuda" if torch.cuda.is_available() else "cpu"

# Load the pre-trained CLIP model and transfer it to the selected device
clip_model = CLIPModel.from_pretrained("openai/clip-vit-base-patch32").to(device)

# Load the pre-trained CLIP processor for image and text preprocessing
clip_processor = CLIPProcessor.from_pretrained("openai/clip-vit-base-patch32")

def search_images(query, api_key):
    """
    Search for images related to a query using SerpAPI and return details about the images.

    This function uses the SerpAPI to perform a Google image search and extracts information
    about the top image results, including titles, links, thumbnails, and sources.

    Args:
        query (str): The search query to find relevant images.
        api_key (str): The SerpAPI key for authenticating the search.

    Returns:
        list: A list of dictionaries, each containing details about an image:
            - "title" (str): Title of the image.
            - "link" (str): Direct link to the image.
            - "thumbnail" (str): Link to the thumbnail of the image.
            - "source" (str): Source website of the image.

    Notes:
        - The function limits results to the top 3 images for efficiency.
        - If no images are found, an empty list is returned.
    """
    # Define search parameters for SerpAPI
    params = {
        "engine": "google",  # Specify Google as the search engine
        "q": query,          # Query string for the search
        "tbm": "isch",       # Specify image search (tbm = "to be matched")
        "api_key": api_key   # API key for authentication
    }

    # Perform the image search using SerpAPI
    search = GoogleSearch(params)
    results = search.get_dict()  # Get the results as a dictionary

    # Initialize a list to store image details
    images = []

    # Check if image results are available in the response
    if "images_results" in results:
        # Iterate over the first 3 image results
        for image in results["images_results"][:3]:
            # Extract and store details about the image
            images.append({
                "title": image.get("title"),         # Title of the image
                "link": image.get("link"),           # Direct link to the image
                "thumbnail": image.get("thumbnail"), # Thumbnail URL of the image
                "source": image.get("source"),       # Source website of the image
            })
            # Log the link of the image for verification
            print(f"Found image link: {image.get('link')}")
    else:
        # Log a message if no images are found
        print("No image results found.")

    # Return the list of image details
    return images

def download_image(url, folder_path, index):
    """
    Download an image from a given URL, save it to a specified folder, and display it.

    This function checks if the URL points to an image file (jpg, jpeg, or png). 
    If valid, it downloads the image, saves it to the specified folder, and displays 
    it using matplotlib.

    Args:
        url (str): The URL of the image to download.
        folder_path (str): The directory where the image will be saved.
        index (int): The index for naming the image file.

    Returns:
        None
    """
    # Check if the URL points to a valid image file type
    if not (url.endswith('.jpg') or url.endswith('.jpeg') or url.endswith('.png')):
        print(f"Skipped non-image URL: {url}")  # Log skipped URLs
        return

    try:
        # Make an HTTP GET request to download the image
        response = requests.get(url)
        response.raise_for_status()  # Raise an error for unsuccessful requests

        # Define the filename for the downloaded image
        filename = f"{folder_path}/image{index}.jpg"

        # Save the image content to the specified file
        with open(filename, 'wb') as file:
            file.write(response.content)
        print(f"Downloaded: {filename}")  # Log successful downloads

        # Display the image
        img = Image.open(BytesIO(response.content))  # Open image from content in memory
        plt.figure()  # Create a new figure
        plt.imshow(img)  # Display the image
        plt.axis('off')  # Hide axis labels
        plt.title(f"Image {index}")  # Set title for the image
        plt.show()  # Render the image
    except Exception as e:
        # Log any exceptions that occur during the download process
        print(f"Could not download {url}. Reason: {e}")

def get_image_files(folder_path):
    """
    Retrieve a list of image file paths from a specified folder.

    This function scans a folder and returns the full paths of all image files 
    (png, jpg, or jpeg) in the folder.

    Args:
        folder_path (str): The directory to scan for image files.

    Returns:
        list: A list of full file paths for all images in the folder.
    """
    # Scan the folder and filter files with valid image extensions
    return [os.path.join(folder_path, f) for f in os.listdir(folder_path)
            if f.lower().endswith(('.png', '.jpg', '.jpeg'))]

def get_clip_embedding(image_path=None, text=None):
    """
    Generate CLIP embeddings for a given image or text input.

    This function uses the pre-trained CLIP model to generate embeddings (vector representations) 
    for either an image or a text. Only one of `image_path` or `text` should be provided at a time.

    Args:
        image_path (str, optional): The file path to the image for generating embeddings. Defaults to None.
        text (str, optional): The text input for generating embeddings. Defaults to None.

    Returns:
        np.ndarray: The CLIP embedding as a NumPy array.
        None: If an error occurs while generating the embedding for an image.

    Notes:
        - The function raises an exception if both `image_path` and `text` are None.
        - The returned embedding can be used for tasks such as similarity search or classification.
    """
    if text:
        # Generate text embeddings using the CLIP processor and model
        inputs = clip_processor(text=[text], return_tensors="pt", padding=True).to(device)
        with torch.no_grad():
            embedding = clip_model.get_text_features(**inputs).cpu().numpy()
        return embedding

    elif image_path:
        try:
            # Open the image file and convert it to RGB format
            image = Image.open(image_path).convert("RGB")
            
            # Process the image and generate embeddings using the CLIP processor and model
            inputs = clip_processor(images=image, return_tensors="pt").to(device)
            with torch.no_grad():
                embedding = clip_model.get_image_features(**inputs).cpu().numpy()
            return embedding
        except Exception as e:
            # Log any errors encountered during image embedding generation
            print(f"Error generating embedding for image {image_path}: {e}")
            return None
    else:
        raise ValueError("Either 'image_path' or 'text' must be provided to generate embeddings.")

def compare_embeddings(embedding1, embedding2):
    """
    Calculate the cosine similarity between two embeddings.

    This function takes two embeddings (vector representations) and computes their 
    cosine similarity, a measure of how similar the vectors are in terms of their 
    orientation in the vector space.

    Args:
        embedding1 (np.ndarray): The first embedding vector.
        embedding2 (np.ndarray): The second embedding vector.

    Returns:
        float: The cosine similarity score between the two embeddings. 
               The value ranges from -1 (opposite) to 1 (identical).

    Notes:
        - The embeddings should have the same dimensionality.
        - Cosine similarity is commonly used for measuring semantic similarity in NLP and vision tasks.
    """
    # Reshape embeddings to ensure they are 2D for cosine similarity calculation
    embedding1 = np.array(embedding1).reshape(1, -1)
    embedding2 = np.array(embedding2).reshape(1, -1)
    
    # Calculate and return the cosine similarity score
    return cosine_similarity(embedding1, embedding2)[0][0]

def encode_image(image_path):
    """
    Encode an image into a base64 string.

    This function reads an image file from the specified path, encodes its binary content 
    into a base64 string, and returns the encoded representation. Base64 encoding is 
    commonly used for embedding image data in text-based formats such as JSON or HTML.

    Args:
        image_path (str): The file path of the image to be encoded.

    Returns:
        str: The base64-encoded string representation of the image.
    """
    # Open the image file in binary read mode
    with open(image_path, "rb") as image_file:
        # Read the image content and encode it to base64
        return base64.b64encode(image_file.read()).decode("utf-8")


def image_summarize(img_base64, prompt):
    """
    Generate a summary of an image using GPT-4o.

    This function takes a base64-encoded image and a textual prompt, passes them to a 
    GPT-4o model via a chat interface, and retrieves a detailed summary of the image 
    based on the prompt.

    Args:
        img_base64 (str): The base64-encoded string of the image to be summarized.
        prompt (str): A textual prompt to guide the summary generation.

    Returns:
        str: The summary generated by the GPT-4o model.

    Notes:
        - The function uses the `ChatOpenAI` model with specific settings (e.g., `gpt-4o-mini`).
        - Introduces a 2-second delay before invoking the chat model to manage API rate limits.
    """
    # Initialize the chat model with specified parameters
    chat = ChatOpenAI(model="gpt-4o-mini", temperature=0)

    # Introduce a delay to manage API rate limits or other timing constraints
    time.sleep(2)

    # Prepare the input payload with text and base64 image data
    msg = chat.invoke(
        [
            HumanMessage(
                content=[
                    {"type": "text", "text": prompt},  # Include the prompt as text
                    {
                        "type": "image_url",  # Specify the image content type
                        "image_url": {"url": f"data:image/jpeg;base64,{img_base64}"},  # Base64-encoded image URL
                    },
                ]
            )
        ]
    )

    # Return the content of the generated message
    return msg.content


def main(query):
    """
    Main function to search, download, process images, and generate a detailed response 
    for a given query using embeddings and GPT-4 integration.

    Args:
        query (str): The input prompt describing the chemical or synthesis process to search for.

    Workflow:
    1. Searches and downloads images related to the query using SERP API.
    2. Extracts CLIP embeddings for the query and the downloaded images.
    3. Compares embeddings to find the most similar image to the query.
    4. Encodes the best-matching image to base64 and generates a detailed description 
       using GPT-4.
    5. Saves the results, including the best image path, similarity score, and GPT-4 response, 
       to a CSV file.
    """
    folder_path = "DownloadedImages"
    os.makedirs(folder_path, exist_ok=True)  # Create the folder if it doesn't exist

    # Step 1: Search and Download all Images
    images = search_images(query, os.getenv("SERP_API_KEY"))
    print(f"Found {len(images)} images. Downloading them now...")

    for index, img in enumerate(images, start=1):
        download_image(img['thumbnail'], folder_path, index)

    # Step 2: Get CLIP embedding for the input prompt
    prompt_embedding = get_clip_embedding(text=query)

    # Step 3: Process downloaded images, get embeddings, and compare with the prompt
    image_files = get_image_files(folder_path)
    best_similarity = -1  # Initialize best similarity score
    best_image = None  # Initialize best image path

    print(f"Processing {len(image_files)} downloaded images for embedding comparison...")

    for index, image_path in enumerate(image_files, start=1):
        image_embedding = get_clip_embedding(image_path=image_path)

        if image_embedding is not None:
            similarity = compare_embeddings(prompt_embedding, image_embedding)
            print(f"Similarity for image {index} ({image_path}): {similarity}")

            if similarity > best_similarity:
                best_similarity = similarity
                best_image = image_path

    if best_image:
        print(f"Most similar image: {best_image} with similarity score: {best_similarity}")

        # Step 4: Encode the best image in base64
        img_base64 = encode_image(best_image)

        # Step 5: Create the prompt for summarizing the image
        image_prompt = f"""
        You are a chemical engineer tasked with detailing the industrial synthesis process for {query}. 
        Your description must be comprehensive and cater to the needs of engineers looking to implement 
        the process in a large-scale industrial setting. Include the following elements:

        1. **Chemical Reactions**: Describe all key chemical reactions involved in the synthesis. 
           Clearly outline the reactants, intermediates, and final products.

        2. **Reactor Types and Operating Conditions**: Identify the types of reactors utilized 
           (e.g., Continuous Stirred Tank Reactor (CSTR), Plug Flow Reactor (PFR)). Specify the operating 
           conditions for each reactor type, including temperature ranges, pressure levels, and any catalyst used.

        3. **Purification Steps**: Detail any purification methods applied to achieve the desired product purity. 
           This may include techniques like distillation, crystallization, filtration, or extraction. 
           Describe the equipment utilized in these steps and their operating conditions.

        4. **By-product Handling**: Discuss how by-products and waste streams will be managed. 
           Describe treatment processes, storage, or disposal methods to mitigate environmental impact.

        5. **Recycling and Heat Integration**: Include any recycling loops in the process and detail how 
           heat integration systems are utilized to optimize energy use, such as heat exchangers that recover 
           energy from exothermic reactions.

        ---

        **Process Flow Diagram Generation (Textual)**

        Based on the synthesis description you’ve provided, create a detailed textual Process Flow Diagram (PFD) for the synthesis of {query}. Your PFD should include:

        - **Major Equipment**: List and describe all major equipment at each step, such as reactors, heat exchangers, distillation columns, separators, pumps, and compressors.

        - **Material Flow**: Illustrate the flow of raw materials, intermediates, and final products through the process, including any recycling streams.

        - **Heat Integration**: Provide details on how heat integration is incorporated, including the application of heat exchangers to recover energy.

        - **Phase Representation**: Clearly depict the phases of substances (gas, liquid, solid) in each unit operation, indicating any relevant phase transitions.

        - **Operating Conditions**: Specify the operating conditions at key stages, including temperatures, pressures, and flow rates.

        - **Bottleneck Identification**: Identify potential bottlenecks in the process flow and suggest methods for optimizing throughput.

        Ensure that the PFD adheres to industry standards and is suited for large-scale production.

        ---

        **Piping and Instrumentation Diagram (P&ID) Suggestions**

        Create a detailed Piping and Instrumentation Diagram (P&ID) based on the provided Process Flow Diagram (PFD) for the synthesis of {query}. Your P&ID should include:

        - **Sensor Placement**: Detail where sensors (temperature, pressure, flow, and level) should be located for monitoring critical process parameters.

        - **Control Valves and Strategies**: Specify the control valves, actuators, and control loops necessary to maintain process parameters—including examples of control strategies like feedback or cascade control.

        - **Safety Instrumentation**: Identify safety instrumentation such as pressure relief valves, emergency shutdown systems, interlocks, and alarms to ensure safety compliance.

        - **Instrumentation for Optimization**: Describe instrumentation needed for process optimization, including advanced process control (APC) systems and real-time data analytics.

        - **Redundancy**: Consider redundancy and reliability in the arrangement of key sensors and control elements to enhance continuous operation.

        - **Piping Material Recommendations**: Suggest appropriate piping materials considering the compatibility, temperature, and pressure of the process streams.

        - **Control System Integration**: Recommend integration with control systems like Distributed Control Systems (DCS) or SCADA systems for centralized monitoring and control.

        Your P&ID suggestions should conform to industry best practices and standards, making it suitable for large-scale production.
        """

        # Use the image_summarize function to get the summary
        gpt4_response = image_summarize(img_base64, image_prompt)
        print(f"GPT-4 Response for the selected image: {gpt4_response}")

        # Step 6: Save the best image, similarity score, and GPT-4 response to CSV
        data = {
            "Prompt": [query],
            "Best Image Path": [best_image],
            "Similarity Score": [best_similarity],
            "Answer": [gpt4_response]
        }
        df = pd.DataFrame(data)
        output_directory = "agents_output"
        os.makedirs(output_directory, exist_ok=True)
        csv_file_path = os.path.join(output_directory, "image_response.csv")

        df.to_csv(csv_file_path, index=False)

        print(f"GPT-4 response saved to: {csv_file_path}")
    else:
        print("No valid image embeddings found.")
