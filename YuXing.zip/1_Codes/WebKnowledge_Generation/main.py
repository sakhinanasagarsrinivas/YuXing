# !pip install fpdf google-search-results langchain langchain-openai htmltabletomd langchain-chroma langchain-community langchain-experimental "unstructured[all-docs]"
# !pip install --upgrade nltk
# # install OCR dependencies for unstructured
# !sudo apt-get install tesseract-ocr
# !sudo apt-get install poppler-utils
# !pip install redis>=4.1.0

# #Starting redis server
# %%sh
# curl -fsSL https://packages.redis.io/gpg | sudo gpg --dearmor -o /usr/share/keyrings/redis-archive-keyring.gpg
# echo "deb [signed-by=/usr/share/keyrings/redis-archive-keyring.gpg] https://packages.redis.io/deb $(lsb_release -cs) main" | sudo tee /etc/apt/sources.list.d/redis.list
# sudo apt-get update  > /dev/null 2>&1
# sudo apt-get install redis-stack-server  > /dev/null 2>&1
# redis-stack-server --daemonize yes

import os
import re
import sys
import json
import shutil
import pandas as pd
from fpdf import FPDF
from langchain_openai import ChatOpenAI
from langchain_core.messages import HumanMessage

from google.colab import userdata

# Retrieve API keys stored in the user's Google Colab environment
OPENAI_API_KEY = userdata.get("OpenAI_API_Key")  # OpenAI API key for authentication and access to OpenAI services
SERP_API_KEY = userdata.get("SerpAPI_API_Key")  # SerpAPI API key for authentication and access to search services

# Set the retrieved API keys as environment variables
os.environ['OPENAI_API_KEY'] = OPENAI_API_KEY
os.environ['SERP_API_KEY'] = SERP_API_KEY

# Import main functions from specific pipelines
from image_pipeline import main as image_pipeline_main  # Entry point for the image processing pipeline
from html_pipeline import main as html_pipeline_main   # Entry point for the HTML processing pipeline
from pdf_pipeline import main as pdf_pipeline_main     # Entry point for the PDF processing pipeline

def load_answers_from_csv(directory):
    """
    Load answers from all CSV files in the given directory.

    Args:
        directory (str): Path to the directory containing CSV files.

    Returns:
        list: A list of answers extracted from the 'Answer' column of all CSV files in the directory.

    Description:
        - Iterates over all files in the specified directory.
        - Checks for files with a '.csv' extension.
        - Reads the contents of each CSV file.
        - Extracts the 'Answer' column (if it exists) and appends its values to the output list.
    """
    all_answers = []

    for filename in os.listdir(directory):
        if filename.endswith('.csv'):
            file_path = os.path.join(directory, filename)
            df = pd.read_csv(file_path)
            if 'Answer' in df.columns:
                all_answers.extend(df['Answer'].tolist())

    return all_answers

def combine_answers(answers):
    """
    Combine all answers into a single context string.

    Args:
        answers (list): A list of individual answers (strings).

    Returns:
        str: A single string containing all answers, joined by newline characters.

    Description:
        - Takes a list of answers as input.
        - Joins the answers using newline characters to create a single context string.
    """
    combined_text = "\n".join(answers)
    return combined_text

def get_final_answer(combined_text, model):
    """
    Get a final answer from ChatGPT-4o-mini using the combined context.

    Args:
        combined_text (str): The combined context string synthesized from multiple answers.
        model (object): The language model instance (e.g., ChatGPT-4o-mini) used to generate the response.

    Returns:
        str: The final generated response from the model, containing a structured professional report.

    Description:
        - Generates a prompt instructing the model to act as a chemical engineering expert.
        - The response focuses on synthesizing information into a cohesive report on a specific chemical compound.
        - The report avoids including chemical formulas, equations, bullet points, or lists and is formatted as structured paragraphs.
        - The prompt specifies three distinct sections to be included in the report:
            1. **Synthesis Description**: Detailed overview of the synthesis process, including steps, equipment, by-products, and recycling loops.
            2. **Process Flow Diagram (PFD)**: Textual description of a PFD with emphasis on materials, bottlenecks, and optimizations.
            3. **Piping and Instrumentation Diagram (P&ID) Suggestions**: Structural outline and details of P&ID components, including instrumentation and safety.

    Example Workflow:
        1. Constructs a comprehensive prompt with detailed instructions and the combined context.
        2. Sends the prompt to the model as a `HumanMessage`.
        3. Receives and returns the content of the model's response.

    Notes:
        - The prompt encourages precise and professional formatting with logical progression between sections.
        - Chemical formulas are replaced with names, and any unnecessary formatting (e.g., bullet points) is avoided.
    """
    # Construct the detailed prompt for the model
    prompt_text = f"""
    You are requested to act as a chemical engineering expert, synthesizing the specified information into a cohesive and detailed professional report.
    Focus exclusively on the designated chemical compound.
    Do not include chemical formulas of the compound in the final generated text.
    Your response should be formatted in well-structured paragraphs that maintain coherence and logical progression throughout the report.
    Avoid bullet points or numbered lists, and do not include any chemical equations and formulas. You can replace the chemical formulas with the chemical name instead.
    The formatting should be precise, with minimal gaps between section headings and their respective content to ensure a polished appearance.

    The report must encompass three distinct sections as follows:

    1. **Synthesis Description**
      - Provide a multi-step process overview of the synthesis.
      - Describe each step in detail, including reactions, reactors, operating conditions, and catalysts.
      - Outline and detail purification steps such as crystallization, filtration, and drying.
      - Include information about equipment used in these processes.
      - Discuss the by-products and waste generated during the synthesis, including their handling and treatment.
      - Describe any recycling loops and heat exchange systems that optimize energy use and minimize waste.

    2. **Process Flow Diagram (PFD)**
      - Provide a detailed textual description of a PFD, including raw material storage, synthesis steps, purification processes, and waste handling.
      - Mention potential bottlenecks and optimization opportunities.

    3. **Piping and Instrumentation Diagram (P&ID) Suggestions**
      - Outline the structure of the P&ID, including instrumentation, control systems, safety measures, and material specifications.
      - Describe the integration with control systems and provide necessary details for each section of the P&ID.

    :\n{combined_text}
    """

    # Create a message object with the constructed prompt
    message = HumanMessage(content=prompt_text)

    # Invoke the model with the generated prompt and retrieve the response
    response = model.invoke([message])
    return response.content

def remove_folder_contents(folder_path):
    """
    Remove all contents in the specified folder if it exists.

    Args:
        folder_path (str): The path to the folder whose contents are to be removed.

    Description:
        - Checks whether the specified folder exists.
        - Iterates through all files and subdirectories in the folder.
        - Deletes files directly and removes directories along with their contents.
        - Handles any errors during removal gracefully and prints an error message.
        - If the folder does not exist, prints a message indicating no action was taken.

    Notes:
        - Uses `os.remove` to delete individual files.
        - Uses `shutil.rmtree` to recursively delete directories and their contents.
        - Catches exceptions to avoid program termination in case of unexpected errors during file or directory deletion.

    Example:
        folder_path = "/path/to/folder"
        remove_folder_contents(folder_path)
    """
    # Check if the folder exists
    if os.path.exists(folder_path):
        # Iterate over all files and directories in the folder
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            try:
                # Remove file
                if os.path.isfile(file_path):
                    os.remove(file_path)
                # Remove directory and its contents
                elif os.path.isdir(file_path):
                    shutil.rmtree(file_path)
            except Exception as e:
                # Handle and print any errors during removal
                print(f"Error removing {file_path}: {e}")
    else:
        # Print message if folder does not exist
        print(f"Folder {folder_path} does not exist. Skipping removal.")

def format_json_and_save(chemical_name, response_text, output_json_directory):
    """
    Format the response into a JSON structure, add the question, and save it to a file.

    Args:
        chemical_name (str): The name of the chemical for which the synthesis and diagrams are described.
        response_text (str): The response text to be included as the answer in the JSON file.
        output_json_directory (str): The directory where the JSON file should be saved.

    Description:
        - Constructs a JSON object with the following structure:
            - `chemical_name`: The name of the chemical.
            - `Question`: A predefined question asking for synthesis, PFD, and P&ID information for the chemical.
            - `Answer`: The response text provided for the chemical.
        - Saves the JSON object to a file in the specified directory, using the chemical name as the filename.
        - The JSON file is indented for readability and uses UTF-8 encoding to support special characters.

    Notes:
        - Creates a filename in the format `<chemical_name>.json` for saving the JSON.
        - Ensures compatibility with common JSON parsers by using proper formatting.
        - Prints a confirmation message with the path of the saved file upon successful completion.

    Example:
        chemical_name = "Methanol"
        response_text = "Detailed synthesis and diagram description."
        output_json_directory = "./output/json_files"
        format_json_and_save(chemical_name, response_text, output_json_directory)
    """
    # Define the JSON structure
    json_data = {
        "chemical_name": chemical_name,
        "Question": f"Generate the synthesis description, Process Flow Diagram (PFD) and Piping and Instrumentation Diagram (P&ID) for {chemical_name}.",
        "Answer": response_text  # Placeholder for actual data
    }

    # Save to JSON in the specified directory
    json_filename = os.path.join(output_json_directory, f"{chemical_name}.json")
    with open(json_filename, 'w', encoding='utf-8') as json_file:
        json.dump(json_data, json_file, indent=4)
    print(f"JSON saved to {json_filename}")

def save_response_as_pdf(response_text, pdf_filename):
    """
    Save the given response text as a PDF file with proper formatting and headings.

    Args:
        response_text (str): The response text to be formatted and saved as a PDF.
        pdf_filename (str): The filename (including path) where the PDF should be saved.

    Description:
        - Uses the FPDF library to create a PDF document.
        - Splits the response text into paragraphs using double newlines (`\n\n`) as separators.
        - Cleans each paragraph by removing "####" symbols and extra whitespace.
        - Adds special formatting for specific headings:
            - "1. Synthesis Description"
            - "2. Process Flow Diagram (PFD)"
            - "3. Piping and Instrumentation Diagram (P&ID) Suggestions"
            - Adds extra lines before and after these headings for better readability.
        - Writes each paragraph to the PDF using the `multi_cell` method for line wrapping.
        - Saves the formatted content to the specified PDF file and prints a confirmation message.

    Notes:
        - Ensures consistent font ("Arial") and size (12) for all text in the document.
        - Adds additional spacing around key headings to improve visual structure.
        - Handles generic paragraphs and headings differently to maintain a polished layout.

    Example:
        response_text = \"\"\"
        1. Synthesis Description
        This section describes the detailed synthesis process...

        2. Process Flow Diagram (PFD)
        A textual representation of the process flow...

        3. Piping and Instrumentation Diagram (P&ID) Suggestions
        Suggestions for P&ID structure and integration...
        \"\"\"
        pdf_filename = "chemical_report.pdf"
        save_response_as_pdf(response_text, pdf_filename)
    """
    # Initialize FPDF object
    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", size=12)

    # Split the response text into paragraphs based on double newlines
    paragraphs = response_text.split('\n\n')

    for paragraph in paragraphs:
        # Remove "####" symbols and strip leading/trailing whitespace
        clean_paragraph = paragraph.replace("####", "").strip()

        # Add extra line before specific headings
        if clean_paragraph.startswith("1. Synthesis Description"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        elif clean_paragraph.startswith("2. Process Flow Diagram (PFD)"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        elif clean_paragraph.startswith("3. Piping and Instrumentation Diagram (P&ID) Suggestions"):
            pdf.cell(0, 10, '', 0, 1)  # Add empty line before heading
            pdf.multi_cell(0, 10, clean_paragraph)  # Add heading
            pdf.cell(0, 10, '', 0, 1)  # Add empty line after heading

        else:
            # Add generic paragraphs without special formatting
            pdf.multi_cell(0, 10, clean_paragraph)

    # Output the PDF to the specified file
    pdf.output(pdf_filename)
    print(f"PDF saved to {pdf_filename}")

def main():
    """
    Main function to process chemical names from a CSV file, execute data pipelines, and save results.

    Description:
        - Loads a list of chemical names from a CSV file.
        - Validates the presence of the required column in the CSV.
        - Initializes a language model (ChatOpenAI) for generating detailed responses.
        - Cleans specific folders and files before processing each chemical.
        - Executes image, HTML, and PDF pipelines for each chemical.
        - Combines and processes answers from the pipelines, generates a final response, and saves it in both PDF and JSON formats.
        - Ensures output directories are created if they do not already exist.

    Steps:
        1. Load chemical names from the specified CSV file.
        2. Verify the presence of the 'Chemical_Names' column.
        3. Initialize a ChatOpenAI model for generating responses.
        4. Define folders and files to be cleaned before each iteration.
        5. Process each chemical:
            - Run data pipelines.
            - Load and combine responses from the pipeline outputs.
            - Generate a final answer using the language model.
            - Save the answer as a PDF and a JSON file.
        6. Handle cases where no answers are found for a chemical.

    Notes:
        - The function assumes specific folder paths and file structures for pipelines and outputs.
        - All output is saved in predefined directories.

    Example:
        Call this function in a script to process chemicals and generate structured outputs.
    """

    # Load chemical names from CSV
    chemicals_df = pd.read_csv('/content/Chemicals_sample_copy_copy.csv')

    # Check if the column 'Chemical_Names' exists
    if 'Chemical_Names' not in chemicals_df.columns:
        print("Error: 'Chemical_Names' column not found in the CSV.")
        return

    # Initialize model
    model = ChatOpenAI(model="gpt-4o-mini", temperature=0.1, max_tokens=8092)

    # Paths to folders to clean
    folders_to_clean = [
        "/content/DownloadedImages",
        "/content/DownloadedPDFs",
        "/content/agents_output",
        "/content/figures",
        "/content/agents_output/image_response.csv",
        "/content/agents_output/html_response.csv",
        "/content/agents_output/pdf_response.csv"
    ]

    # Prepare a list to hold responses
    responses = []

    # Directory to store individual JSON files
    output_json_directory = "/content/GeneratedJSON"
    os.makedirs(output_json_directory, exist_ok=True)

    # Directory to store final PDF files
    reports_directory = "/content/GeneratedReports"
    os.makedirs(reports_directory, exist_ok=True)

    # Iterate over each chemical name
    for index, row in chemicals_df.iterrows():
        chemical_name = row['Chemical_Names']
        query = f"Chemical Process Instrumentation Diagram of {chemical_name}"

        # Clean folder contents before processing
        for folder in folders_to_clean:
            remove_folder_contents(folder)

        # Execute pipelines for the current chemical
        print(f"\nExecuting Image Pipeline for {chemical_name}...\n")
        image_pipeline_main(query)

        print(f"\nExecuting HTML Pipeline for {chemical_name}...\n")
        html_pipeline_main(query)

        print(f"\nExecuting PDF Pipeline for {chemical_name}...\n")
        pdf_pipeline_main(query)

        # Load answers from CSVs
        output_directory = "agents_output"
        answers = load_answers_from_csv(output_directory)

        if answers:
            # Combine answers
            combined_text = combine_answers(answers)

            # Get final answer
            final_answer = get_final_answer(combined_text, model)
            print(f"Final Answer for {chemical_name} from GPT-4o mini:", final_answer)

            # Save the final answer directly to a PDF
            pdf_filename = os.path.join(reports_directory, f"{chemical_name}.pdf")
            save_response_as_pdf(final_answer, pdf_filename)

            # Format the response for JSON
            format_json_and_save(chemical_name, final_answer, output_json_directory)

        else:
            # Handle case where no answers are found
            print(f"No answers found for {chemical_name} in the CSV.")
            responses.append("")  # Append empty string if no answers found


if __name__ == "__main__":
    main()

import shutil
from google.colab import files

def download_directory_as_zip(folder_path):
    """
    Zips the specified directory and downloads it.

    Args:
        folder_path (str): The path to the directory to zip and download.

    Description:
        - Checks if the specified folder exists.
        - Compresses the folder into a zip file using `shutil.make_archive`.
        - Downloads the zip file to the user's local machine using `google.colab.files.download`.

    Notes:
        - The zip file is created in the same location as the original folder, with the `.zip` extension added.
        - If the specified folder does not exist, an error message is printed, and the function exits.
        - This function is designed for use in Google Colab, where `files.download` is used to facilitate downloads.

    Example:
        download_directory_as_zip('/content/GeneratedReports')
        download_directory_as_zip('/content/GeneratedJSON')
    """
    # Ensure the folder path is valid
    if not os.path.exists(folder_path):
        print(f"Error: The folder '{folder_path}' does not exist.")
        return

    # Path to the zip file
    zip_file_path = folder_path + '.zip'

    # Create a zip file of the directory
    shutil.make_archive(folder_path, 'zip', folder_path)

    # Download the zip file
    files.download(zip_file_path)

# Example usage: Zipping and downloading directories
download_directory_as_zip('/content/GeneratedReports')
download_directory_as_zip('/content/GeneratedJSON')

