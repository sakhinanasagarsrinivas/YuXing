# src/models/eikf_net.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class EIKFNet(nn.Module):
    """
    EIKF-Net: Multi-Knowledge Fusion Network for Time Series Representation Learning
    """
    def __init__(self, config, adj_mx):
        super().__init__()
        self.config = config
        self.adj_mx = adj_mx
        self.num_nodes = adj_mx.shape[0]
        
        # Projection Layer (Section 3.1)
        self.projection = GLNLayer(
            input_dim=config['input_dim'],
            hidden_dim=config['hidden_dim']
        )
        
        # Spatial Learning Components (Section 3.2)
        # Hypergraph Learning Module
        self.hg_learning = HypergraphLearningModule(
            num_nodes=self.num_nodes,
            hidden_dim=config['hidden_dim'],
            num_hyperedges=config['num_hyperedges']
        )
        
        # Graph Learning Module
        self.graph_learning = GraphLearningModule(
            num_nodes=self.num_nodes,
            hidden_dim=config['hidden_dim'],
            adj_mx=adj_mx
        )
        
        # Spatial Fusion Layer
        self.spatial_fusion = SpatialFusion(config['hidden_dim'])
        
        # Temporal Learning Component (Section 3.3)
        self.temporal_inference = TemporalInference(
            hidden_dim=config['hidden_dim'],
            horizon=config['horizon']
        )
        
        # Uncertainty Estimation (Section A.11)
        self.uncertainty_estimator = UncertaintyEstimator(
            input_dim=config['hidden_dim'],
            horizon=config['horizon']
        )
        
    def forward(self, x):
        # x: [batch_size, num_nodes, time_steps, input_dim]
        batch_size = x.size(0)
        
        # Projection Layer
        x_proj = self.projection(x)  # [batch_size, num_nodes, time_steps, hidden_dim]
        
        # Spatial Learning
        # Hypergraph representation learning
        hg_repr, hg_structure = self.hg_learning(x_proj)  
        
        # Graph representation learning
        g_repr = self.graph_learning(x_proj, self.adj_mx)
        
        # Spatial Fusion through gating mechanism
        fused_repr = self.spatial_fusion(g_repr, hg_repr)
        
        # Temporal Inference
        temporal_repr = self.temporal_inference(fused_repr)
        
        # Final predictions
        predictions = self.temporal_inference.predict(temporal_repr)
        
        if self.training or self.config['estimate_uncertainty']:
            # Heteroscedastic Gaussian distribution parameters (Section A.11)
            mu, sigma = self.uncertainty_estimator(temporal_repr)
            return predictions, mu, sigma
        
        return predictions

class UncertaintyEstimator(nn.Module):
    """
    Implements uncertainty estimation for w/Unc-EIKF-Net variant.
    Based on Section A.11 of the paper using heteroscedastic Gaussian likelihood.
    """
    def __init__(self, input_dim, horizon):
        super().__init__()
        self.input_dim = input_dim
        self.horizon = horizon
        
        # Network to predict mean and variance parameters
        self.network = nn.Sequential(
            nn.Linear(input_dim, input_dim),
            nn.ReLU(),
            nn.Linear(input_dim, 2 * horizon)  # 2* for mean and variance
        )
        
    def forward(self, x):
        outputs = self.network(x)
        
        # Split outputs into mean and variance
        mu, log_var = torch.chunk(outputs, 2, dim=-1)
        
        # Ensure positive variance through exp
        sigma = torch.exp(0.5 * log_var)
        
        return mu, sigma

    def gaussian_nll_loss(self, pred, target, mu, sigma):
        """
        Compute negative Gaussian log likelihood loss as per equation 23
        """
        nll = (torch.log(sigma) + 0.5 * torch.log(2 * torch.pi) + 
               0.5 * ((target - mu) / sigma) ** 2)
        return nll.mean()

class HypergraphLearningModule(nn.Module):
    """
    Hypergraph Learning Module implementing both HgI and HgRL units.
    Based on Section 3.2.1 of the paper.
    """
    def __init__(self, num_nodes, hidden_dim, num_hyperedges):
        super().__init__()
        self.num_nodes = num_nodes
        self.hidden_dim = hidden_dim
        self.num_hyperedges = num_hyperedges
        
        # Hypergraph Structure Learning (HgI)
        self.hypernode_embeddings = nn.Parameter(torch.randn(num_nodes, hidden_dim))
        self.hyperedge_embeddings = nn.Parameter(torch.randn(num_hyperedges, hidden_dim))
        
        # Hypergraph Representation Learning (HgRL)
        self.hgat = HypergraphAttentionNetwork(hidden_dim)
        self.hgt = HypergraphTransformer(hidden_dim)
        
        # Information fusion gate
        self.fusion_gate = nn.Linear(2 * hidden_dim, hidden_dim)
        
    def forward(self, x):
        # Learn hypergraph structure through similarity metric (Eq. 4)
        incidence_matrix = self._compute_hypergraph_structure()
        
        # Compute hypernode representations through HgAT and HgT
        hgat_repr = self.hgat(x, incidence_matrix)
        hgt_repr = self.hgt(x)
        
        # Fuse representations through gating (Eq. 6)
        gate = torch.sigmoid(self.fusion_gate(torch.cat([hgat_repr, hgt_repr], dim=-1)))
        fused_repr = gate * hgat_repr + (1 - gate) * hgt_repr
        
        return fused_repr, incidence_matrix
    
    def _compute_hypergraph_structure(self):
        """
        Compute hypergraph structure through similarity metric learning.
        Implements equations 4-5 from the paper.
        """
        # Compute pairwise similarity (Eq. 4)
        node_norm = torch.norm(self.hypernode_embeddings, dim=1, keepdim=True)
        edge_norm = torch.norm(self.hyperedge_embeddings, dim=1, keepdim=True)
        sim = torch.mm(self.hypernode_embeddings, self.hyperedge_embeddings.t())
        sim = sim / (node_norm * edge_norm.t() + 1e-8)
        
        # Apply Gumbel-Softmax for differentiable sampling (Eq. 5)
        gumbel = -torch.log(-torch.log(torch.rand_like(sim) + 1e-8) + 1e-8)
        incidence_matrix = F.gumbel_softmax((sim + gumbel) / 0.05, dim=-1)
        
        return incidence_matrix