# src/inference/inference.py
import torch
import numpy as np
from ..evaluation.evaluation_metrics import EvaluationMetrics

class Inferencer:
    """Inference class for EIKF-Net model."""
    
    def __init__(self, model, device, config):
        """Initialize inferencer.
        
        Args:
            model: Trained EIKF-Net model
            device: torch device
            config (dict): Configuration dictionary
        """
        self.model = model
        self.device = device
        self.config = config
    
    def predict(self, dataloader, scaler=None, return_uncertainty=False):
        """Generate predictions for test data.
        
        Args:
            dataloader: DataLoader for test data
            scaler: Optional scaler for inverse transforming predictions
            return_uncertainty (bool): Whether to return uncertainty estimates
            
        Returns:
            tuple: (predictions, uncertainties if requested)
        """
        self.model.eval()
        predictions = []
        uncertainties = [] if return_uncertainty else None
        targets = []
        
        with torch.no_grad():
            for x, y in dataloader:
                x = x.to(self.device)
                
                if return_uncertainty and self.config['model']['estimate_uncertainty']:
                    pred, mu, sigma = self.model(x)
                    uncertainties.append(sigma.cpu().numpy())
                else:
                    pred = self.model(x)
                
                predictions.append(pred.cpu().numpy())
                targets.append(y.cpu().numpy())
        
        # Concatenate predictions
        predictions = np.concatenate(predictions, axis=0)
        targets = np.concatenate(targets, axis=0)
        
        if return_uncertainty:
            uncertainties = np.concatenate(uncertainties, axis=0)
            
            # Inverse transform if scaler provided
            if scaler is not None:
                predictions = scaler.inverse_transform(predictions)
                targets = scaler.inverse_transform(targets)
            
            return predictions, targets, uncertainties
        
        # Inverse transform if scaler provided
        if scaler is not None:
            predictions = scaler.inverse_transform(predictions)
            targets = scaler.inverse_transform(targets)
        
        return predictions, targets
    
    def evaluate(self, predictions, targets, scaler=None):
        """Evaluate predictions using multiple metrics.
        
        Args:
            predictions (np.ndarray): Model predictions
            targets (np.ndarray): Ground truth values
            scaler: Optional scaler for inverse transforming predictions
            
        Returns:
            dict: Dictionary of evaluation metrics
        """
        metrics = EvaluationMetrics(scaler)
        metrics_dict = metrics.evaluate(predictions, targets)
        metrics.print_metrics(metrics_dict)
        
        return metrics_dict