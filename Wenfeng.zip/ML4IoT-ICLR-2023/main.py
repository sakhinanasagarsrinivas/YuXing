# src/main.py
import os
import torch
import argparse
import yaml
import logging
from datetime import datetime

from data.dataloader import TrafficDataLoader
from models.eikf_net import EIKFNet
from training.training import Trainer
from inference.inference import Inferencer

def parse_args():
    parser = argparse.ArgumentParser(description='EIKF-Net for Traffic Forecasting')
    parser.add_argument('--config', type=str, default='config/default.yaml',
                      help='path to config file')
    parser.add_argument('--dataset', type=str, default='METR-LA',
                      help='dataset name')
    parser.add_argument('--mode', type=str, choices=['train', 'test'],
                      default='train', help='train or test mode')
    parser.add_argument('--gpu', type=int, default=0,
                      help='gpu device id')
    parser.add_argument('--seed', type=int, default=42,
                      help='random seed')
    return parser.parse_args()

def setup_logging(config):
    """Setup logging configuration."""
    log_dir = config['logging']['log_dir']
    os.makedirs(log_dir, exist_ok=True)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    log_file = os.path.join(log_dir, f'eikf_net_{timestamp}.log')
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file),
            logging.StreamHandler()
        ]
    )
    return logging.getLogger(__name__)

def set_random_seed(seed):
    """Set random seed for reproducibility."""
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def main():
    # Parse arguments
    args = parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Update config with command line arguments
    config['dataset'] = args.dataset
    config['gpu'] = args.gpu
    
    # Setup
    logger = setup_logging(config)
    set_random_seed(args.seed)
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    
    # Load data
    logger.info(f"Loading {args.dataset} dataset...")
    data_loader = TrafficDataLoader(config)
    train_loader, val_loader, test_loader, adj_mx, scaler = data_loader.load_dataset(
        args.dataset,
        config['data']['root_path']
    )
    
    # Initialize model
    logger.info("Initializing EIKF-Net model...")
    model = EIKFNet(config['model'], adj_mx).to(device)
    
    if args.mode == 'train':
        # Training
        logger.info("Starting training...")
        trainer = Trainer(model, config, device)
        trainer.train(train_loader, val_loader, scaler)
        
        # Load best model for testing
        model.load_state_dict(torch.load(config['training']['model_save_path']))
    else:
        # Load trained model
        logger.info("Loading trained model...")
        model.load_state_dict(torch.load(config['training']['model_save_path']))
    
    # Testing
    logger.info("Running inference on test set...")
    inferencer = Inferencer(model, device, config)
    
    if config['model']['estimate_uncertainty']:
        predictions, targets, uncertainties = inferencer.predict(
            test_loader,
            scaler=scaler,
            return_uncertainty=True
        )
        
        # Save predictions and uncertainties
        save_dir = config['inference']['save_dir']
        os.makedirs(save_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        np.save(os.path.join(save_dir, f'predictions_{timestamp}.npy'), predictions)
        np.save(os.path.join(save_dir, f'uncertainties_{timestamp}.npy'), uncertainties)
    else:
        predictions, targets = inferencer.predict(
            test_loader,
            scaler=scaler,
            return_uncertainty=False
        )
        
        # Save predictions
        save_dir = config['inference']['save_dir']
        os.makedirs(save_dir, exist_ok=True)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        np.save(os.path.join(save_dir, f'predictions_{timestamp}.npy'), predictions)
    
    # Evaluate predictions
    logger.info("Computing evaluation metrics...")
    metrics = inferencer.evaluate(predictions, targets)
    
    # Save metrics
    metrics_file = os.path.join(save_dir, f'metrics_{timestamp}.json')
    with open(metrics_file, 'w') as f:
        json.dump(metrics, f, indent=4)
    
    logger.info("Evaluation completed!")

if __name__ == '__main__':
    main()