# src/models/losses.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class EIKFNetLoss(nn.Module):
    """Combined loss function for EIKF-Net as described in the paper."""
    
    def __init__(self, alpha=0.1, beta=0.1):
        """Initialize loss function with weighting parameters.
        
        Args:
            alpha (float): Weight for uncertainty loss term
            beta (float): Weight for hypergraph regularization term
        """
        super().__init__()
        self.alpha = alpha
        self.beta = beta
        self.mse = nn.MSELoss()
        
    def forward(self, pred, target, mu=None, sigma=None, hg_structure=None):
        """Compute the combined loss.
        
        Args:
            pred (torch.Tensor): Model predictions
            target (torch.Tensor): Ground truth values
            mu (torch.Tensor, optional): Predicted mean for uncertainty
            sigma (torch.Tensor, optional): Predicted std for uncertainty
            hg_structure (torch.Tensor, optional): Hypergraph structure matrix
            
        Returns:
            torch.Tensor: Combined loss value
        """
        # Main prediction loss
        main_loss = self.mse(pred, target)
        
        total_loss = main_loss
        
        # Add uncertainty loss if provided
        if mu is not None and sigma is not None:
            uncertainty_loss = self._gaussian_nll_loss(target, mu, sigma)
            total_loss += self.alpha * uncertainty_loss
        
        # Add hypergraph regularization if provided
        if hg_structure is not None:
            hg_loss = self._hypergraph_regularization(hg_structure)
            total_loss += self.beta * hg_loss
        
        return total_loss
    
    def _gaussian_nll_loss(self, target, mu, sigma):
        """Compute negative Gaussian log likelihood loss."""
        nll = (torch.log(sigma) + 0.5 * torch.log(2 * torch.pi) + 
               0.5 * ((target - mu) / sigma) ** 2)
        return nll.mean()
    
    def _hypergraph_regularization(self, hg_structure):
        """Compute hypergraph regularization loss.
        
        Implements sparsity and connectivity constraints on the hypergraph structure.
        """
        # Sparsity constraint
        sparsity_loss = torch.mean(torch.abs(hg_structure))
        
        # Connectivity constraint (ensure each node connects to at least one hyperedge)
        connectivity_loss = torch.mean(
            torch.relu(1 - torch.sum(hg_structure, dim=1))
        )
        
        return sparsity_loss + connectivity_loss