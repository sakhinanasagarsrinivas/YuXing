# src/models/layers.py
import torch
import torch.nn as nn
import torch.nn.functional as F

class GLNLayer(nn.Module):
    """
    Gated Linear Networks layer for projection (Section 3.1).
    """
    def __init__(self, input_dim, hidden_dim):
        super().__init__()
        self.W0 = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.W1 = nn.Parameter(torch.randn(input_dim, hidden_dim))
        self.W2 = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        
    def forward(self, x):
        # Element-wise multiplication (⊗)
        gate = torch.sigmoid(torch.matmul(x, self.W0))
        transform = torch.matmul(x, self.W1)
        gated = gate * transform  # Element-wise multiplication
        return torch.matmul(gated, self.W2)

class HypergraphAttentionLayer(nn.Module):
    """
    Hypergraph Attention Layer (HgAT) for capturing higher-order relationships.
    As described in Section 3.2.1 and equations 8-10.
    """
    def __init__(self, hidden_dim, num_heads=8):
        super().__init__()
        self.hidden_dim = hidden_dim
        self.num_heads = num_heads
        self.head_dim = hidden_dim // num_heads
        
        # Weights for intra-edge attention (Eq. 8)
        self.W0 = nn.Parameter(torch.randn(num_heads, hidden_dim, self.head_dim))
        
        # Weights for inter-edge attention (Eq. 10)
        self.W1 = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.W2 = nn.Parameter(torch.randn(hidden_dim, hidden_dim))
        self.W3 = nn.Parameter(torch.randn(2 * hidden_dim))
        
    def forward(self, x, incidence_matrix):
        """
        Implements equations 8-10 from the paper for hypergraph attention.
        Args:
            x: Node features [batch_size, num_nodes, hidden_dim]
            incidence_matrix: Hypergraph structure [num_nodes, num_hyperedges]
        """
        batch_size = x.size(0)
        num_nodes = x.size(1)
        
        # Intra-edge attention (Eq. 8)
        h_j = []
        for z in range(self.num_heads):
            # Calculate α(t,ℓ,z)_j,i
            e_ji = F.relu(torch.matmul(x, self.W0[z]))  # Eq. 9
            alpha = F.softmax(e_ji, dim=1)
            
            # Weighted aggregation
            h_j_head = torch.sum(alpha.unsqueeze(-1) * x, dim=1)
            h_j.append(h_j_head)
        
        h_j = torch.cat(h_j, dim=-1)
        
        # Inter-edge attention (Eq. 10)
        # Calculate β(t,ℓ,z)_i,j
        h_i = torch.matmul(x, self.W1)
        h_j = torch.matmul(h_j, self.W2)
        
        # Concatenate and compute attention scores
        concat = torch.cat([h_i, h_j], dim=-1)
        e_ij = F.relu(torch.matmul(concat, self.W3))
        beta = F.softmax(e_ij, dim=-1)
        
        # Apply hypergraph structure constraint
        beta = beta * incidence_matrix
        
        # Final aggregation
        output = beta.unsqueeze(-1) * h_j
        
        return output

class HypergraphTransformerLayer(nn.Module):
    """
    Hypergraph Transformer Layer (HgT) as described in Section A.3.
    Implements equations 13-14.
    """
    def __init__(self, hidden_dim, num_heads=8):
        super().__init__()
        self.msa = nn.MultiheadAttention(hidden_dim, num_heads)
        self.mlp = nn.Sequential(
            nn.Linear(hidden_dim, 4 * hidden_dim),
            nn.ReLU(),
            nn.Linear(4 * hidden_dim, hidden_dim)
        )
        self.ln1 = nn.LayerNorm(hidden_dim)
        self.ln2 = nn.LayerNorm(hidden_dim)
        
    def forward(self, x):
        # Eq. 13: MSA with skip connection
        h = self.ln1(x)
        h_msa, _ = self.msa(h, h, h)
        h = h_msa + x
        
        # Eq. 14: MLP with skip connection
        h_out = self.ln2(h)
        h_out = self.mlp(h_out) + h
        
        return h_out

class TemporalInference(nn.Module):
    """
    Temporal Inference Component (Section 3.3).
    Implements MOE mechanism and 1x1 convolutions.
    """
    def __init__(self, hidden_dim):
        super().__init__()
        # Expert networks (graph and hypergraph experts)
        self.fs = nn.Linear(hidden_dim, hidden_dim)  # For graph representations
        self.fg = nn.Linear(hidden_dim, hidden_dim)  # For hypergraph representations
        
        # Gating network
        self.gate = nn.Linear(2 * hidden_dim, 1)
        
        # 1x1 convolutions for temporal modeling
        self.temporal_conv = nn.Conv1d(hidden_dim, hidden_dim, 1)
        
    def forward(self, graph_repr, hypergraph_repr):
        # Equation 7: MOE gating mechanism
        gate_input = torch.cat([graph_repr, hypergraph_repr], dim=-1)
        g = torch.sigmoid(self.gate(gate_input))
        
        # Expert outputs
        graph_out = self.fs(graph_repr)
        hypergraph_out = self.fg(hypergraph_repr)
        
        # Weighted combination
        fused = g * graph_out + (1 - g) * hypergraph_out
        
        # Temporal modeling with 1x1 convolutions
        fused = fused.transpose(1, 2)
        temporal = self.temporal_conv(fused)
        temporal = temporal.transpose(1, 2)
        
        return temporal