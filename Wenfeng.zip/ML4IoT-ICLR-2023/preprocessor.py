# src/data/preprocessor.py
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler, MinMaxScaler
import torch

class TimeSeriesPreprocessor:
    """Preprocessor for multivariate time series data."""
    
    def __init__(self, scale_method='standard'):
        """Initialize preprocessor.
        
        Args:
            scale_method (str): Scaling method ('standard' or 'minmax')
        """
        self.scale_method = scale_method
        self.scaler = StandardScaler() if scale_method == 'standard' else MinMaxScaler()
        
    def fit_transform(self, data):
        """Fit scaler and transform data.
        
        Args:
            data (np.ndarray): Shape [num_nodes, num_timestamps, num_features]
            
        Returns:
            np.ndarray: Scaled data with same shape
        """
        # Reshape for scaling
        original_shape = data.shape
        reshaped_data = data.reshape(-1, data.shape[-1])
        
        # Fit and transform
        scaled_data = self.scaler.fit_transform(reshaped_data)
        
        # Reshape back
        return scaled_data.reshape(original_shape)
    
    def transform(self, data):
        """Transform data using fitted scaler.
        
        Args:
            data (np.ndarray): Shape [num_nodes, num_timestamps, num_features]
            
        Returns:
            np.ndarray: Scaled data with same shape
        """
        original_shape = data.shape
        reshaped_data = data.reshape(-1, data.shape[-1])
        scaled_data = self.scaler.transform(reshaped_data)
        return scaled_data.reshape(original_shape)
    
    def inverse_transform(self, data):
        """Inverse transform scaled data.
        
        Args:
            data (np.ndarray): Scaled data
            
        Returns:
            np.ndarray: Original scale data
        """
        original_shape = data.shape
        reshaped_data = data.reshape(-1, data.shape[-1])
        original_data = self.scaler.inverse_transform(reshaped_data)
        return original_data.reshape(original_shape)