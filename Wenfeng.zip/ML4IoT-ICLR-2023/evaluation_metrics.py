# src/evaluation/evaluation_metrics.py
import numpy as np
import torch

class Metrics:
    """Evaluation metrics for time series forecasting."""
    
    @staticmethod
    def mae(pred, true):
        """Mean Absolute Error"""
        return np.mean(np.abs(pred - true))
    
    @staticmethod
    def mse(pred, true):
        """Mean Squared Error"""
        return np.mean((pred - true) ** 2)
    
    @staticmethod
    def rmse(pred, true):
        """Root Mean Squared Error"""
        return np.sqrt(np.mean((pred - true) ** 2))
    
    @staticmethod
    def mape(pred, true):
        """Mean Absolute Percentage Error"""
        mask = true != 0
        return np.mean(np.abs((true[mask] - pred[mask]) / true[mask])) * 100
    
    @staticmethod
    def mspe(pred, true):
        """Mean Square Percentage Error"""
        mask = true != 0
        return np.mean(np.square((true[mask] - pred[mask]) / true[mask])) * 100
    
    @staticmethod
    def corr(pred, true):
        """Correlation coefficient"""
        u = ((true - true.mean(0)) * (pred - pred.mean(0))).sum(0)
        d = np.sqrt(((true - true.mean(0)) ** 2).sum(0) * ((pred - pred.mean(0)) ** 2).sum(0))
        mask = d != 0
        return (u[mask] / d[mask]).mean()

class EvaluationMetrics:
    """Wrapper class for computing all evaluation metrics."""
    
    def __init__(self, scaler=None):
        """Initialize evaluation metrics calculator.
        
        Args:
            scaler: Optional scaler for inverse transforming predictions
        """
        self.scaler = scaler
        self.metrics = Metrics()
    
    def evaluate(self, pred, true):
        """Compute all metrics for the predictions.
        
        Args:
            pred (np.ndarray): Predictions
            true (np.ndarray): Ground truth values
            
        Returns:
            dict: Dictionary containing all computed metrics
        """
        # Inverse transform if scaler provided
        if self.scaler is not None:
            pred = self.scaler.inverse_transform(pred)
            true = self.scaler.inverse_transform(true)
        
        pred = pred.reshape(-1, pred.shape[-1])
        true = true.reshape(-1, true.shape[-1])
        
        metrics_dict = {
            'MAE': self.metrics.mae(pred, true),
            'MSE': self.metrics.mse(pred, true),
            'RMSE': self.metrics.rmse(pred, true),
            'MAPE': self.metrics.mape(pred, true),
            'MSPE': self.metrics.mspe(pred, true),
            'CORR': self.metrics.corr(pred, true)
        }
        
        return metrics_dict
    
    def print_metrics(self, metrics_dict):
        """Print metrics in a formatted way."""
        print("\nModel Performance Metrics:")
        print("=" * 50)
        for metric, value in metrics_dict.items():
            print(f"{metric:>10}: {value:.4f}")
        print("=" * 50)