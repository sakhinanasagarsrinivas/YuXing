# src/data/constants.py
DATASET_CONFIGS = {
    'PeMSD3': {
        'nodes': 358,
        'timestamps': 26208,
        'time_range': '09/2018-11/2018',
        'split_ratio': [0.6, 0.2, 0.2],  # train/val/test
        'granularity': '5mins'
    },
    'PeMSD4': {
        'nodes': 307,
        'timestamps': 16992,
        'time_range': '01/2018-02/2018',
        'split_ratio': [0.6, 0.2, 0.2],
        'granularity': '5mins'
    },
    'PeMSD7': {
        'nodes': 883,
        'timestamps': 28224,
        'time_range': '05/2017-08/2017',
        'split_ratio': [0.6, 0.2, 0.2],
        'granularity': '5mins'
    },
    'PeMSD8': {
        'nodes': 170,
        'timestamps': 17856,
        'time_range': '07/2016-08/2016',
        'split_ratio': [0.6, 0.2, 0.2],
        'granularity': '5mins'
    },
    'PeMSD7(M)': {
        'nodes': 228,
        'timestamps': 12672,
        'time_range': '05/2012-06/2012',
        'split_ratio': [0.6, 0.2, 0.2],
        'granularity': '5mins'
    },
    'METR-LA': {
        'nodes': 207,
        'timestamps': 34272,
        'time_range': '03/2012-06/2012',
        'split_ratio': [0.7, 0.1, 0.2],
        'granularity': '5mins'
    },
    'PEMS-BAY': {
        'nodes': 325,
        'timestamps': 52116,
        'time_range': '01/2017-05/2017',
        'split_ratio': [0.7, 0.1, 0.2],
        'granularity': '5mins'
    }
}