# src/data/dataloader.py
import os
import numpy as np
import pandas as pd
import h5py
import torch
from torch.utils.data import DataLoader
from .dataset import TimeSeriesDataset
from .preprocessor import TimeSeriesPreprocessor
from .constants import DATASET_CONFIGS

class TrafficDataLoader:
    """Data loader for traffic datasets (PeMS and others)."""
    
    def __init__(self, config):
        """Initialize data loader.
        
        Args:
            config (dict): Configuration dictionary
        """
        self.config = config
        self.preprocessor = TimeSeriesPreprocessor(config['data']['scale_method'])
        
    def load_dataset(self, dataset_name, root_path):
        """Load specific dataset.
        
        Args:
            dataset_name (str): Name of dataset ('PeMSD3', 'METR-LA', etc.)
            root_path (str): Root path for data files
            
        Returns:
            tuple: (train_loader, val_loader, test_loader, adj_mx, preprocessor)
        """
        if dataset_name not in DATASET_CONFIGS:
            raise ValueError(f"Dataset {dataset_name} not supported")
        
        dataset_config = DATASET_CONFIGS[dataset_name]
        
        # Load data based on dataset type
        if dataset_name in ['METR-LA', 'PEMS-BAY']:
            data, adj_mx = self._load_h5_dataset(dataset_name, root_path)
        else:
            data, adj_mx = self._load_pems_dataset(dataset_name, root_path)
        
        # Preprocess data
        data = self.preprocessor.fit_transform(data)
        
        # Split data
        split_ratio = dataset_config['split_ratio']
        train_data, val_data, test_data = self._split_data(data, split_ratio)
        
        # Create data loaders
        train_loader = self._create_data_loader(
            train_data, 
            batch_size=self.config['data']['batch_size'],
            shuffle=True
        )
        val_loader = self._create_data_loader(
            val_data,
            batch_size=self.config['data']['batch_size'],
            shuffle=False
        )
        test_loader = self._create_data_loader(
            test_data,
            batch_size=self.config['data']['batch_size'],
            shuffle=False
        )
        
        return train_loader, val_loader, test_loader, adj_mx, self.preprocessor
    
    def _load_h5_dataset(self, dataset_name, root_path):
        """Load HDF5 format datasets (METR-LA and PEMS-BAY).
        
        Args:
            dataset_name (str): Name of dataset
            root_path (str): Root path for data files
            
        Returns:
            tuple: (data, adj_mx)
        """
        dataset_path = os.path.join(root_path, f"{dataset_name.lower()}.h5")
        adj_path = os.path.join(root_path, f"{dataset_name.lower()}_adj.csv")
        
        with h5py.File(dataset_path, 'r') as hf:
            data = np.array(hf['data'])
        
        # Load adjacency matrix
        adj_mx = pd.read_csv(adj_path).values
        
        # Reshape data to [num_nodes, num_timestamps, num_features]
        data = np.transpose(data, (1, 0, 2))
        
        return data, adj_mx
    
    def _load_pems_dataset(self, dataset_name, root_path):
        """Load PeMS datasets.
        
        Args:
            dataset_name (str): Name of dataset
            root_path (str): Root path for data files
            
        Returns:
            tuple: (data, adj_mx)
        """
        data_path = os.path.join(root_path, dataset_name, 'data.csv')
        adj_path = os.path.join(root_path, dataset_name, 'adj_mx.csv')
        
        # Load data
        data = pd.read_csv(data_path)
        
        # Convert to numpy and reshape to [num_nodes, num_timestamps, num_features]
        num_nodes = DATASET_CONFIGS[dataset_name]['nodes']
        data = data.values.reshape(num_nodes, -1, 1)  # Assuming single feature (traffic flow)
        
        # Load adjacency matrix
        adj_mx = pd.read_csv(adj_path).values
        
        return data, adj_mx
    
    def _split_data(self, data, split_ratio):
        """Split data into train, validation and test sets.
        
        Args:
            data (np.ndarray): Full dataset
            split_ratio (list): List of ratios [train_ratio, val_ratio, test_ratio]
            
        Returns:
            tuple: (train_data, val_data, test_data)
        """
        train_ratio, val_ratio, _ = split_ratio
        
        train_size = int(data.shape[1] * train_ratio)
        val_size = int(data.shape[1] * val_ratio)
        
        train_data = data[:, :train_size, :]
        val_data = data[:, train_size:train_size+val_size, :]
        test_data = data[:, train_size+val_size:, :]
        
        return train_data, val_data, test_data
    
    def _create_data_loader(self, data, batch_size, shuffle):
        """Create data loader for a dataset.
        
        Args:
            data (np.ndarray): Input data
            batch_size (int): Batch size
            shuffle (bool): Whether to shuffle the data
            
        Returns:
            DataLoader: PyTorch data loader
        """
        dataset = TimeSeriesDataset(
            data,
            window_size=self.config['data']['window_size'],
            horizon=self.config['data']['horizon']
        )
        
        return DataLoader(
            dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=self.config['data']['num_workers'],
            pin_memory=True
        )