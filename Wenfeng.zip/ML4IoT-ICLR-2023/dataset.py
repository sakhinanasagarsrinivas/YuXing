# src/data/dataset.py
import torch
from torch.utils.data import Dataset
import numpy as np

class TimeSeriesDataset(Dataset):
    """Dataset for multivariate time series forecasting."""
    
    def __init__(self, data, window_size, horizon):
        """Initialize dataset.
        
        Args:
            data (np.ndarray): Shape [num_nodes, num_timestamps, num_features]
            window_size (int): Number of past time steps to use
            horizon (int): Number of future time steps to predict
        """
        self.data = torch.FloatTensor(data)
        self.window_size = window_size
        self.horizon = horizon
        self.indices = self._generate_indices()
        
    def _generate_indices(self):
        """Generate valid indices for sliding windows."""
        num_samples = self.data.shape[1] - self.window_size - self.horizon + 1
        return list(range(num_samples))
    
    def __len__(self):
        """Return number of samples."""
        return len(self.indices)
    
    def __getitem__(self, idx):
        """Get a single sample.
        
        Args:
            idx (int): Sample index
            
        Returns:
            tuple: (x, y) where:
                x is the input sequence of shape [num_nodes, window_size, num_features]
                y is the target sequence of shape [num_nodes, horizon, num_features]
        """
        t = self.indices[idx]
        x = self.data[:, t:t+self.window_size, :]
        y = self.data[:, t+self.window_size:t+self.window_size+self.horizon, :]
        return x, y