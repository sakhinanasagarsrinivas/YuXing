# src/training/training.py
import torch
import torch.optim as optim
import numpy as np
from tqdm import tqdm
import logging
from ..models.losses import EIKFNetLoss
from ..evaluation.evaluation_metrics import EvaluationMetrics

class Trainer:
    """Trainer class for EIKF-Net model."""
    
    def __init__(self, model, config, device):
        """Initialize trainer.
        
        Args:
            model: EIKF-Net model instance
            config (dict): Training configuration
            device: torch device
        """
        self.model = model
        self.config = config
        self.device = device
        
        # Setup loss and optimizer
        self.criterion = EIKFNetLoss(
            alpha=config['training']['uncertainty_weight'],
            beta=config['training']['hypergraph_weight']
        )
        self.optimizer = optim.Adam(
            model.parameters(),
            lr=config['training']['learning_rate'],
            weight_decay=config['training']['weight_decay']
        )
        
        # Learning rate scheduler
        self.scheduler = optim.lr_scheduler.ReduceLROnPlateau(
            self.optimizer,
            mode='min',
            patience=config['training']['lr_patience'],
            factor=config['training']['lr_factor']
        )
        
        # Setup logger
        logging.basicConfig(level=logging.INFO)
        self.logger = logging.getLogger(__name__)
    
    def train_epoch(self, train_loader):
        """Train for one epoch.
        
        Args:
            train_loader: DataLoader for training data
            
        Returns:
            float: Average training loss for the epoch
        """
        self.model.train()
        total_loss = 0
        
        with tqdm(train_loader, desc='Training') as pbar:
            for x, y in pbar:
                x, y = x.to(self.device), y.to(self.device)
                
                self.optimizer.zero_grad()
                
                # Forward pass
                if self.config['model']['estimate_uncertainty']:
                    pred, mu, sigma = self.model(x)
                    loss = self.criterion(pred, y, mu, sigma)
                else:
                    pred = self.model(x)
                    loss = self.criterion(pred, y)
                
                # Backward pass
                loss.backward()
                
                # Gradient clipping
                if self.config['training']['grad_clip']:
                    torch.nn.utils.clip_grad_norm_(
                        self.model.parameters(),
                        self.config['training']['grad_clip_value']
                    )
                
                self.optimizer.step()
                
                total_loss += loss.item()
                pbar.set_postfix({'loss': loss.item()})
        
        return total_loss / len(train_loader)
    
    def validate(self, val_loader, scaler=None):
        """Validate the model.
        
        Args:
            val_loader: DataLoader for validation data
            scaler: Optional scaler for inverse transforming predictions
            
        Returns:
            tuple: (validation loss, metrics dictionary)
        """
        self.model.eval()
        total_loss = 0
        predictions = []
        targets = []
        
        with torch.no_grad():
            for x, y in val_loader:
                x, y = x.to(self.device), y.to(self.device)
                
                if self.config['model']['estimate_uncertainty']:
                    pred, mu, sigma = self.model(x)
                    loss = self.criterion(pred, y, mu, sigma)
                else:
                    pred = self.model(x)
                    loss = self.criterion(pred, y)
                
                total_loss += loss.item()
                
                # Store predictions and targets for metrics
                predictions.append(pred.cpu().numpy())
                targets.append(y.cpu().numpy())
        
        # Compute metrics
        predictions = np.concatenate(predictions, axis=0)
        targets = np.concatenate(targets, axis=0)
        
        metrics = EvaluationMetrics(scaler)
        metrics_dict = metrics.evaluate(predictions, targets)
        
        return total_loss / len(val_loader), metrics_dict
    
    def train(self, train_loader, val_loader, scaler=None):
        """Full training loop.
        
        Args:
            train_loader: DataLoader for training data
            val_loader: DataLoader for validation data
            scaler: Optional scaler for inverse transforming predictions
        """
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.config['training']['epochs']):
            # Train
            train_loss = self.train_epoch(train_loader)
            
            # Validate
            val_loss, metrics = self.validate(val_loader, scaler)
            
            # Learning rate scheduling
            self.scheduler.step(val_loss)
            
            # Logging
            self.logger.info(f"\nEpoch {epoch + 1}/{self.config['training']['epochs']}")
            self.logger.info(f"Train Loss: {train_loss:.4f}")
            self.logger.info(f"Val Loss: {val_loss:.4f}")
            
            # Print metrics
            EvaluationMetrics.print_metrics(metrics)
            
            # Early stopping
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                # Save best model
                torch.save(self.model.state_dict(), 
                         self.config['training']['model_save_path'])
            else:
                patience_counter += 1
                if patience_counter >= self.config['training']['patience']:
                    self.logger.info("Early stopping triggered!")
                    break
        
        self.logger.info("Training completed!")