# trainer.py
from typing import Dict, List, Any, Optional, Tuple
import torch
from torch.utils.data import Dataset, DataLoader
import numpy as np
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.llms import OpenAI
from sklearn.model_selection import train_test_split
from sklearn.metrics import precision_recall_fscore_support
from transformers import AutoTokenizer, AutoModelForCausalLM
import logging
from tqdm import tqdm
from patexpert import PatentClassifier, AcceptancePredictor, ClaimGenerator, AbstractSummarizer
from expert_agents import (
    BaseExpertAgent, PatentClassifier, AcceptancePredictor,
    ClaimGenerator, AbstractSummarizer, HypothesisGenerator
)
from critique_agents import RewardCritic, GoldCritic
from dataset_utils import HUPDDatasetProcessor, DatasetManager
import wandb
import json
import os

class PatExpertTrainer:
    """Training coordinator for PatExpert framework"""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = logging.getLogger(__name__)
        
        # Initialize dataset processor
        self.data_processor = HUPDDatasetProcessor(base_path=config['data_path'])
        
        # Initialize expert agents
        self.expert_agents = {
            'classification': PatentClassifier(),
            'acceptance': AcceptancePredictor(),
            'claims': ClaimGenerator(),
            'summary': AbstractSummarizer(),
            'hypothesis': HypothesisGenerator()
        }
        
        # Initialize critique agents
        self.critics = {
            'reward': RewardCritic(),
            'gold': GoldCritic()
        }
        
        # Setup logging
        wandb.init(project="patexpert", config=config)

    def prepare_datasets(self) -> Dict[str, Dataset]:
        """Prepare task-specific datasets"""
        datasets = {}
        
        for task in self.config['tasks']:
            self.logger.info(f"Preparing dataset for {task}")
            
            # Get appropriate dataset based on task
            if task == "classification":
                data = self.data_processor.preprocess_for_classification()
            elif task == "acceptance":
                data = self.data_processor.preprocess_for_acceptance()
            elif task == "claims":
                data = self.data_processor.preprocess_for_claim_generation()
            elif task == "summary":
                data = self.data_processor.preprocess_for_summarization()
            elif task == "hypothesis":
                data = self.data_processor.create_hypothesis_generation_dataset()
            
            # Create dataset splits
            dataset_manager = DatasetManager(
                data=data,
                val_size=self.config['val_size'],
                test_size=self.config['test_size']
            )
            
            train_data, val_data, test_data = dataset_manager.create_splits()
            datasets[task] = {
                'train': train_data,
                'val': val_data,
                'test': test_data
            }
            
        return datasets

    def train_expert(self, task: str, dataset: Dataset) -> None:
        """Train a specific expert agent"""
        try:
            expert = self.expert_agents[task]
            
            self.logger.info(f"Training {task} expert")
            
            # Get task-specific training config
            train_config = self.config['task_configs'][task]
            
            # Train the expert
            expert.train(
                dataset,
                learning_rate=train_config['learning_rate'],
                batch_size=train_config['batch_size'],
                num_epochs=train_config['epochs']
            )
            
            # Save the trained model
            expert.save(f"models/{task}_expert.pt")
            
        except Exception as e:
            self.logger.error(f"Error training {task} expert: {str(e)}")
            raise

    def evaluate_expert(self, task: str, test_data: Dataset) -> Dict[str, float]:
        """Evaluate a specific expert agent"""
        try:
            expert = self.expert_agents[task]
            metrics = {}
            
            self.logger.info(f"Evaluating {task} expert")
            
            # Task-specific evaluation
            if task in ['classification', 'acceptance']:
                predictions = expert.predict(test_data)
                precision, recall, f1, _ = precision_recall_fscore_support(
                    test_data['labels'],
                    predictions,
                    average='weighted'
                )
                accuracy = (predictions == test_data['labels']).mean()
                
                metrics = {
                    'precision': precision,
                    'recall': recall,
                    'f1': f1,
                    'accuracy': accuracy
                }
                
            elif task in ['claims', 'summary']:
                # Use BLEU and ROUGE for text generation tasks
                predictions = expert.generate(test_data)
                bleu_score = self._calculate_bleu(predictions, test_data['reference'])
                rouge_scores = self._calculate_rouge(predictions, test_data['reference'])
                
                metrics = {
                    'bleu': bleu_score,
                    **rouge_scores
                }
            
            # Log metrics
            wandb.log({f"{task}_{k}": v for k, v in metrics.items()})
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Error evaluating {task} expert: {str(e)}")
            raise

    def _calculate_bleu(self, predictions: List[str], references: List[str]) -> float:
        """Calculate BLEU score"""
        from nltk.translate.bleu_score import corpus_bleu
        return corpus_bleu([[r.split()] for r in references], [p.split() for p in predictions])

    def _calculate_rouge(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Calculate ROUGE scores"""
        from rouge import Rouge
        rouge = Rouge()
        scores = rouge.get_scores(predictions, references, avg=True)
        return {
            'rouge-1': scores['rouge-1']['f'],
            'rouge-2': scores['rouge-2']['f'],
            'rouge-l': scores['rouge-l']['f']
        }

    def train(self) -> None:
        """Main training loop"""
        try:
            # Prepare datasets
            datasets = self.prepare_datasets()
            
            # Train each expert
            for task in self.config['tasks']:
                self.train_expert(task, datasets[task]['train'])
                metrics = self.evaluate_expert(task, datasets[task]['test'])
                
                self.logger.info(f"{task} evaluation metrics: {metrics}")
                
            self.logger.info("Training completed successfully")
            
        except Exception as e:
            self.logger.error(f"Training error: {str(e)}")
            raise
            
    def save_checkpoint(self, path: str) -> None:
        """Save training checkpoint"""
        checkpoint = {
            'config': self.config,
            'expert_states': {
                name: expert.state_dict() 
                for name, expert in self.expert_agents.items()
            }
        }
        torch.save(checkpoint, path)

    def load_checkpoint(self, path: str) -> None:
        """Load training checkpoint"""
        checkpoint = torch.load(path)
        self.config = checkpoint['config']
        
        for name, state in checkpoint['expert_states'].items():
            self.expert_agents[name].load_state_dict(state)

# evaluation.py
class PatExpertEvaluator:
    """Handles comprehensive evaluation of PatExpert framework"""
    
    def __init__(self, model_path: str):
        self.model_path = model_path
        self.logger = logging.getLogger(__name__)
        
        # Load trained model
        checkpoint = torch.load(model_path)
        self.config = checkpoint['config']
        
        # Initialize components
        self.expert_agents = {
            'classification': PatentClassifier(),
            'acceptance': AcceptancePredictor(),
            'claims': ClaimGenerator(),
            'summary': AbstractSummarizer(),
            'hypothesis': HypothesisGenerator()
        }
        
        # Load trained states
        for name, state in checkpoint['expert_states'].items():
            self.expert_agents[name].load_state_dict(state)
            
        self.critics = {
            'reward': RewardCritic(),
            'gold': GoldCritic()
        }

    async def evaluate_response(
        self,
        query: str,
        response: str,
        task: str
    ) -> Dict[str, Any]:
        """Evaluate a single response using both critics"""
        
        # Get critiques
        reward_critique = await self.critics['reward'].evaluate(
            query=query,
            response=response
        )
        
        gold_critique = await self.critics['gold'].evaluate(
            query=query,
            response=response
        )
        
        # Combine critiques
        evaluation = {
            'reward_critique': reward_critique,
            'gold_critique': gold_critique,
            'status': 'CORRECT' if (
                reward_critique['status'] == 'CORRECT' and
                gold_critique['status'] == 'CORRECT'
            ) else 'INCORRECT'
        }
        
        return evaluation

    async def evaluate_batch(
        self,
        test_data: Dataset,
        task: str
    ) -> Dict[str, Any]:
        """Evaluate a batch of test cases"""
        results = []
        
        for item in tqdm(test_data):
            response = await self.expert_agents[task].process(
                query=item['query'],
                context=item.get('context')
            )
            
            evaluation = await self.evaluate_response(
                query=item['query'],
                response=response['response'],
                task=task
            )
            
            results.append({
                'query': item['query'],
                'response': response['response'],
                'evaluation': evaluation
            })
            
        # Calculate aggregate metrics
        metrics = self._calculate_aggregate_metrics(results)
        
        return {
            'results': results,
            'metrics': metrics
        }

    def _calculate_aggregate_metrics(
        self,
        results: List[Dict[str, Any]]
    ) -> Dict[str, float]:
        """Calculate aggregate metrics from evaluation results"""
        total = len(results)
        correct = sum(1 for r in results if r['evaluation']['status'] == 'CORRECT')
        
        metrics = {
            'accuracy': correct / total,
            'reward_scores': np.mean([
                r['evaluation']['reward_critique']['scores']
                for r in results
            ]),
            'gold_confidence': np.mean([
                r['evaluation']['gold_critique']['metadata']['confidence']
                for r in results
            ])
        }
        
        return metrics

# main.py
def main():
    # Load configuration
    with open('config.json', 'r') as f:
        config = json.load(f)
        
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Initialize trainer
    trainer = PatExpertTrainer(config)
    
    try:
        # Train the model
        trainer.train()
        
        # Save checkpoint
        trainer.save_checkpoint('models/patexpert_latest.pt')
        
        # Initialize evaluator
        evaluator = PatExpertEvaluator('models/patexpert_latest.pt')
        
        # Load test data
        test_data = HUPDDatasetProcessor(
            base_path=config['data_path']
        ).create_test_dataset()
        
        # Evaluate on test set
        results = await evaluator.evaluate_batch(test_data, task='classification')
        
        # Log results
        logging.info(f"Evaluation metrics: {results['metrics']}")
        
        # Save detailed results
        with open('evaluation_results.json', 'w') as f:
            json.dump(results, f, indent=2)
            
    except Exception as e:
        logging.error(f"Error in main execution: {str(e)}")
        raise

if __name__ == "__main__":
    main()