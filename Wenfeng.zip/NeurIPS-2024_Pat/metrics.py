# metrics.py
from typing import List, Dict, Any
import numpy as np
from nltk.translate.bleu_score import corpus_bleu
from rouge_score import rouge_scorer
from sklearn.metrics import precision_recall_fscore_support, accuracy_score
import torch
import logging

class PatExpertMetrics:
    """Evaluation metrics for PatExpert framework"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'])

    def calculate_text_metrics(
        self,
        predictions: List[str],
        references: List[str]
    ) -> Dict[str, float]:
        """Calculate metrics for text generation tasks"""
        try:
            # Calculate BLEU score
            bleu = self._calculate_bleu(predictions, references)
            
            # Calculate ROUGE scores
            rouge_scores = self._calculate_rouge(predictions, references)
            
            metrics = {
                'bleu': bleu,
                **rouge_scores
            }
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Error calculating text metrics: {str(e)}")
            raise

    def calculate_classification_metrics(
        self,
        predictions: List[Any],
        references: List[Any]
    ) -> Dict[str, float]:
        """Calculate metrics for classification tasks"""
        try:
            precision, recall, f1, _ = precision_recall_fscore_support(
                references,
                predictions,
                average='weighted'
            )
            
            accuracy = accuracy_score(references, predictions)
            
            metrics = {
                'precision': precision,
                'recall': recall,
                'f1': f1,
                'accuracy': accuracy
            }
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Error calculating classification metrics: {str(e)}")
            raise

    def _calculate_bleu(
        self,
        predictions: List[str],
        references: List[str]
    ) -> float:
        """Calculate BLEU score"""
        references_tokens = [[ref.split()] for ref in references]
        predictions_tokens = [pred.split() for pred in predictions]
        return corpus_bleu(references_tokens, predictions_tokens)

    def _calculate_rouge(
        self,
        predictions: List[str],
        references: List[str]
    ) -> Dict[str, float]:
        """Calculate ROUGE scores"""
        scores = {
            'rouge1': 0.0,
            'rouge2': 0.0,
            'rougeL': 0.0
        }
        
        for pred, ref in zip(predictions, references):
            score = self.rouge_scorer.score(ref, pred)
            scores['rouge1'] += score['rouge1'].fmeasure
            scores['rouge2'] += score['rouge2'].fmeasure
            scores['rougeL'] += score['rougeL'].fmeasure
        
        # Average scores
        n = len(predictions)
        return {k: v/n for k, v in scores.items()}

    def evaluate_critic_outputs(
        self,
        reward_critiques: List[Dict[str, Any]],
        gold_critiques: List[Dict[str, Any]]
    ) -> Dict[str, float]:
        """Evaluate critic outputs"""
        try:
            metrics = {
                'reward_scores': np.mean([
                    critique['scores']['overall'] 
                    for critique in reward_critiques
                ]),
                'gold_confidence': np.mean([
                    critique['metadata']['confidence'] 
                    for critique in gold_critiques
                ]),
                'acceptance_rate': np.mean([
                    critique['status'] == 'CORRECT'
                    for critique in gold_critiques
                ])
            }
            
            return metrics
            
        except Exception as e:
            self.logger.error(f"Error evaluating critic outputs: {str(e)}")
            raise




