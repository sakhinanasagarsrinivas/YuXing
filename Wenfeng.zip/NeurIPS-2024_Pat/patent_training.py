# patent_training.py
from dataset_utils import HUPDDatasetProcessor, DatasetManager
from llama_index.llms.openai import OpenAI
from llama_index.finetuning.callbacks import OpenAIFineTuningHandler
from llama_index.core.callbacks import CallbackManager
from llama_index.finetuning import OpenAIFinetuneEngine
import logging
from typing import Dict, Any
import os

class PatentTaskTrainer:
    """Handles training data generation and fine-tuning for patent tasks"""
    
    def __init__(self, base_path: str = "data"):
        self.processor = HUPDDatasetProcessor(base_path=base_path)
        self.dataset_manager = None
        
        # Setup for GPT-4 training data generation
        self.finetuning_handler = OpenAIFineTuningHandler()
        self.callback_manager = CallbackManager([self.finetuning_handler])
        self.gpt4 = OpenAI(model="gpt-4", temperature=0.3)
        self.gpt4.callback_manager = self.callback_manager
        
        self.logger = logging.getLogger(__name__)

    def prepare_task_dataset(self, task: str):
        """Prepare dataset for specific task"""
        # Get appropriate dataset based on task
        if task == "classification":
            data = self.processor.preprocess_for_classification()
        elif task == "acceptance":
            data = self.processor.preprocess_for_acceptance()
        elif task == "claims":
            data = self.processor.preprocess_for_claim_generation()
        elif task == "summary":
            data = self.processor.preprocess_for_summarization()
        elif task == "hypothesis":
            data = self.processor.create_hypothesis_generation_dataset()
        elif task == "multi_patent":
            data = self.processor.create_multi_patent_raft_dataset()
        else:
            raise ValueError(f"Unknown task: {task}")
            
        # Create dataset splits
        self.dataset_manager = DatasetManager(
            data=data,
            val_size=0.1,
            test_size=0.1
        )
        
        return self.dataset_manager.create_splits()

    def generate_gpt4_training_data(self, task: str, train_data):
        """Generate high-quality training data using GPT-4"""
        system_prompts = {
            "classification": "You are an expert patent classifier. Classify this patent into appropriate IPC/CPC codes.",
            "acceptance": "You are an expert patent examiner. Determine if this patent application should be granted.",
            "claims": "You are an expert patent attorney. Generate comprehensive claims for this patent.",
            "summary": "You are an expert technical writer. Generate a concise and informative abstract for this patent.",
            "hypothesis": "You are an expert scientist. Generate scientific hypotheses from this patent's content.",
            "multi_patent": "You are an expert patent analyst. Analyze relationships and comparisons between patents."
        }

        training_examples = []
        for i, example in enumerate(train_data):
            try:
                # Format input based on task
                if task == "classification":
                    input_text = example["text"]
                    target = example["labels"]
                elif task == "acceptance":
                    input_text = example["text"]
                    target = example["labels"]
                elif task == "claims":
                    input_text = example["document"]
                    target = example["claims"]
                elif task == "summary":
                    input_text = example["document"]
                    target = example["summary"]
                elif task == "hypothesis":
                    input_text = f"""Title: {example['title']}
                    Abstract: {example['abstract']}
                    Claims: {example['claims']}"""
                    target = example["hypothesis"]
                elif task == "multi_patent":
                    input_text = f"Question: {example['question']}\nContext: {example['context']}"
                    target = example["answer"]

                # Get GPT-4 enhanced response
                messages = [
                    {"role": "system", "content": system_prompts[task]},
                    {"role": "user", "content": input_text}
                ]
                
                response = self.gpt4.chat.completions.create(
                    model="gpt-4",
                    messages=messages,
                    temperature=0.3
                )
                
                training_examples.append({
                    "messages": messages + [{"role": "assistant", "content": response.choices[0].message.content}]
                })
                
            except Exception as e:
                self.logger.error(f"Error processing example {i}: {str(e)}")
                continue

        # Save training data
        self.finetuning_handler.save_finetuning_events(f"{task}_training_events.jsonl")
        return training_examples

    def finetune_model(self, task: str, training_file: str):
        """Fine-tune GPT-4o mini for specific task"""
        finetune_engine = OpenAIFinetuneEngine(
            "gpt-4o-mini",
            training_file
        )
        return finetune_engine.finetune()

def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--task",
        required=True,
        choices=[
            "classification",
            "acceptance", 
            "claims",
            "summary",
            "hypothesis",
            "multi_patent"
        ]
    )
    parser.add_argument("--data_path", required=True)
    args = parser.parse_args()
    
    # Setup logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)
    
    # Initialize trainer
    trainer = PatentTaskTrainer(base_path=args.data_path)
    
    # Prepare dataset
    logger.info(f"Preparing dataset for {args.task}")
    train_data, val_data, test_data = trainer.prepare_task_dataset(args.task)
    
    # Generate training data with GPT-4
    logger.info("Generating training data with GPT-4")
    training_examples = trainer.generate_gpt4_training_data(args.task, train_data)
    
    # Fine-tune model
    logger.info("Starting fine-tuning")
    ft_model = trainer.finetune_model(
        args.task,
        f"{args.task}_training_events.jsonl"
    )
    
    logger.info("Fine-tuning complete")

if __name__ == "__main__":
    main()