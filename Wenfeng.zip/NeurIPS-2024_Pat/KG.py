from typing import List, Dict, Any, Optional
import os
import glob
import PyPDF2
from pathlib import Path
from tqdm import tqdm
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.llms import OpenAI
from langchain.prompts import PromptTemplate
from langchain.chains import LLMChain
from neo4j import GraphDatabase
import numpy as np
from sentence_transformers import SentenceTransformer
import logging
import re

class PatentPDFProcessor:
    """Handles PDF reading and text extraction from patent documents"""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)

    def extract_patent_id(self, filename: str) -> str:
        """Extract patent ID from filename or document content"""
        # Try to find a patent number pattern in the filename
        # Common formats: US12345678, US-12345678, EP12345678
        pattern = r'([A-Z]{2}[-]?\d{6,})'
        match = re.search(pattern, filename)
        if match:
            return match.group(1)
        return os.path.splitext(os.path.basename(filename))[0]

    def read_pdf(self, file_path: str) -> Dict[str, str]:
        """Read PDF file and extract text and metadata"""
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                
                # Extract text from all pages
                text = ""
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
                
                # Get metadata
                metadata = pdf_reader.metadata if pdf_reader.metadata else {}
                
                # Extract patent ID from filename or content
                patent_id = self.extract_patent_id(file_path)
                
                return {
                    "patent_id": patent_id,
                    "text": text,
                    "metadata": metadata,
                    "source_file": file_path
                }
                
        except Exception as e:
            self.logger.error(f"Error reading PDF {file_path}: {str(e)}")
            return None

class PatentKnowledgeGraph:
    def __init__(
        self, 
        uri: str = "neo4j://localhost:7687",
        username: str = "neo4j",
        password: str = "your_password"
    ):
        self.driver = GraphDatabase.driver(uri, auth=(username, password))
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        self.embeddings = OpenAIEmbeddings()
        self.encoder = SentenceTransformer('sentence-transformers/all-mpnet-base-v2')
        self.llm = OpenAI(temperature=0.3)
        
        self.pdf_processor = PatentPDFProcessor()
        
        # Setup LLM chain for triple extraction
        triple_template = """Extract subject-action-object triples from the following patent text.
        Focus on technical relationships and innovations.
        
        Text: {text}
        
        Output the triples in the format:
        Subject: [subject]
        Action: [action]
        Object: [object]
        """
        
        self.triple_chain = LLMChain(
            llm=self.llm,
            prompt=PromptTemplate(
                template=triple_template,
                input_variables=["text"]
            )
        )
        
        self.logger = logging.getLogger(__name__)

    def initialize_database(self):
        """Initialize Neo4j database with required indexes"""
        with self.driver.session() as session:
            # Create indexes for better query performance
            session.run("CREATE INDEX IF NOT EXISTS FOR (c:Chunk) ON (c.id)")
            session.run("CREATE INDEX IF NOT EXISTS FOR (e:Entity) ON (e.id)")
            # Create full-text search index for text content
            session.run("""
            CALL db.index.fulltext.createNodeIndex(
                'chunkTextSearch',
                ['Chunk'],
                ['text']
            )
            """)

    def process_patent_folder(self, folder_path: str):
        """Process all PDF files in the specified folder"""
        try:
            # Initialize database
            self.initialize_database()
            
            # Get all PDF files in the folder
            pdf_files = glob.glob(os.path.join(folder_path, "*.pdf"))
            
            if not pdf_files:
                self.logger.warning(f"No PDF files found in {folder_path}")
                return
            
            # Process each PDF file
            for pdf_file in tqdm(pdf_files, desc="Processing patents"):
                try:
                    # Read PDF
                    patent_data = self.pdf_processor.read_pdf(pdf_file)
                    
                    if patent_data:
                        # Process the patent
                        self.process_patent(
                            patent_text=patent_data["text"],
                            patent_id=patent_data["patent_id"],
                            metadata=patent_data["metadata"]
                        )
                        self.logger.info(f"Successfully processed {pdf_file}")
                    
                except Exception as e:
                    self.logger.error(f"Error processing {pdf_file}: {str(e)}")
                    continue
                    
        except Exception as e:
            self.logger.error(f"Error processing folder {folder_path}: {str(e)}")
            raise

    def create_patent_node(self, tx, patent_id: str, metadata: Dict):
        """Create a patent node with metadata"""
        query = """
        CREATE (p:Patent {
            id: $patent_id,
            metadata: $metadata
        })
        """
        tx.run(query, patent_id=patent_id, metadata=metadata)

    def create_chunk_node(self, tx, chunk_id: str, text: str, embedding: List[float], patent_id: str):
        """Create a text chunk node and link it to patent"""
        query = """
        CREATE (c:Chunk {
            id: $chunk_id,
            text: $text,
            embedding: $embedding
        })
        WITH c
        MATCH (p:Patent {id: $patent_id})
        CREATE (p)-[:CONTAINS]->(c)
        """
        tx.run(query, chunk_id=chunk_id, text=text, embedding=embedding, patent_id=patent_id)

    # [Previous methods remain the same...]

    def process_patent(self, patent_text: str, patent_id: str, metadata: Dict = None):
        """Process a patent document and add it to the knowledge graph"""
        try:
            # Create patent node first
            with self.driver.session() as session:
                session.write_transaction(
                    self.create_patent_node,
                    patent_id,
                    metadata or {}
                )
            
            # Split text into chunks
            chunks = self.text_splitter.split_text(patent_text)
            
            with self.driver.session() as session:
                for i, chunk in enumerate(chunks):
                    chunk_id = f"{patent_id}_chunk_{i}"
                    
                    # Generate embedding for chunk
                    embedding = self.encoder.encode(chunk).tolist()
                    
                    # Create chunk node and link to patent
                    session.write_transaction(
                        self.create_chunk_node,
                        chunk_id,
                        chunk,
                        embedding,
                        patent_id
                    )
                    
                    # Extract and process triples
                    triples = self.extract_triples(chunk)
                    
                    # Process each triple
                    for j, triple in enumerate(triples):
                        subject_id = f"{chunk_id}_subject_{j}"
                        object_id = f"{chunk_id}_object_{j}"
                        
                        # Create entities and relationships
                        self._process_triple(
                            session, 
                            triple, 
                            subject_id, 
                            object_id, 
                            chunk_id
                        )
                        
        except Exception as e:
            self.logger.error(f"Error processing patent {patent_id}: {str(e)}")
            raise

    def _process_triple(self, session, triple: Dict, subject_id: str, object_id: str, chunk_id: str):
        """Helper method to process a single triple"""
        # Create entity nodes
        session.write_transaction(
            self.create_entity_node,
            subject_id,
            "subject",
            triple["subject"]
        )
        session.write_transaction(
            self.create_entity_node,
            object_id,
            "object", 
            triple["object"]
        )
        
        # Create relationship between entities
        session.write_transaction(
            self.create_relationship,
            subject_id,
            triple["action"],
            object_id
        )
        
        # Create MENTIONS relationships
        session.write_transaction(
            self.create_mentions_relationship,
            chunk_id,
            subject_id
        )
        session.write_transaction(
            self.create_mentions_relationship,
            chunk_id,
            object_id
        )

def main():
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    # Initialize knowledge graph
    kg = PatentKnowledgeGraph(
        uri="neo4j://localhost:7687",
        username="neo4j",
        password="your_password"
    )
    
    try:
        # Process all patents in the folder
        patents_folder = "path/to/your/patents/folder"
        kg.process_patent_folder(patents_folder)
        
        # Example query
        results = kg.query_knowledge_graph(
            "How does the transformer architecture handle self-attention?"
        )
        
        print("\nQuery Results:")
        for result in results:
            print(f"\nFound relationship: {result['subject']} {result['relation']} {result['object']}")
            print(f"Context: {result['context']}")
            print(f"Relevance score: {result['score']}")
        
    finally:
        kg.close()

if __name__ == "__main__":
    main()