# config.py
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
from pathlib import Path
import json

@dataclass
class TaskConfig:
    """Configuration for individual tasks"""
    learning_rate: float = 1e-5
    batch_size: int = 32
    epochs: int = 100
    warmup_steps: int = 1000
    model_name: str = field(default="")

@dataclass
class DataConfig:
    """Data processing configuration"""
    base_path: Path
    years: List[int]
    val_size: float = 0.1
    test_size: float = 0.1
    tasks: List[str] = field(default_factory=lambda: [
        "classification",
        "acceptance",
        "claims",
        "summary",
        "hypothesis"
    ])
    task_configs: Dict[str, TaskConfig] = field(default_factory=dict)

@dataclass
class TrainingConfig:
    """Training configuration"""
    seed: int = 42
    gradient_accumulation_steps: int = 4
    weight_decay: float = 0.01
    max_grad_norm: float = 1.0
    logging_steps: int = 100
    save_steps: int = 1000
    eval_steps: int = 500

@dataclass
class MetaAgentConfig:
    """Meta-agent configuration"""
    model_name: str = "meta-llama/Llama-3.1-405B"
    temperature: float = 0.3
    max_tokens: int = 2048
    top_p: float = 0.95
    routing_config: Dict[str, Any] = field(default_factory=lambda: {
        "max_agents": 3,
        "min_confidence": 0.7,
        "similarity_threshold": 0.85
    })

@dataclass
class CriticConfig:
    """Configuration for critic agents"""
    model_name: str
    temperature: float = 0.2
    max_tokens: int = 512
    metrics: List[str] = field(default_factory=list)
    score_threshold: float = 0.8

@dataclass
class CriticAgentsConfig:
    """Configuration for all critic agents"""
    reward: CriticConfig = field(default_factory=lambda: CriticConfig(
        model_name="nvidia/nemotron-4-340b-reward",
        metrics=[
            "helpfulness",
            "correctness",
            "coherence",
            "complexity",
            "verbosity"
        ],
        score_threshold=0.8
    ))
    gold: CriticConfig = field(default_factory=lambda: CriticConfig(
        model_name="openai/gpt4o",
        max_tokens=1024,
        metrics=[
            "technical_accuracy",
            "legal_compliance",
            "completeness",
            "factual_support",
            "domain_relevance"
        ],
        score_threshold=0.85
    ))

@dataclass
class Neo4jConfig:
    """Neo4j database configuration"""
    uri: str = "neo4j://localhost:7687"
    username: str = "neo4j"
    password: str = "your_password"
    database: str = "patents"

@dataclass
class EmbeddingConfig:
    """Embedding model configuration"""
    model: str = "sentence-transformers/all-mpnet-base-v2"
    dimension: int = 768
    batch_size: int = 32

@dataclass
class ChunkConfig:
    """Text chunking configuration"""
    chunk_size: int = 1000
    chunk_overlap: int = 200
    min_chunk_size: int = 100

@dataclass
class IndexConfig:
    """Vector index configuration"""
    similarity_metric: str = "cosine"
    k_neighbors: int = 5
    index_type: str = "hnsw"
    ef_construction: int = 200
    m: int = 16

@dataclass
class KnowledgeGraphConfig:
    """Knowledge graph configuration"""
    neo4j: Neo4jConfig = field(default_factory=Neo4jConfig)
    embedding: EmbeddingConfig = field(default_factory=EmbeddingConfig)
    chunk_config: ChunkConfig = field(default_factory=ChunkConfig)
    index_config: IndexConfig = field(default_factory=IndexConfig)

@dataclass
class WandbConfig:
    """Weights & Biases configuration"""
    project: str = "patexpert"
    entity: str = "your_entity"
    log_artifacts: bool = True
    watch_gradients: bool = True

@dataclass
class LoggingConfig:
    """Logging configuration"""
    level: str = "INFO"
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    file_path: str = "logs/patexpert.log"
    wandb: WandbConfig = field(default_factory=WandbConfig)

@dataclass
class HardwareConfig:
    """Hardware configuration"""
    device: str = "cuda"
    num_gpus: int = 1
    mixed_precision: str = "fp16"
    gradient_checkpointing: bool = True

@dataclass
class PathConfig:
    """Path configuration"""
    model_dir: str = "models"
    data_dir: str = "data"
    output_dir: str = "outputs"
    cache_dir: str = "cache"
    log_dir: str = "logs"

@dataclass
class ExperimentConfig:
    """Complete experiment configuration"""
    data: DataConfig
    training: TrainingConfig = field(default_factory=TrainingConfig)
    meta_agent: MetaAgentConfig = field(default_factory=MetaAgentConfig)
    critic_agents: CriticAgentsConfig = field(default_factory=CriticAgentsConfig)
    knowledge_graph: KnowledgeGraphConfig = field(default_factory=KnowledgeGraphConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    hardware: HardwareConfig = field(default_factory=HardwareConfig)
    paths: PathConfig = field(default_factory=PathConfig)

def load_config(config_path: Optional[str] = None) -> ExperimentConfig:
    """Load configuration from file or use defaults"""
    if config_path is None:
        # Default configuration
        data_config = DataConfig(
            base_path=Path("./data"),
            years=[2015, 2016, 2017]
        )
        
        return ExperimentConfig(data=data_config)
    
    else:
        # Load from JSON config file
        with open(config_path, 'r') as f:
            config_dict = json.load(f)
        
        # Convert paths to Path objects
        config_dict['data']['base_path'] = Path(config_dict['data']['base_path'])
        
        # Create task configs
        task_configs = {}
        for task, cfg in config_dict['data']['task_configs'].items():
            task_configs[task] = TaskConfig(**cfg)
        config_dict['data']['task_configs'] = task_configs
        
        # Create data config
        data_config = DataConfig(**config_dict['data'])
        
        # Remove data from dict since we've handled it
        del config_dict['data']
        
        # Create full config
        return ExperimentConfig(
            data=data_config,
            **config_dict
        )

def save_config(config: ExperimentConfig, path: str) -> None:
    """Save configuration to JSON file"""
    config_dict = {
        'data': {
            'base_path': str(config.data.base_path),
            'years': config.data.years,
            'val_size': config.data.val_size,
            'test_size': config.data.test_size,
            'tasks': config.data.tasks,
            'task_configs': {
                task: vars(cfg) for task, cfg in config.data.task_configs.items()
            }
        },
        'training': vars(config.training),
        'meta_agent': vars(config.meta_agent),
        'critic_agents': {
            'reward': vars(config.critic_agents.reward),
            'gold': vars(config.critic_agents.gold)
        },
        'knowledge_graph': {
            'neo4j': vars(config.knowledge_graph.neo4j),
            'embedding': vars(config.knowledge_graph.embedding),
            'chunk_config': vars(config.knowledge_graph.chunk_config),
            'index_config': vars(config.knowledge_graph.index_config)
        },
        'logging': {
            **vars(config.logging),
            'wandb': vars(config.logging.wandb)
        },
        'hardware': vars(config.hardware),
        'paths': vars(config.paths)
    }
    
    with open(path, 'w') as f:
        json.dump(config_dict, f, indent=2)