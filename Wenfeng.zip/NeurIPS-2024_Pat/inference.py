# inference.py
class PatExpertInference:
    """Inference pipeline for PatExpert framework"""
    
    def __init__(
        self,
        meta_agent,
        expert_agents: Dict[str, Any],
        critics: Dict[str, Any],
        config: Dict[str, Any]
    ):
        self.meta_agent = meta_agent
        self.expert_agents = expert_agents
        self.critics = critics
        self.config = config
        self.logger = logging.getLogger(__name__)
        self.metrics = PatExpertMetrics()

    async def process_query(
        self,
        query: str,
        task: str = None
    ) -> Dict[str, Any]:
        """Process a single query"""
        try:
            # If task not specified, let meta-agent route it
            if task is None:
                routing = await self.meta_agent.route_query(query)
                task = routing['primary_task']
            
            # Get expert agent
            expert = self.expert_agents.get(task)
            if not expert:
                raise ValueError(f"No expert agent found for task: {task}")
            
            # Generate initial response
            response = await expert.process(query)
            
            # Get critiques
            reward_critique = await self.critics['reward'].evaluate(
                query=query,
                response=response
            )
            
            gold_critique = await self.critics['gold'].evaluate(
                query=query,
                response=response
            )
            
            # Refine response if needed
            if reward_critique['status'] == 'INCORRECT' or gold_critique['status'] == 'INCORRECT':
                refined_response = await self.meta_agent.refine_response(
                    query=query,
                    response=response,
                    reward_critique=reward_critique,
                    gold_critique=gold_critique
                )
                response = refined_response
            
            return {
                'task': task,
                'query': query,
                'response': response,
                'critiques': {
                    'reward': reward_critique,
                    'gold': gold_critique
                }
            }
            
        except Exception as e:
            self.logger.error(f"Error in inference: {str(e)}")
            raise

    async def batch_inference(
        self,
        queries: List[str],
        task: str = None
    ) -> List[Dict[str, Any]]:
        """Process a batch of queries"""
        results = []
        for query in queries:
            result = await self.process_query(query, task)
            results.append(result)
        return results