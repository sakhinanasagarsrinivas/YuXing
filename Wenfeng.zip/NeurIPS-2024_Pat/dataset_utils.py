# dataset_utils.py
import os
import json
import pandas as pd
import networkx as nx
from typing import Dict, List, Tuple, Optional, Set
from pathlib import Path
from datasets import load_dataset, Dataset, DatasetDict
import torch
from torch.utils.data import DataLoader
from sklearn.model_selection import train_test_split
from transformers import AutoTokenizer
import numpy as np
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.docstore.document import Document

class HUPDDatasetProcessor:
    """Processor for the Harvard USPTO Patent Dataset (HUPD)"""
    
    def __init__(self, base_path: str, years: List[int] = [2015, 2016, 2017]):
        self.base_path = Path(base_path)
        self.years = years
        self.raw_data = None
        self.processed_data = None
        self.text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=1000,
            chunk_overlap=200
        )
        
    def load_raw_data(self) -> None:
        """Load raw HUPD dataset from Hugging Face"""
        try:
            dataset = load_dataset("HUPD/hupd", 
                                 name="all", 
                                 split="train",
                                 streaming=True)
            
            filtered_data = []
            for example in dataset:
                if example['filing_date'].year in self.years:
                    filtered_data.append(example)
                    
            self.raw_data = pd.DataFrame(filtered_data)
            print(f"Loaded {len(self.raw_data)} patent documents")
            
        except Exception as e:
            print(f"Error loading dataset: {str(e)}")
            raise

    def create_multi_patent_raft_dataset(self) -> pd.DataFrame:
        """Create RAFT dataset for multi-patent analysis"""
        if self.raw_data is None:
            self.load_raw_data()
            
        # Create document chunks for each patent
        patent_chunks = []
        for _, row in self.raw_data.iterrows():
            full_text = f"""Title: {row['title']}
            Abstract: {row['abstract']}
            Background: {row['background']}
            Description: {row['description']}
            Claims: {row['claims']}"""
            
            chunks = self.text_splitter.create_documents([full_text])
            for chunk in chunks:
                patent_chunks.append({
                    'patent_id': row['patent_id'],
                    'chunk_text': chunk.page_content,
                    'filing_date': row['filing_date']
                })
        
        chunks_df = pd.DataFrame(patent_chunks)
        
        # Generate synthetic QA pairs
        qa_pairs = []
        for _, patent in self.raw_data.iterrows():
            # Technical questions
            qa_pairs.extend([
                {
                    'patent_id': patent['patent_id'],
                    'question': f"What is the main technical innovation in patent {patent['patent_id']}?",
                    'context': patent['abstract'] + "\n" + patent['claims'],
                    'answer': f"The main technical innovation involves {patent['title']}..."
                },
                {
                    'question': f"What technical problem does patent {patent['patent_id']} solve?",
                    'context': patent['background'] + "\n" + patent['summary'],
                    'answer': "The patent addresses the technical challenge of..."
                }
            ])
            
            # Comparative questions (for patents in same IPC class)
            related_patents = self.raw_data[
                (self.raw_data['ipc_class'] == patent['ipc_class']) & 
                (self.raw_data['patent_id'] != patent['patent_id'])
            ]
            if len(related_patents) > 0:
                related_patent = related_patents.iloc[0]
                qa_pairs.append({
                    'patent_id': patent['patent_id'],
                    'question': f"How does this patent differ from {related_patent['patent_id']}?",
                    'context': f"Patent 1: {patent['abstract']}\nPatent 2: {related_patent['abstract']}",
                    'answer': "The key differences between the patents are..."
                })
        
        return pd.DataFrame(qa_pairs)

    def create_hypothesis_generation_dataset(self) -> pd.DataFrame:
        """Create dataset for scientific hypothesis generation"""
        if self.raw_data is None:
            self.load_raw_data()
        
        # Filter for granted patents only
        granted_patents = self.raw_data[self.raw_data['granted'] == True]
        
        hypothesis_data = []
        for _, patent in granted_patents.iterrows():
            # Extract subject-action-object structures
            sao_structures = self._extract_sao_structures(
                title=patent['title'],
                abstract=patent['abstract'],
                claims=patent['claims']
            )
            
            hypothesis_data.append({
                'patent_id': patent['patent_id'],
                'title': patent['title'],
                'abstract': patent['abstract'],
                'claims': patent['claims'],
                'background': patent['background'],
                'description': patent['description'],
                'sao_structures': sao_structures,
                'hypothesis': self._generate_hypothesis_template(sao_structures)
            })
        
        return pd.DataFrame(hypothesis_data)

    def _extract_sao_structures(self, title: str, abstract: str, claims: str) -> List[Dict]:
        """Extract Subject-Action-Object structures from patent text"""
        # This is a simplified version - in practice, you'd use more sophisticated NLP
        sao_list = []
        
        # From title
        parts = title.split()
        if len(parts) >= 3:
            sao_list.append({
                'subject': parts[0],
                'action': parts[1],
                'object': ' '.join(parts[2:])
            })
            
        # From first claim (usually the broadest)
        first_claim = claims.split('.')[0]
        parts = first_claim.split()
        if len(parts) >= 3:
            sao_list.append({
                'subject': parts[0],
                'action': parts[1],
                'object': ' '.join(parts[2:])
            })
            
        return sao_list

    def _generate_hypothesis_template(self, sao_structures: List[Dict]) -> str:
        """Generate hypothesis template from SAO structures"""
        if not sao_structures:
            return ""
            
        # Use first SAO structure as main hypothesis
        main_sao = sao_structures[0]
        return f"The {main_sao['subject']} {main_sao['action']} {main_sao['object']}, " \
               f"which could potentially lead to improved performance in the field."

    def create_knowledge_graph_dataset(self) -> nx.DiGraph:
        """Create knowledge graph from patent documents"""
        if self.raw_data is None:
            self.load_raw_data()
            
        G = nx.DiGraph()
        
        # Add patent nodes
        for _, patent in self.raw_data.iterrows():
            G.add_node(patent['patent_id'], 
                      type='patent',
                      title=patent['title'],
                      abstract=patent['abstract'],
                      ipc_class=patent['ipc_class'])
            
            # Add IPC class node and edge
            G.add_node(patent['ipc_class'], type='ipc_class')
            G.add_edge(patent['patent_id'], patent['ipc_class'], 
                      relation='belongs_to')
            
            # Extract and add technical concept nodes
            concepts = self._extract_technical_concepts(
                patent['title'], 
                patent['abstract']
            )
            
            for concept in concepts:
                G.add_node(concept, type='concept')
                G.add_edge(patent['patent_id'], concept, 
                          relation='implements')
            
            # Add citation edges
            if patent['citations']:
                for citation in patent['citations']:
                    G.add_edge(patent['patent_id'], citation, 
                             relation='cites')
        
        return G

    def _extract_technical_concepts(self, title: str, abstract: str) -> Set[str]:
        """Extract technical concepts from patent text"""
        # This is a simplified version - in practice, use more sophisticated NLP
        text = f"{title} {abstract}".lower()
        words = set(text.split())
        
        # Filter for technical terms (simplified)
        technical_terms = {word for word in words 
                         if len(word) > 3 and not word.isspace()}
        
        return technical_terms

    # Previous methods remain the same
    def preprocess_for_classification(self) -> pd.DataFrame:
        """Preprocess data for patent classification task"""
        if self.raw_data is None:
            self.load_raw_data()
            
        processed = pd.DataFrame({
            'text': self.raw_data.apply(
                lambda x: f"Title: {x['title']}\nAbstract: {x['abstract']}\n" + \
                         f"Background: {x['background']}\nSummary: {x['summary']}", 
                axis=1
            ),
            'labels': self.raw_data['ipc_class']
        })
        return processed
        
    def preprocess_for_acceptance(self) -> pd.DataFrame:
        """Preprocess data for patent acceptance prediction task"""
        if self.raw_data is None:
            self.load_raw_data()
            
        processed = pd.DataFrame({
            'text': self.raw_data.apply(
                lambda x: f"Title: {x['title']}\nAbstract: {x['abstract']}\n" + \
                         f"Claims: {x['claims']}", 
                axis=1
            ),
            'labels': self.raw_data['granted']
        })
        return processed
        
    def preprocess_for_summarization(self) -> pd.DataFrame:
        """Preprocess data for abstractive summarization task"""
        if self.raw_data is None:
            self.load_raw_data()
            
        processed = pd.DataFrame({
            'document': self.raw_data.apply(
                lambda x: f"Title: {x['title']}\nBackground: {x['background']}\n" + \
                         f"Description: {x['description']}", 
                axis=1
            ),
            'summary': self.raw_data['abstract']
        })
        return processed
        
    def preprocess_for_claim_generation(self) -> pd.DataFrame:
        """Preprocess data for claim generation task"""
        if self.raw_data is None:
            self.load_raw_data()
            
        # Only use granted patents for claim generation
        granted_patents = self.raw_data[self.raw_data['granted'] == True]
        
        processed = pd.DataFrame({
            'document': granted_patents.apply(
                lambda x: f"Title: {x['title']}\nAbstract: {x['abstract']}\n" + \
                         f"Background: {x['background']}\nSummary: {x['summary']}\n" + \
                         f"Description: {x['description']}", 
                axis=1
            ),
            'claims': granted_patents['claims']
        })
        return processed

class DatasetManager:
    """Manages dataset splitting and dataloader creation"""
    
    def __init__(self, 
                 data: pd.DataFrame,
                 val_size: float = 0.1,
                 test_size: float = 0.1,
                 batch_size: int = 32,
                 seed: int = 42):
        self.data = data
        self.val_size = val_size
        self.test_size = test_size
        self.batch_size = batch_size
        self.seed = seed
        self.train_data = None
        self.val_data = None
        self.test_data = None
        
    def create_splits(self) -> Tuple[Dataset, Dataset, Dataset]:
        """Create train/validation/test splits"""
        # First split into train and temp
        train_data, temp_data = train_test_split(
            self.data,
            test_size=(self.val_size + self.test_size),
            random_state=self.seed
        )
        
        # Split temp into validation and test
        relative_test_size = self.test_size / (self.val_size + self.test_size)
        val_data, test_data = train_test_split(
            temp_data,
            test_size=relative_test_size,
            random_state=self.seed
        )
        
        # Convert to HF datasets
        self.train_data = Dataset.from_pandas(train_data)
        self.val_data = Dataset.from_pandas(val_data)
        self.test_data = Dataset.from_pandas(test_data)
        
        return self.train_data, self.val_data, self.test_data
    
    def get_dataloaders(self) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """Create PyTorch DataLoaders"""
        if any(x is None for x in [self.train_data, self.val_data, self.test_data]):
            self.create_splits()
            
        train_loader = DataLoader(
            self.train_data,
            batch_size=self.batch_size,
            shuffle=True
        )
        
        val_loader = DataLoader(
            self.val_data,
            batch_size=self.batch_size,
            shuffle=False
        )
        
        test_loader = DataLoader(
            self.test_data,
            batch_size=self.batch_size,
            shuffle=False
        )
        
        return train_loader, val_loader, test_loader