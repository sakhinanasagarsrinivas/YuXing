# File: scripts/prepare_data.py
import os
import shutil
from pathlib import Path
import random
from typing import List, Tuple

def split_dataset(
    data_dir: str,
    train_ratio: float = 0.7,
    val_ratio: float = 0.15,
    test_ratio: float = 0.15
) -> Tuple[List[str], List[str], List[str]]:
    """
    Split the dataset into train/val/test sets and save split files
    """
    assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 1e-5
    
    data_dir = Path(data_dir)
    image_files = [f for f in os.listdir(data_dir) if f.endswith(('.jpg', '.png', '.tif'))]
    random.shuffle(image_files)
    
    n = len(image_files)
    train_size = int(n * train_ratio)
    val_size = int(n * val_ratio)
    
    train_files = image_files[:train_size]
    val_files = image_files[train_size:train_size + val_size]
    test_files = image_files[train_size + val_size:]
    
    # Save split files
    for split, files in [
        ('train', train_files),
        ('val', val_files),
        ('test', test_files)
    ]:
        with open(data_dir / f"{split}_images.txt", 'w') as f:
            f.write('\n'.join(files))
            
    return train_files, val_files, test_files

def prepare_sem_dataset(
    raw_data_dir: str,
    processed_data_dir: str,
    api_key: str
):
    """
    Prepare the SEM dataset by:
    1. Organizing images
    2. Generating instruction data using GPT-4
    3. Creating train/val/test splits
    """
    processed_data_dir = Path(processed_data_dir)
    
    # Create directory structure
    image_dir = processed_data_dir / "images"
    instruction_dir = processed_data_dir / "instructions"
    
    for d in [image_dir, instruction_dir]:
        d.mkdir(parents=True, exist_ok=True)
    
    # Copy images to processed directory
    raw_data_dir = Path(raw_data_dir)
    for img_file in raw_data_dir.glob("*.[jp][pn][g]"):
        shutil.copy2(img_file, image_dir)
    
    # Split dataset
    train_files, val_files, test_files = split_dataset(image_dir)
    
    # Generate instruction data
    instruction_generator = GPT4InstructionGenerator(
        api_key=api_key,
        save_dir=instruction_dir
    )
    
    for img_file in image_dir.glob("*.[jp][pn][g]"):
        instruction_generator.generate_and_save(str(img_file))

if __name__ == "__main__":
    # Example usage
    prepare_sem_dataset(
        raw_data_dir="path/to/raw/sem/images",
        processed_data_dir="path/to/processed/data",
        api_key="your-api-key"
    )