
# Directory structure:
# mvaema/
#   ├── config/
#   │   └── config.py
#   ├── models/
#   │   ├── __init__.py
#   │   ├── encoders.py
#   │   ├── decoder.py
#   │   └── mvaema.py
#   ├── losses/
#   │   ├── __init__.py
#   │   └── losses.py
#   ├── metrics/
#   │   ├── __init__.py
#   │   └── metrics.py
#   └── train.py

# File: mvaema/config/config.py
from dataclasses import dataclass

@dataclass
class ModelConfig:
    """Configuration for MVaEMa model as specified in the paper"""
    # Model architecture
    hidden_dim: int = 64  # Hidden dimension size
    num_heads: int = 4    # Number of attention heads
    num_layers: int = 6   # Number of transformer layers
    dropout: float = 0.1  # Dropout rate
    
    # Image settings
    image_size: int = 224  # Input image size
    patch_size: int = 32   # Patch size for image tokenization
    num_channels: int = 3  # Number of image channels
    
    # Text settings
    max_seq_length: int = 512  # Maximum sequence length
    vocab_size: int = 30522    # Vocabulary size (BERT)
    
    # Training settings
    batch_size: int = 48        # From paper
    learning_rate: float = 1e-3  # From paper
    weight_decay: float = 0.01
    warmup_steps: int = 1000
    max_epochs: int = 50
    
    # Loss settings
    temperature: float = 0.25  # Temperature for contrastive loss
    itc_weight: float = 1.0    # Weight for ITC loss
    itm_weight: float = 1.0    # Weight for ITM loss
    lm_weight: float = 1.0     # Weight for LM loss


