# File: mvaema/evaluate.py

import torch
import torch.nn.functional as F
from tqdm import tqdm
import json
import pandas as pd
from pathlib import Path
from typing import Dict, List, Tuple
import logging
from torchmetrics.text import BLEUScore, ROUGEScore
from nltk.translate.meteor_score import meteor_score
import nltk
import numpy as np

class Evaluator:
    """
    Evaluation class implementing all metrics from the paper:
    - BLEU-2 and BLEU-4
    - ROUGE-1, ROUGE-2, and ROUGE-L
    - METEOR
    Also computes detailed analysis per category.
    """
    def __init__(self, model, test_loader, config, device, save_dir="results"):
        self.model = model
        self.test_loader = test_loader
        self.config = config
        self.device = device
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize metrics
        self.bleu2 = BLEUScore(n_gram=2)
        self.bleu4 = BLEUScore(n_gram=4)
        self.rouge = ROUGEScore()
        
        # Download NLTK data for METEOR
        nltk.download('wordnet')
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(self.save_dir / 'evaluation.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    @torch.no_grad()
    def evaluate(self) -> Dict:
        """
        Full evaluation on test set with all metrics from paper
        """
        self.model.eval()
        
        all_predictions = []
        all_references = []
        all_categories = []
        all_metrics = {}
        
        # Evaluate all test samples
        for batch in tqdm(self.test_loader, desc="Evaluating"):
            # Move batch to device
            batch = {k: v.to(self.device) if torch.is_tensor(v) else v 
                    for k, v in batch.items()}
            
            # Get model predictions
            outputs = self.model(batch)
            predictions = self.decode_predictions(outputs['logits'])
            
            # Store results
            all_predictions.extend(predictions)
            all_references.extend(batch['text'])
            all_categories.extend(batch['category'])

        # Compute overall metrics
        metrics = self.compute_metrics(all_predictions, all_references)
        
        # Compute per-category metrics
        category_metrics = self.compute_category_metrics(
            all_predictions, 
            all_references, 
            all_categories
        )
        
        # Save detailed results
        self.save_results(
            all_predictions, 
            all_references, 
            all_categories,
            metrics,
            category_metrics
        )
        
        return metrics, category_metrics

    def compute_metrics(self, predictions: List[str], references: List[str]) -> Dict:
        """
        Compute all metrics following paper's evaluation
        """
        metrics = {}
        
        # BLEU scores
        metrics['bleu2'] = self.bleu2(predictions, references)
        metrics['bleu4'] = self.bleu4(predictions, references)
        
        # ROUGE scores
        rouge_scores = self.rouge(predictions, references)
        metrics.update({
            'rouge1': rouge_scores['rouge1_fmeasure'],
            'rouge2': rouge_scores['rouge2_fmeasure'],
            'rougeL': rouge_scores['rougeL_fmeasure']
        })
        
        # METEOR score
        meteor_scores = [
            meteor_score([ref], pred) 
            for pred, ref in zip(predictions, references)
        ]
        metrics['meteor'] = np.mean(meteor_scores)
        
        return metrics

    def compute_category_metrics(
        self, 
        predictions: List[str], 
        references: List[str], 
        categories: List[str]
    ) -> Dict:
        """
        Compute metrics for each category separately
        """
        unique_categories = sorted(set(categories))
        category_metrics = {}
        
        for category in unique_categories:
            # Get indices for this category
            indices = [i for i, cat in enumerate(categories) if cat == category]
            
            # Get predictions and references for this category
            cat_predictions = [predictions[i] for i in indices]
            cat_references = [references[i] for i in indices]
            
            # Compute metrics for this category
            metrics = self.compute_metrics(cat_predictions, cat_references)
            category_metrics[category] = metrics
            
        return category_metrics

    def save_results(
        self,
        predictions: List[str],
        references: List[str],
        categories: List[str],
        metrics: Dict,
        category_metrics: Dict
    ):
        """
        Save all evaluation results
        """
        # Save detailed predictions
        results_df = pd.DataFrame({
            'category': categories,
            'prediction': predictions,
            'reference': references
        })
        results_df.to_csv(self.save_dir / 'predictions.csv', index=False)
        
        # Save metrics
        with open(self.save_dir / 'metrics.json', 'w') as f:
            json.dump({
                'overall_metrics': metrics,
                'category_metrics': category_metrics
            }, f, indent=2)
        
        # Log results
        self.logger.info("Overall Metrics:")
        for k, v in metrics.items():
            self.logger.info(f"{k}: {v:.4f}")
        
        self.logger.info("\nCategory-wise Metrics:")
        for category, cat_metrics in category_metrics.items():
            self.logger.info(f"\n{category}:")
            for k, v in cat_metrics.items():
                self.logger.info(f"{k}: {v:.4f}")

    def decode_predictions(self, logits: torch.Tensor) -> List[str]:
        """
        Convert model logits to text predictions
        """
        predictions = logits.argmax(dim=-1)
        return self.tokenizer.batch_decode(predictions, skip_special_tokens=True)

# File: mvaema/evaluate_examples.py

def evaluate_specific_examples(model, examples: List[Dict], save_dir: str):
    """
    Evaluate model on specific examples and generate visualizations
    as shown in Table 7 of the paper
    """
    save_dir = Path(save_dir)
    save_dir.mkdir(exist_ok=True)
    
    results = []
    for example in examples:
        # Prepare input
        inputs = prepare_example_input(example)
        
        # Get model prediction
        with torch.no_grad():
            outputs = model(inputs)
            prediction = decode_prediction(outputs)
        
        # Compute metrics for this example
        metrics = compute_example_metrics(prediction, example['reference'])
        
        results.append({
            'image_path': example['image_path'],
            'ground_truth': example['reference'],
            'prediction': prediction,
            'metrics': metrics
        })
    
    # Save results in format similar to paper's Table 7
    save_example_results(results, save_dir)

# File: scripts/run_evaluation.py

def main():
    """
    Main evaluation script
    """
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=str, required=True)
    parser.add_argument('--config', type=str, required=True)
    parser.add_argument('--output_dir', type=str, default='evaluation_results')
    args = parser.parse_args()
    
    # Load config and model
    config = ModelConfig.from_json(args.config)
    model = load_model(config, args.checkpoint)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = model.to(device)
    
    # Create test dataloader
    test_loader = create_test_dataloader(config)
    
    # Create evaluator
    evaluator = Evaluator(
        model=model,
        test_loader=test_loader,
        config=config,
        device=device,
        save_dir=args.output_dir
    )
    
    # Run evaluation
    metrics, category_metrics = evaluator.evaluate()
    
    # Evaluate specific examples (as in paper Table 7)
    example_cases = load_example_cases()
    evaluate_specific_examples(
        model=model,
        examples=example_cases,
        save_dir=Path(args.output_dir) / 'example_cases'
    )

if __name__ == "__main__":
    main()