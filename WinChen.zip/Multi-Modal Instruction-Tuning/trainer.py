# File: mvaema/train.py
import torch
from torch.cuda.amp import autocast, GradScaler
from tqdm import tqdm
import logging
import wandb
import os
from pathlib import Path
import numpy as np
from typing import Dict, Any

class Trainer:
    def __init__(
        self,
        model: torch.nn.Module,
        criterion: MVaEMaLoss,
        optimizer: torch.optim.Optimizer,
        config: ModelConfig,
        train_loader: torch.utils.data.DataLoader,
        val_loader: torch.utils.data.DataLoader,
        metrics: MVaEMaMetrics,
        device: torch.device,
        checkpoint_dir: str = "checkpoints"
    ):
        self.model = model
        self.criterion = criterion
        self.optimizer = optimizer
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.metrics = metrics
        self.device = device
        self.checkpoint_dir = Path(checkpoint_dir)
        self.checkpoint_dir.mkdir(exist_ok=True)
        
        # Initialize automatic mixed precision
        self.scaler = GradScaler()
        
        # Learning rate scheduler (as mentioned in paper)
        self.scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            factor=0.5,
            patience=5,
            verbose=True
        )
        
        # Initialize logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        self.logger = logging.getLogger(__name__)

    def train_epoch(self) -> Dict[str, float]:
        """Train for one epoch"""
        self.model.train()
        epoch_losses = {
            'total_loss': 0.0,
            'itc_loss': 0.0,
            'itm_loss': 0.0,
            'lm_loss': 0.0
        }
        
        pbar = tqdm(self.train_loader, desc='Training')
        for batch in pbar:
            # Move batch to device
            batch = {k: v.to(self.device) if torch.is_tensor(v) else v 
                    for k, v in batch.items()}
            
            # Zero gradients
            self.optimizer.zero_grad()
            
            # Forward pass with automatic mixed precision
            with autocast():
                outputs = self.model(batch)
                losses = self.criterion(outputs, batch)
            
            # Backward pass with gradient scaling
            self.scaler.scale(losses['loss']).backward()
            self.scaler.step(self.optimizer)
            self.scaler.update()
            
            # Update running losses
            for k, v in losses.items():
                epoch_losses[k] += v.item()
            
            # Update progress bar
            pbar.set_postfix({
                k: f"{v/len(pbar):.4f}" 
                for k, v in epoch_losses.items()
            })
        
        # Compute average losses
        epoch_losses = {
            k: v/len(self.train_loader) 
            for k, v in epoch_losses.items()
        }
        
        return epoch_losses

    @torch.no_grad()
    def validate(self) -> Dict[str, float]:
        """Validate the model"""
        self.model.eval()
        val_losses = {
            'total_loss': 0.0,
            'itc_loss': 0.0,
            'itm_loss': 0.0,
            'lm_loss': 0.0
        }
        all_predictions = []
        all_references = []
        
        pbar = tqdm(self.val_loader, desc='Validation')
        for batch in pbar:
            # Move batch to device
            batch = {k: v.to(self.device) if torch.is_tensor(v) else v 
                    for k, v in batch.items()}
            
            # Forward pass
            outputs = self.model(batch)
            losses = self.criterion(outputs, batch)
            
            # Update running losses
            for k, v in losses.items():
                val_losses[k] += v.item()
            
            # Generate predictions for metrics
            predictions = self.generate_text(outputs['logits'])
            all_predictions.extend(predictions)
            all_references.extend(batch['text'])
            
            # Update progress bar
            pbar.set_postfix({
                k: f"{v/len(pbar):.4f}" 
                for k, v in val_losses.items()
            })
        
        # Compute average losses
        val_losses = {
            k: v/len(self.val_loader) 
            for k, v in val_losses.items()
        }
        
        # Compute metrics
        metrics = self.metrics.compute_all(all_predictions, all_references)
        val_losses.update(metrics)
        
        return val_losses

    def generate_text(self, logits: torch.Tensor) -> List[str]:
        """Generate text from logits"""
        predictions = logits.argmax(dim=-1)
        return self.tokenizer.batch_decode(predictions, skip_special_tokens=True)

    def save_checkpoint(self, epoch: int, val_loss: float, is_best: bool = False):
        """Save model checkpoint"""
        checkpoint = {
            'epoch': epoch,
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'val_loss': val_loss,
            'config': self.config
        }
        
        # Save latest checkpoint
        torch.save(
            checkpoint,
            self.checkpoint_dir / 'latest_checkpoint.pt'
        )
        
        # Save best checkpoint
        if is_best:
            torch.save(
                checkpoint,
                self.checkpoint_dir / 'best_checkpoint.pt'
            )

    def load_checkpoint(self, checkpoint_path: str):
        """Load model checkpoint"""
        checkpoint = torch.load(checkpoint_path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        return checkpoint['epoch'], checkpoint['val_loss']

    def train(self, num_epochs: int):
        """Full training loop"""
        best_val_loss = float('inf')
        
        for epoch in range(num_epochs):
            self.logger.info(f"Epoch {epoch+1}/{num_epochs}")
            
            # Training phase
            train_losses = self.train_epoch()
            self.logger.info(
                "Training Losses: " + 
                ", ".join(f"{k}: {v:.4f}" for k, v in train_losses.items())
            )
            
            # Validation phase
            val_losses = self.validate()
            self.logger.info(
                "Validation Losses: " + 
                ", ".join(f"{k}: {v:.4f}" for k, v in val_losses.items())
            )
            
            # Learning rate scheduling
            self.scheduler.step(val_losses['total_loss'])
            
            # Checkpoint saving
            is_best = val_losses['total_loss'] < best_val_loss
            if is_best:
                best_val_loss = val_losses['total_loss']
            
            self.save_checkpoint(
                epoch=epoch,
                val_loss=val_losses['total_loss'],
                is_best=is_best
            )
            
            # Log to wandb if available
            if wandb.run is not None:
                wandb.log({
                    **{f"train/{k}": v for k, v in train_losses.items()},
                    **{f"val/{k}": v for k, v in val_losses.items()},
                    "epoch": epoch,
                    "learning_rate": self.optimizer.param_groups[0]['lr']
                })

def main():
    # Parse arguments
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, required=True)
    args = parser.parse_args()
    
    # Load config
    config = ModelConfig.from_json(args.config)
    
    # Set device
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Initialize wandb
    wandb.init(
        project="mvaema",
        config=vars(config)
    )
    
    # Create model components
    model = MVaEMa(config).to(device)
    criterion = MVaEMaLoss(config)
    optimizer = torch.optim.Adam(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay
    )
    
    # Create data loaders
    train_loader, val_loader = create_dataloaders(config)
    
    # Initialize metrics
    metrics = MVaEMaMetrics()
    
    # Create trainer
    trainer = Trainer(
        model=model,
        criterion=criterion,
        optimizer=optimizer,
        config=config,
        train_loader=train_loader,
        val_loader=val_loader,
        metrics=metrics,
        device=device
    )
    
    # Start training
    trainer.train(num_epochs=config.max_epochs)

if __name__ == "__main__":
    main()