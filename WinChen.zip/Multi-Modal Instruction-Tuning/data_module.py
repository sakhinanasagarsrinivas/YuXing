# File: data/data_module.py
from torch.utils.data import DataLoader
from typing import Dict, Optional
import pytorch_lightning as pl

class SEMDataModule(pl.LightningDataModule):
    def __init__(
        self,
        image_dir: str,
        instruction_dir: str,
        batch_size: int = 48,
        num_workers: int = 4,
        transform: Optional[Dict] = None
    ):
        super().__init__()
        self.image_dir = image_dir
        self.instruction_dir = instruction_dir
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.transform = transform
        
    def setup(self, stage: Optional[str] = None):
        # Create train/val/test datasets
        if stage == 'fit' or stage is None:
            self.train_dataset = SEMDataset(
                self.image_dir,
                self.instruction_dir,
                transform=self.transform,
                split='train'
            )
            
            self.val_dataset = SEMDataset(
                self.image_dir,
                self.instruction_dir,
                transform=self.transform,
                split='val'
            )
            
        if stage == 'test' or stage is None:
            self.test_dataset = SEMDataset(
                self.image_dir,
                self.instruction_dir,
                transform=self.transform,
                split='test'
            )
            
    def train_dataloader(self):
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=True
        )
        
    def val_dataloader(self):
        return DataLoader(
            self.val_dataset,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=False
        )
        
    def test_dataloader(self):
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            num_workers=self.num_workers,
            shuffle=False
        )
