# File: mvaema/losses/losses.py
class MVaEMaLoss:
    """Loss computation following paper equations"""
    def __init__(self, config):
        self.config = config

    def compute_itc_loss(self, image_features, text_features):
        """Image-text contrastive loss"""
        # Normalize features
        image_features = F.normalize(image_features, dim=-1)
        text_features = F.normalize(text_features, dim=-1)
        
        # Compute similarity matrix
        similarity = torch.matmul(image_features, text_features.transpose(-2, -1))
        similarity = similarity / self.config.temperature
        
        # Compute I2T and T2I losses
        labels = torch.arange(similarity.size(0), device=similarity.device)
        i2t_loss = F.cross_entropy(similarity, labels)
        t2i_loss = F.cross_entropy(similarity.t(), labels)
        
        return (i2t_loss + t2i_loss) / 2

    def compute_itm_loss(self, similarity_scores, labels):
        """Image-text matching loss"""
        return F.binary_cross_entropy_with_logits(similarity_scores, labels)

    def compute_lm_loss(self, logits, labels, attention_mask=None):
        """Language modeling loss"""
        if attention_mask is not None:
            active_loss = attention_mask.view(-1) == 1
            active_logits = logits.view(-1, logits.size(-1))[active_loss]
            active_labels = labels.view(-1)[active_loss]
            loss = F.cross_entropy(active_logits, active_labels)
        else:
            loss = F.cross_entropy(logits.view(-1, logits.size(-1)), labels.view(-1))
        
        return loss

    def __call__(self, outputs, batch):
        """Combined loss computation"""
        itc_loss = self.compute_itc_loss(
            outputs['image_features'],
            outputs['text_features']
        )
        
        itm_loss = self.compute_itm_loss(
            outputs['similarity_scores'],
            batch['labels']
        )
        
        lm_loss = self.compute_lm_loss(
            outputs['logits'],
            batch['labels'],
            batch['attention_mask']
        )
        
        # Combine losses with weights from config
        total_loss = (
            self.config.itc_weight * itc_loss +
            self.config.itm_weight * itm_loss +
            self.config.lm_weight * lm_loss
        )
        
        return {
            'loss': total_loss,
            'itc_loss': itc_loss,
            'itm_loss': itm_loss,
            'lm_loss': lm_loss
        }



