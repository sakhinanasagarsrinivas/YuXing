from torchmetrics import Metric
from torchmetrics.text import BLEUScore, ROUGEScore
from typing import List, Dict

class MVaEMaMetrics:
    """Evaluation metrics from paper"""
    def __init__(self):
        self.bleu2 = BLEUScore(n_gram=2)
        self.bleu4 = BLEUScore(n_gram=4)
        self.rouge = ROUGEScore()
        self.meteor = MeteorScore()  # Custom implementation needed

    def compute_all(self, predictions: List[str], references: List[str]) -> Dict[str, float]:
        """Compute all metrics"""
        results = {}
        
        # BLEU scores
        results['bleu2'] = self.bleu2(predictions, references)
        results['bleu4'] = self.bleu4(predictions, references)
        
        # ROUGE scores
        rouge_results = self.rouge(predictions, references)
        results.update({
            'rouge1': rouge_results['rouge1_fmeasure'],
            'rouge2': rouge_results['rouge2_fmeasure'],
            'rougeL': rouge_results['rougeL_fmeasure']
        })
        
        # METEOR score
        results['meteor'] = self.meteor(predictions, references)
        
        return results