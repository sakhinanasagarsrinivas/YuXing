# File: data/sem_dataset.py
import os
import json
import torch
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms
from PIL import Image
from typing import Dict, List, Optional
from pathlib import Path

class SEMDataset(Dataset):
    """
    Dataset class for SEM images and their instruction-response pairs
    """
    def __init__(
        self,
        image_dir: str,
        instruction_dir: str,
        transform: Optional[transforms.Compose] = None,
        split: str = 'train'
    ):
        self.image_dir = Path(image_dir)
        self.instruction_dir = Path(instruction_dir)
        self.split = split
        
        # Default transform if none provided
        if transform is None:
            self.transform = transforms.Compose([
                transforms.Resize((224, 224)),
                transforms.ToTensor(),
                transforms.Normalize(mean=[0.5, 0.5, 0.5], std=[0.5, 0.5, 0.5])
            ])
        else:
            self.transform = transform
            
        # Load split information
        split_file = self.image_dir / f"{split}_images.txt"
        with open(split_file, 'r') as f:
            self.image_files = [line.strip() for line in f.readlines()]
            
        # Load all instruction data
        self.instruction_data = {}
        for img_file in self.image_files:
            instruction_file = self.instruction_dir / f"{Path(img_file).stem}_instructions.json"
            if instruction_file.exists():
                with open(instruction_file, 'r') as f:
                    self.instruction_data[img_file] = json.load(f)
                    
    def __len__(self):
        return len(self.image_files)
        
    def __getitem__(self, idx):
        img_file = self.image_files[idx]
        img_path = self.image_dir / img_file
        
        # Load and transform image
        image = Image.open(img_path).convert('RGB')
        image = self.transform(image)
        
        # Get instruction data
        instructions = self.instruction_data[img_file]
        
        return {
            'image': image,
            'instructions': instructions,
            'image_path': str(img_path)
        }
