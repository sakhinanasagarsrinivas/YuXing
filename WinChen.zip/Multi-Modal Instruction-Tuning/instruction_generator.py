# File: data/instruction_generator.py
import os
import json
import openai
from typing import List, Dict
from pathlib import Path

class GPT4InstructionGenerator:
    def __init__(self, api_key: str, save_dir: str):
        """
        Initialize GPT-4 instruction generator with API key and directory to save generated data.
        
        Args:
            api_key: OpenAI API key
            save_dir: Directory to save generated instruction data
        """
        openai.api_key = api_key
        self.save_dir = Path(save_dir)
        self.save_dir.mkdir(parents=True, exist_ok=True)
        
        # All prompts from the paper
        self.prompt_templates = [
            "**Basics** - This image depicts a nanomaterial. Identify the specific type of nanomaterial depicted in the image? Additionally, find image scale: real-world length per unit measurement?",
            "**Morphology and Structure** - Describe the overall shape and morphology of the nanomaterials? Identify any visible layers, phases, or distinct domains? Assess consistency in size and shape, or note any variability?",
            "**Size and Distribution** - Estimate size/size range of nanostructures? Describe distribution - evenly spaced, clustered, or random? Comment on any aggregation or bundling visible?",
            "**Surface Characteristics** - Describe surface textures - smooth, rough, distinct textures? Comment on any visible imperfections like defects, pores, or impurities?",
            "**Composition and Elements** - Note any visible evidence of compositional variations? Identify any labels or markers pointing to specific elements/compounds?",
            "**Interactions and Boundaries** - Describe visual interactions: touching, fused, or separate? Can you distinguish boundaries between structures/phases?",
            "**External Environment** - Note any visible signs of interaction between nanomaterials and surroundings? Identify and describe any non-nanomaterial structures/objects present?",
            "**Image Technique and Modifications** - Identify imaging technique used? Note any visible post-processing or modifications?",
            "**Functional Features** - Identify any visible functional elements or regions with distinct properties? Note if the image shows any dynamic processes?",
            "**Context and Application** - Identify intended use/application of nanomaterials. Are they experimental samples or theoretical representations?"
        ]

    def generate_and_save(self, image_path: str) -> str:
        """
        Generate instruction data for an image and save it to JSON file.
        
        Args:
            image_path: Path to the SEM image
            
        Returns:
            Path to saved JSON file
        """
        # Generate unique filename for this image's instruction data
        save_name = Path(image_path).stem + "_instructions.json"
        save_path = self.save_dir / save_name
        
        # Check if instructions already exist
        if save_path.exists():
            print(f"Instructions already exist for {image_path}")
            return str(save_path)
        
        instruction_data = []
        for prompt in self.prompt_templates:
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-4-vision-preview",
                    messages=[
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": prompt},
                                {"type": "image_url", "image_url": f"file://{image_path}"}
                            ]
                        }
                    ],
                    max_tokens=3500,
                    temperature=0.25,
                    top_p=0.1
                )
                
                instruction_data.append({
                    "image_path": image_path,
                    "instruction": prompt,
                    "response": response.choices[0].message.content
                })
                
            except Exception as e:
                print(f"Error generating instruction for {image_path}: {e}")
        
        # Save to JSON file
        with open(save_path, 'w') as f:
            json.dump(instruction_data, f, indent=2)
            
        return str(save_path)



