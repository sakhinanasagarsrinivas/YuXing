# File: mvaema/models/encoders.py
import torch
import torch.nn as nn
import math

class PatchEmbed(nn.Module):
    """Image to Patch Embedding as described in paper"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Patch embedding projection
        self.proj = nn.Conv2d(
            config.num_channels,
            config.hidden_dim,
            kernel_size=config.patch_size,
            stride=config.patch_size
        )
        
        # Calculate number of patches
        self.num_patches = (config.image_size // config.patch_size) ** 2
        
        # CLS token and position embedding
        self.cls_token = nn.Parameter(torch.zeros(1, 1, config.hidden_dim))
        self.pos_embed = nn.Parameter(torch.zeros(1, self.num_patches + 1, config.hidden_dim))
        
        # Initialize parameters
        nn.init.normal_(self.cls_token, std=0.02)
        nn.init.normal_(self.pos_embed, std=0.02)

    def forward(self, x):
        B = x.shape[0]
        
        # Create patches
        x = self.proj(x)  # (B, C, H/P, W/P)
        x = x.flatten(2).transpose(1, 2)  # (B, N, D)
        
        # Add CLS token
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        
        # Add position embeddings
        x = x + self.pos_embed
        
        return x

class ImageEncoder(nn.Module):
    """Instruction-aware image encoder with self-attention"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Patch embedding
        self.patch_embed = PatchEmbed(config)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hidden_dim,
            nhead=config.num_heads,
            dim_feedforward=config.hidden_dim * 4,
            dropout=config.dropout,
            batch_first=True
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer, 
            num_layers=config.num_layers
        )
        
        self.norm = nn.LayerNorm(config.hidden_dim)

    def forward(self, x):
        # Patch embedding
        x = self.patch_embed(x)
        
        # Transformer encoder
        x = self.encoder(x)
        x = self.norm(x)
        
        return x

class TextEncoder(nn.Module):
    """Bidirectional self-attention text encoder"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Text embedding
        self.embedding = nn.Embedding(config.vocab_size, config.hidden_dim)
        self.pos_encoder = PositionalEncoding(config.hidden_dim, config.dropout)
        
        # Transformer encoder
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=config.hidden_dim,
            nhead=config.num_heads,
            dim_feedforward=config.hidden_dim * 4,
            dropout=config.dropout,
            batch_first=True
        )
        self.encoder = nn.TransformerEncoder(
            encoder_layer,
            num_layers=config.num_layers
        )
        
        self.norm = nn.LayerNorm(config.hidden_dim)

    def forward(self, x, attention_mask=None):
        # Embedding
        x = self.embedding(x)
        x = self.pos_encoder(x)
        
        # Create attention mask
        if attention_mask is not None:
            attention_mask = attention_mask.unsqueeze(1).unsqueeze(2)
            attention_mask = (1.0 - attention_mask) * -10000.0
        
        # Transformer encoder
        x = self.encoder(x, src_key_padding_mask=attention_mask)
        x = self.norm(x)
        
        return x

class PositionalEncoding(nn.Module):
    """Positional encoding for text"""
    def __init__(self, d_model, dropout=0.1, max_len=5000):
        super().__init__()
        self.dropout = nn.Dropout(p=dropout)

        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        pe = pe.unsqueeze(0)
        self.register_buffer('pe', pe)

    def forward(self, x):
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)

# File: mvaema/models/decoder.py
class ImageGroundedDecoder(nn.Module):
    """Image-grounded text decoder with causal attention"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Transformer decoder
        decoder_layer = nn.TransformerDecoderLayer(
            d_model=config.hidden_dim,
            nhead=config.num_heads,
            dim_feedforward=config.hidden_dim * 4,
            dropout=config.dropout,
            batch_first=True
        )
        self.decoder = nn.TransformerDecoder(
            decoder_layer,
            num_layers=config.num_layers
        )
        
        # Output projection
        self.output_projection = nn.Linear(config.hidden_dim, config.vocab_size)

    def forward(self, tgt, memory, tgt_mask=None):
        # Transformer decoder
        x = self.decoder(tgt, memory, tgt_mask=tgt_mask)
        
        # Project to vocabulary
        x = self.output_projection(x)
        
        return x

    def generate_square_subsequent_mask(self, sz):
        """Generate causal mask for decoder"""
        mask = (torch.triu(torch.ones(sz, sz)) == 1).transpose(0, 1)
        mask = mask.float().masked_fill(mask == 0, float('-inf')).masked_fill(mask == 1, float(0.0))
        return mask

# File: mvaema/models/mvaema.py
class MVaEMa(nn.Module):
    """Complete MVaEMa architecture"""
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Main components
        self.image_encoder = ImageEncoder(config)
        self.text_encoder = TextEncoder(config)
        self.decoder = ImageGroundedDecoder(config)
        
        # Cross attention for grounding
        self.cross_attention = nn.MultiheadAttention(
            embed_dim=config.hidden_dim,
            num_heads=config.num_heads,
            dropout=config.dropout,
            batch_first=True
        )
        
        # Layernorms
        self.norm1 = nn.LayerNorm(config.hidden_dim)
        self.norm2 = nn.LayerNorm(config.hidden_dim)

    def forward(self, batch):
        # Encode image
        image_features = self.image_encoder(batch['image'])
        
        # Encode text
        text_features = self.text_encoder(
            batch['input_ids'],
            batch['attention_mask']
        )
        
        # Cross attention for grounding
        grounded_features, _ = self.cross_attention(
            query=text_features,
            key=image_features,
            value=image_features
        )
        grounded_features = self.norm1(grounded_features + text_features)
        
        # Decode
        tgt_mask = self.decoder.generate_square_subsequent_mask(
            batch['decoder_input_ids'].size(1)
        ).to(batch['decoder_input_ids'].device)
        
        output = self.decoder(
            batch['decoder_input_ids'],
            grounded_features,
            tgt_mask=tgt_mask
        )
        
        return {
            'logits': output,
            'image_features': image_features[:, 0],  # CLS token
            'text_features': text_features[:, 0],    # CLS token
            'grounded_features': grounded_features
        }

