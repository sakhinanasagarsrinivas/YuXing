# utils/metrics.py

import torch
import numpy as np

class Metrics:
    """
    Evaluation metrics as used in paper:
    MAE, RMSE, and MAPE
    """
    @staticmethod
    def MAE(pred: torch.Tensor, true: torch.Tensor) -> float:
        """Mean Absolute Error"""
        return torch.mean(torch.abs(pred - true)).item()
    
    @staticmethod
    def RMSE(pred: torch.Tensor, true: torch.Tensor) -> float:
        """Root Mean Square Error"""
        return torch.sqrt(torch.mean((pred - true) ** 2)).item()
    
    @staticmethod
    def MAPE(pred: torch.Tensor, true: torch.Tensor) -> float:
        """Mean Absolute Percentage Error"""
        return torch.mean(torch.abs((pred - true) / true)) * 100