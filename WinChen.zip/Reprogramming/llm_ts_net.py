# models/llm_ts_net.py

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer
from lora_amr import LoRAAMR
from dynamic_prompting import DynamicPromptPool
from intra_series import IntraSeriesAttention
from inter_series import InterSeriesAttention
from cross_modal import CrossModalFusion

class LLMTSNet(nn.Module):
    """
    Complete LLM-TS Net implementation following paper architecture
    """
    def __init__(self, config):
        super().__init__()
        
        # Initialize large LLM (Llama2-70B) for generating descriptions
        self.large_llm_tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-70b-hf")
        self.large_llm = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-70b-hf")
        
        # Initialize small LLM (Llama2-7B) with LoRA-AMR for fine-tuning
        self.small_llm_tokenizer = AutoTokenizer.from_pretrained("meta-llama/Llama-2-7b-hf")
        self.small_llm = AutoModelForCausalLM.from_pretrained("meta-llama/Llama-2-7b-hf")
        
        # Add LoRA-AMR to small LLM
        self.lora_amr = LoRAAMR(
            base_model=self.small_llm,
            rank=config.rank,
            alpha=config.lora_alpha
        )
        
        # Other components
        self.dynamic_prompting = DynamicPromptPool(
            M=config.num_prompts,
            d=config.hidden_size,
            W=config.window_size
        )
        
        self.intra_series = IntraSeriesAttention(
            d=config.hidden_size,
            H=config.num_heads,
            G=config.num_groups
        )
        
        self.inter_series = InterSeriesAttention(
            d=config.hidden_size,
            H=config.num_heads,
            G=config.num_groups
        )
        
        self.cross_modal = CrossModalFusion(
            d_model=config.hidden_size,
            num_heads=config.num_heads
        )
        
        self.output_projection = nn.Linear(config.hidden_size, config.output_size)

    def generate_descriptions(self, time_series):
        """Generate technical descriptions using Llama2-70B"""
        prompt = self._create_analysis_prompt(time_series)
        inputs = self.large_llm_tokenizer(prompt, return_tensors="pt", truncation=True)
        
        with torch.no_grad():
            outputs = self.large_llm.generate(
                inputs.input_ids,
                max_length=512,
                temperature=0.7
            )
        
        return self.large_llm_tokenizer.decode(outputs[0])

    def _create_analysis_prompt(self, time_series):
        """Create prompt for time series analysis"""
        return f"""Analyze this time series data and provide a technical description 
        focusing on main trends, patterns, seasonality, and anomalies:
        Time Series Data: {time_series.tolist()}
        Technical Description:"""

    def get_text_embeddings(self, descriptions):
        """Get embeddings from fine-tuned Llama2-7B with LoRA-AMR"""
        inputs = self.small_llm_tokenizer(descriptions, return_tensors="pt", padding=True)
        base_outputs = self.small_llm(**inputs).last_hidden_state
        
        # Apply LoRA-AMR adaptation
        adapted_embeddings = self.lora_amr(base_outputs)
        return adapted_embeddings

    def forward(self, x):
        """
        Forward pass implementing the joint optimization of three methods as described in paper:
        1. Dynamic prompting with intra/inter dependencies
        2. LLM-based trend analysis
        3. Cross-modal integration
        """
        batch_size = x.size(0)
        
        # 1. Generate descriptions using large LLM
        descriptions = []
        for i in range(batch_size):
            desc = self.generate_descriptions(x[i])
            descriptions.append(desc)
        
        # 2. Get text embeddings from fine-tuned small LLM
        text_embeddings = self.get_text_embeddings(descriptions)
        
        # 3. Dynamic prompting
        prompted_features = self.dynamic_prompting(x)
        
        # 4. Intra-series dependencies
        intra_features = self.intra_series(prompted_features)
        
        # 5. Inter-series dependencies
        inter_features = self.inter_series(intra_features)
        
        # 6. Cross-modal integration
        fused_features = self.cross_modal(text_embeddings, inter_features)
        
        # 7. Final prediction
        return self.output_projection(fused_features)