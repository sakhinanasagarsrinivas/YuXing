# data/data_loader.py

import torch
from torch.utils.data import Dataset, DataLoader
import pandas as pd

class TimeSeriesDataset(Dataset):
    """Dataset class for spatio-temporal MTS data"""
    def __init__(self, X: torch.Tensor, window_size: int, horizon: int):
        """
        Args:
            X: Input tensor of shape [N×T×F]
            window_size: Size of sliding window (W in paper)
            horizon: Prediction horizon (ν in paper)
        """
        self.X = X
        self.window_size = window_size
        self.horizon = horizon
        
    def __len__(self):
        return len(self.X) - self.window_size - self.horizon + 1
        
    def __getitem__(self, idx):
        # Sliding window approach as described in paper
        x = self.X[idx:idx + self.window_size]
        y = self.X[idx + self.window_size:idx + self.window_size + self.horizon]
        return x, y

def create_data_loaders(config, X):
    """Creates train/val/test DataLoaders"""
    # Split data according to paper's chronological splitting
    train_size = int(len(X) * config.train_ratio)
    val_size = int(len(X) * config.val_ratio)
    
    train_data = TimeSeriesDataset(
        X[:train_size],
        config.window_size,
        config.forecast_horizon
    )
    
    val_data = TimeSeriesDataset(
        X[train_size:train_size + val_size],
        config.window_size,
        config.forecast_horizon
    )
    
    test_data = TimeSeriesDataset(
        X[train_size + val_size:],
        config.window_size,
        config.forecast_horizon
    )
    
    return (
        DataLoader(train_data, batch_size=config.batch_size, shuffle=True),
        DataLoader(val_data, batch_size=config.batch_size),
        DataLoader(test_data, batch_size=config.batch_size)
    )