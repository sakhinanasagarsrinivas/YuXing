# models/cross_modal.py

import torch
import torch.nn as nn

class CrossModalFusion(nn.Module):
    """
    Cross-modal integration using multi-head attention (MHA)
    As described in paper section: Output Layer
    """
    def __init__(self, d_model: int, num_heads: int):
        super().__init__()
        self.attention = nn.MultiheadAttention(
            embed_dim=d_model,
            num_heads=num_heads,
            batch_first=True
        )
        self.norm = nn.LayerNorm(d_model)
        
    def forward(self, Htext: torch.Tensor, St: torch.Tensor) -> torch.Tensor:
        """
        Args:
            Htext: Text-level embeddings [N×W×m×d]
            St: Time series embeddings [N×W×d]
        """
        # Cross-modal attention as described in paper
        fused_features, _ = self.attention(
            query=St,
            key=Htext,
            value=Htext
        )
        
        return self.norm(fused_features + St)  # Residual connection