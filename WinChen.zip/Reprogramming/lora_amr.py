# models/lora_amr.py

import torch
import torch.nn as nn

class LoRAAMR(nn.Module):
    """
    Implementation of Low-Rank Adaptation with Activation Memory Reduction
    As described in paper section: LoRA-AMR
    """
    def __init__(self, d: int, r: int):
        super().__init__()
        # Original weights (frozen)
        self.W0 = nn.Parameter(torch.randn(d, d), requires_grad=False)
        
        # LoRA-AMR components as per paper
        self.B = nn.Parameter(torch.randn(d, r), requires_grad=False)  # Projection-down
        self.D = nn.Parameter(torch.randn(r, r//2), requires_grad=False)  # Second projection-down
        self.C = nn.Parameter(torch.randn(r//2, d))  # Second projection-up (trainable)
        
        # Scaling factor
        self.alpha = r/2
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # Base transformation
        base_output = x @ self.W0
        
        # LoRA-AMR adaptation with reduced memory
        lora_activation = x @ self.B  # First projection
        lora_activation = lora_activation @ self.D  # Second projection
        lora_output = lora_activation @ self.C  # Final projection
        
        return base_output + self.alpha * lora_output