# utils/logger.py

import logging
import os
from datetime import datetime

class Logger:
    """Logging utility for training and evaluation"""
    def __init__(self, name, save_dir):
        self.logger = logging.getLogger(name)
        self.logger.setLevel(logging.INFO)
        
        # Create handlers
        self.file_handler = logging.FileHandler(
            os.path.join(save_dir, f'log_{datetime.now():%Y%m%d_%H%M%S}.txt')
        )
        self.console_handler = logging.StreamHandler()
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        self.file_handler.setFormatter(formatter)
        self.console_handler.setFormatter(formatter)
        
        # Add handlers
        self.logger.addHandler(self.file_handler)
        self.logger.addHandler(self.console_handler)
    
    def info(self, message):
        self.logger.info(message)
    
    def error(self, message):
        self.logger.error(message)