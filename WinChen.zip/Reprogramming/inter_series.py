# models/inter_series.py

import torch
import torch.nn as nn

class InterSeriesAttention(nn.Module):
    """
    Inter-series dependencies modeling using Grouped-query Multi-head Attention
    As described in paper section: Modeling Inter-series dependencies
    """
    def __init__(self, d: int, H: int, G: int):
        super().__init__()
        self.d = d  # Embedding dimension
        self.H = H  # Number of heads
        self.G = G  # Number of groups
        
        # Following paper notation for inter-series attention
        self.Kg = nn.ModuleList([nn.Linear(d, d) for _ in range(G)])
        self.Vg = nn.ModuleList([nn.Linear(d, d) for _ in range(G)])
        self.Qgh = nn.ModuleList([
            nn.ModuleList([nn.Linear(d, d) for _ in range(H)])
            for _ in range(G)
        ])
        
        self.output_layer = nn.Linear(G * H * d, d)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Args:
            x: Input tensor of shape [N×W×d]
        Returns:
            Tensor with inter-series dependencies captured
        """
        N, W, d = x.shape
        outputs = []
        
        for g in range(self.G):
            Kw_g = self.Kg[g](x)  # [N×W×d]
            Vw_g = self.Vg[g](x)  # [N×W×d]
            
            head_outputs = []
            for h in range(self.H):
                Qw_gh = self.Qgh[g][h](x)  # [N×W×d]
                
                # Attention computation as per paper equation
                attention = torch.softmax(
                    torch.matmul(Qw_gh, Kw_g.transpose(-2, -1)) / torch.sqrt(torch.tensor(self.d)),
                    dim=-1
                )
                head_output = torch.matmul(attention, Vw_g)
                head_outputs.append(head_output)
            
            outputs.append(torch.cat(head_outputs, dim=-1))
        
        return self.output_layer(torch.cat(outputs, dim=-1))