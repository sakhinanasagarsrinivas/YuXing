# models/dynamic_prompting.py

import torch
import torch.nn as nn

class DynamicPromptPool(nn.Module):
    """
    Dynamic prompting mechanism with key-value pairs
    As described in paper section: Dynamic Prompting Mechanism Design
    """
    def __init__(self, M: int, d: int, W: int):
        super().__init__()
        # Key-value prompt pool initialization
        self.keys = nn.Parameter(torch.randn(M, d))  # km ∈ Rd
        self.values = nn.Parameter(torch.randn(M, W, d))  # Vm ∈ RW×d
        
        # Score matching components
        self.Wq = nn.Linear(W, d)
        self.Wk = nn.Linear(d, d)
        self.Wv = nn.Linear(d, 1)
        
    def score_matching(self, S: torch.Tensor, k: torch.Tensor) -> torch.Tensor:
        """Implementation of score matching function a(S_i^t, k_m)"""
        query = self.Wq(S)
        key = self.Wk(k)
        score = self.Wv(torch.tanh(query + key))
        return score.squeeze(-1)
        
    def forward(self, S: torch.Tensor, K: int = None) -> torch.Tensor:
        batch_size = S.shape[0]
        
        # Calculate attention scores for all keys
        scores = torch.stack([
            self.score_matching(S, k) for k in self.keys
        ])
        
        # Select top-K prompts
        if K is None:
            K = self.values.shape[0]
            
        _, indices = torch.topk(scores, k=min(K, scores.size(0)), dim=0)
        selected_prompts = self.values[indices]
        
        # Concatenate with input as per paper
        return torch.cat([selected_prompts, S.unsqueeze(1)], dim=1)