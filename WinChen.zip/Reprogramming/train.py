# train.py

import torch
from torch.optim import Adam
from torch.nn import MSELoss
from metrics import Metrics
from logger import Logger

class Trainer:
    def __init__(self, model, config, logger):
        self.model = model
        self.config = config
        self.logger = logger
        self.optimizer = Adam(
            model.parameters(),
            lr=config.learning_rate
        )
        self.criterion = MSELoss()
        self.metrics = Metrics()
        
    def train_epoch(self, train_loader):
        self.model.train()
        total_loss = 0
        
        for batch_x, batch_y in train_loader:
            self.optimizer.zero_grad()
            
            # Forward pass through all components
            predictions = self.model(batch_x)
            loss = self.criterion(predictions, batch_y)
            
            # Backward pass
            loss.backward()
            self.optimizer.step()
            
            total_loss += loss.item()
            
        return total_loss / len(train_loader)
    
    def validate(self, val_loader):
        self.model.eval()
        total_loss = 0
        
        with torch.no_grad():
            for batch_x, batch_y in val_loader:
                predictions = self.model(batch_x)
                loss = self.criterion(predictions, batch_y)
                total_loss += loss.item()
                
        return total_loss / len(val_loader)
    
    def train(self, train_loader, val_loader):
        best_val_loss = float('inf')
        patience_counter = 0
        
        for epoch in range(self.config.num_epochs):
            train_loss = self.train_epoch(train_loader)
            val_loss = self.validate(val_loader)
            
            self.logger.info(
                f'Epoch {epoch}: Train Loss = {train_loss:.4f}, '
                f'Val Loss = {val_loss:.4f}'
            )
            
            # Early stopping
            if val_loss < best_val_loss:
                best_val_loss = val_loss
                patience_counter = 0
                # Save best model
                torch.save(
                    self.model.state_dict(),
                    'best_model.pth'
                )
            else:
                patience_counter += 1
                if patience_counter >= self.config.early_stopping_patience:
                    self.logger.info('Early stopping triggered')
                    break