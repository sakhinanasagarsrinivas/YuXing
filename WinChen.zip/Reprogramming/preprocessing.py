# data/preprocessing.py

import torch
import numpy as np
from sklearn.preprocessing import StandardScaler

class TimeSeriesPreprocessor:
    """Preprocessing for spatio-temporal MTS data"""
    def __init__(self):
        self.scaler = StandardScaler()
        
    def fit_transform(self, data: np.ndarray) -> torch.Tensor:
        """
        Standardize the time series data as mentioned in paper
        Args:
            data: Raw time series data [N×T×F]
        """
        N, T, F = data.shape
        # Reshape and standardize
        reshaped_data = data.reshape(-1, F)
        scaled_data = self.scaler.fit_transform(reshaped_data)
        
        # Reshape back
        return torch.FloatTensor(
            scaled_data.reshape(N, T, F)
        )
        
    def inverse_transform(self, data: torch.Tensor) -> np.ndarray:
        """Convert standardized data back to original scale"""
        return self.scaler.inverse_transform(data.reshape(-1, 1)).reshape(
            data.shape
        )