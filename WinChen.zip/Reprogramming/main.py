# main.py

import torch
from config.config import Config
from llm_ts_net import LLMTSNet
from data_loader import create_data_loaders
from preprocessing import TimeSeriesPreprocessor
from logger import Logger
from train import Trainer

def main():
    # Initialize config and logger
    config = Config()
    logger = Logger('LLM-TS-Net', 'logs')
    
    # Load and preprocess data
    preprocessor = TimeSeriesPreprocessor()
    # Assume data loading from your source
    raw_data = load_your_data()  # Implement based on your data source
    processed_data = preprocessor.fit_transform(raw_data)
    
    # Create data loaders
    train_loader, val_loader, test_loader = create_data_loaders(
        config,
        processed_data
    )
    
    # Initialize model
    model = LLMTSNet(config)
    
    # Initialize trainer and train model
    trainer = Trainer(model, config, logger)
    trainer.train(train_loader, val_loader)
    
    # Evaluate on test set
    model.load_state_dict(torch.load('best_model.pth'))
    test_loss = trainer.validate(test_loader)
    logger.info(f'Test Loss: {test_loss:.4f}')

if __name__ == "__main__":
    main()