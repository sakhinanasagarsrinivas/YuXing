# config/config.py

class Config:
    def __init__(self):
        # LLM Settings
        self.large_llm = "llama2-70B-4k"  # Large-scale LLM for descriptions
        self.small_llm = "llama2-7B-4k"   # Small LLM for fine-tuning
        
        # Model Architecture
        self.hidden_size = 4096  # d in paper
        self.window_size = 12    # W in paper
        self.forecast_horizon = 12  # ν in paper
        self.num_prompts = 15    # M in paper
        self.rank = 16          # r for LoRA-AMR
        self.num_heads = 32     # H in paper
        self.num_groups = 3     # G in paper
        
        # Training Parameters
        self.batch_size = 48
        self.learning_rate = 1e-3
        self.num_epochs = 30
        self.early_stopping_patience = 5
        
        # LoRA-AMR Parameters
        self.lora_alpha = self.rank / 2
        self.lora_dropout = 0.05
        
        # Data Parameters
        self.train_ratio = 0.6
        self.val_ratio = 0.2
        self.test_ratio = 0.2