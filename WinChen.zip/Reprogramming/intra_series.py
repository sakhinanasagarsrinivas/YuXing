# models/intra_series.py

import torch
import torch.nn as nn

class IntraSeriesAttention(nn.Module):
    """
    Intra-series dependencies modeling using Grouped-query Multi-head Attention
    As described in paper section: Modeling Intra-series dependencies
    """
    def __init__(self, d: int, H: int, G: int):
        super().__init__()
        self.d = d  # Embedding dimension
        self.H = H  # Number of heads
        self.G = G  # Number of groups
        
        # Shared key and value projections per group
        self.WK = nn.ModuleList([nn.Linear(d, d) for _ in range(G)])
        self.WV = nn.ModuleList([nn.Linear(d, d) for _ in range(G)])
        
        # Query projections for each head in each group
        self.WQ = nn.ModuleList([
            nn.ModuleList([nn.Linear(d, d) for _ in range(H)])
            for _ in range(G)
        ])
        
        self.output_projection = nn.Linear(G * H * d, d)
        
    def forward(self, x: torch.Tensor) -> torch.Tensor:
        batch_size, seq_len, _ = x.shape
        
        group_outputs = []
        for g in range(self.G):
            # Shared key-value projections for group
            K = self.WK[g](x)
            V = self.WV[g](x)
            
            head_outputs = []
            for h in range(self.H):
                Q = self.WQ[g][h](x)
                
                # Scaled dot-product attention
                scores = torch.matmul(Q, K.transpose(-2, -1)) / torch.sqrt(torch.tensor(self.d))
                attention = torch.softmax(scores, dim=-1)
                head_output = torch.matmul(attention, V)
                head_outputs.append(head_output)
            
            group_outputs.append(torch.cat(head_outputs, dim=-1))
        
        combined = torch.cat(group_outputs, dim=-1)
        return self.output_projection(combined)