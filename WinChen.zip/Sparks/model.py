# models/micrograph_encoder.py
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Tuple, Optional

class PatchEmbedding(nn.Module):
    """Transform images into patch embeddings."""
    
    def __init__(self, 
                 image_size: Tuple[int, int] = (224, 224),
                 patch_size: int = 32,
                 in_channels: int = 1,
                 embed_dim: int = 128):
        """
        Initialize patch embedding layer.
        
        Args:
            image_size (tuple): Input image size (H, W)
            patch_size (int): Size of patches to extract
            in_channels (int): Number of input channels
            embed_dim (int): Embedding dimension
        """
        super().__init__()
        self.image_size = image_size
        self.patch_size = patch_size
        self.in_channels = in_channels
        self.embed_dim = embed_dim
        
        self.n_patches = (image_size[0] // patch_size) * (image_size[1] // patch_size)
        
        # Linear projection
        self.proj = nn.Conv2d(in_channels, embed_dim,
                            kernel_size=patch_size, stride=patch_size)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for patch embedding.
        
        Args:
            x (torch.Tensor): Input image [B, C, H, W]
            
        Returns:
            torch.Tensor: Patch embeddings [B, N, D]
        """
        B, C, H, W = x.shape
        assert H == self.image_size[0] and W == self.image_size[1], \
            f"Input image size ({H}*{W}) doesn't match model ({self.image_size[0]}*{self.image_size[1]})"
        
        # Extract patches and project
        x = self.proj(x)  # [B, E, H', W']
        x = x.flatten(2)  # [B, E, N]
        x = x.transpose(1, 2)  # [B, N, E]
        
        return x

class PositionalEmbedding(nn.Module):
    """Add learnable positional embeddings to patch embeddings."""
    
    def __init__(self, num_patches: int, embed_dim: int, dropout: float = 0.1):
        """
        Initialize positional embeddings.
        
        Args:
            num_patches (int): Number of patches
            embed_dim (int): Embedding dimension
            dropout (float): Dropout rate
        """
        super().__init__()
        self.pos_embed = nn.Parameter(torch.zeros(1, num_patches + 1, embed_dim))
        self.cls_token = nn.Parameter(torch.zeros(1, 1, embed_dim))
        self.dropout = nn.Dropout(p=dropout)
        
        # Initialize positional embeddings
        nn.init.trunc_normal_(self.pos_embed, std=0.02)
        nn.init.trunc_normal_(self.cls_token, std=0.02)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Add positional embeddings to patch embeddings.
        
        Args:
            x (torch.Tensor): Patch embeddings [B, N, D]
            
        Returns:
            torch.Tensor: Embeddings with positions and cls token [B, N+1, D]
        """
        B = x.shape[0]
        cls_tokens = self.cls_token.expand(B, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x = x + self.pos_embed
        return self.dropout(x)

class MultiHeadAttention(nn.Module):
    """Multi-head attention with higher-order attention mechanism."""
    
    def __init__(self, 
                 embed_dim: int,
                 num_heads: int = 4,
                 dropout: float = 0.1,
                 qk_dim: int = 32):
        """
        Initialize multi-head attention.
        
        Args:
            embed_dim (int): Embedding dimension
            num_heads (int): Number of attention heads
            dropout (float): Dropout rate
            qk_dim (int): Dimension of query/key vectors
        """
        super().__init__()
        self.num_heads = num_heads
        self.qk_dim = qk_dim
        self.scale = qk_dim ** -0.5
        
        self.qkv = nn.Linear(embed_dim, 3 * num_heads * qk_dim)
        self.proj = nn.Linear(num_heads * qk_dim, embed_dim)
        self.dropout = nn.Dropout(dropout)

    def forward(self, x: torch.Tensor, mask: Optional[torch.Tensor] = None) -> torch.Tensor:
        """
        Forward pass for multi-head attention.
        
        Args:
            x (torch.Tensor): Input tensor [B, N, D]
            mask (torch.Tensor, optional): Attention mask
            
        Returns:
            torch.Tensor: Attention output [B, N, D]
        """
        B, N, D = x.shape
        
        # Project to queries, keys, values
        qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, self.qk_dim)
        qkv = qkv.permute(2, 0, 3, 1, 4)  # [3, B, H, N, D_h]
        q, k, v = qkv[0], qkv[1], qkv[2]
        
        # Higher-order attention
        attn = torch.matmul(q, k.transpose(-2, -1)) * self.scale  # [B, H, N, N]
        if mask is not None:
            attn = attn.masked_fill(mask == 0, float('-inf'))
            
        # Additional non-linear transformation
        attn = F.softplus(attn)  # Non-linear activation
        attn = F.dropout(attn, p=self.dropout.p, training=self.training)
        
        # Weighted aggregation
        out = torch.matmul(attn, v)  # [B, H, N, D_h]
        out = out.transpose(1, 2).reshape(B, N, -1)  # [B, N, H*D_h]
        out = self.proj(out)
        
        return out

class TransformerEncoder(nn.Module):
    """Transformer encoder for electron micrograph analysis."""
    
    def __init__(self,
                 embed_dim: int = 128,
                 num_layers: int = 12,
                 num_heads: int = 4,
                 mlp_ratio: int = 4,
                 qk_dim: int = 32,
                 dropout: float = 0.1):
        """
        Initialize transformer encoder.
        
        Args:
            embed_dim (int): Embedding dimension
            num_layers (int): Number of transformer layers
            num_heads (int): Number of attention heads
            mlp_ratio (int): Ratio for MLP hidden dimension
            qk_dim (int): Dimension of query/key vectors
            dropout (float): Dropout rate
        """
        super().__init__()
        
        self.layers = nn.ModuleList([
            TransformerEncoderLayer(
                embed_dim=embed_dim,
                num_heads=num_heads,
                mlp_ratio=mlp_ratio,
                qk_dim=qk_dim,
                dropout=dropout
            ) for _ in range(num_layers)
        ])
        
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for transformer encoder.
        
        Args:
            x (torch.Tensor): Input tensor [B, N, D]
            
        Returns:
            torch.Tensor: Encoded features [B, N, D]
        """
        for layer in self.layers:
            x = layer(x)
        return self.norm(x)

class TransformerEncoderLayer(nn.Module):
    """Single transformer encoder layer."""
    
    def __init__(self,
                 embed_dim: int,
                 num_heads: int,
                 mlp_ratio: int,
                 qk_dim: int,
                 dropout: float = 0.1):
        """
        Initialize transformer encoder layer.
        
        Args:
            embed_dim (int): Embedding dimension
            num_heads (int): Number of attention heads
            mlp_ratio (int): Ratio for MLP hidden dimension
            qk_dim (int): Dimension of query/key vectors
            dropout (float): Dropout rate
        """
        super().__init__()
        
        # Multi-head attention
        self.attn = MultiHeadAttention(
            embed_dim=embed_dim,
            num_heads=num_heads,
            qk_dim=qk_dim,
            dropout=dropout
        )
        self.norm1 = nn.LayerNorm(embed_dim)
        
        # MLP
        mlp_hidden_dim = int(embed_dim * mlp_ratio)
        self.mlp = nn.Sequential(
            nn.Linear(embed_dim, mlp_hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_hidden_dim, embed_dim),
            nn.Dropout(dropout)
        )
        self.norm2 = nn.LayerNorm(embed_dim)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for transformer encoder layer.
        
        Args:
            x (torch.Tensor): Input tensor [B, N, D]
            
        Returns:
            torch.Tensor: Transformed features [B, N, D]
        """
        # Multi-head attention with residual
        x = x + self.attn(self.norm1(x))
        
        # MLP with residual
        x = x + self.mlp(self.norm2(x))
        
        return x

class ElectronMicrographEncoder(nn.Module):
    """Main encoder model for electron micrographs."""
    
    def __init__(self,
                 image_size: Tuple[int, int] = (224, 224),
                 patch_size: int = 32,
                 in_channels: int = 1,
                 embed_dim: int = 128,
                 num_layers: int = 12,
                 num_heads: int = 4,
                 mlp_ratio: int = 4,
                 qk_dim: int = 32,
                 dropout: float = 0.1):
        """
        Initialize electron micrograph encoder.
        
        Args:
            image_size (tuple): Input image size (H, W)
            patch_size (int): Size of patches
            in_channels (int): Number of input channels
            embed_dim (int): Embedding dimension
            num_layers (int): Number of transformer layers
            num_heads (int): Number of attention heads
            mlp_ratio (int): Ratio for MLP hidden dimension
            qk_dim (int): Dimension of query/key vectors
            dropout (float): Dropout rate
        """
        super().__init__()
        
        # Patch embedding
        self.patch_embed = PatchEmbedding(
            image_size=image_size,
            patch_size=patch_size,
            in_channels=in_channels,
            embed_dim=embed_dim
        )
        
        # Add positional embedding
        num_patches = self.patch_embed.n_patches
        self.pos_embed = PositionalEmbedding(
            num_patches=num_patches,
            embed_dim=embed_dim,
            dropout=dropout
        )
        
        # Transformer encoder
        self.encoder = TransformerEncoder(
            embed_dim=embed_dim,
            num_layers=num_layers,
            num_heads=num_heads,
            mlp_ratio=mlp_ratio,
            qk_dim=qk_dim,
            dropout=dropout
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """
        Forward pass for electron micrograph encoder.
        
        Args:
            x (torch.Tensor): Input image [B, C, H, W]
            
        Returns:
            torch.Tensor: Encoded features [B, N+1, D]
        """
        # Convert image to patch embeddings
        x = self.patch_embed(x)
        
        # Add positional embeddings
        x = self.pos_embed(x)
        
        # Transform through encoder layers
        x = self.encoder(x)
        
        return x

    def get_attention_maps(self, x: torch.Tensor) -> List[torch.Tensor]:
        """
        Get attention maps from all layers.
        
        Args:
            x (torch.Tensor): Input image [B, C, H, W]
            
        Returns:
            List[torch.Tensor]: List of attention maps
        """
        # Implement attention visualization logic
        attention_maps = []
        
        # Get patch embeddings
        x = self.patch_embed(x)
        x = self.pos_embed(x)
        
        # Collect attention maps from each layer
        for layer in self.encoder.layers:
            # Forward pass through layer
            attn_output = layer.attn(layer.norm1(x))
            attention_maps.append(attn_output)
            x = x + attn_output
            x = x + layer.mlp(layer.norm2(x))
            
        return attention_maps


class LossFunction(nn.Module):
    """Custom loss function for electron micrograph encoder."""
    
    def __init__(self, temperature: float = 0.07):
        """
        Initialize loss function.
        
        Args:
            temperature (float): Temperature parameter for NT-Xent loss
        """
        super().__init__()
        self.temperature = temperature

    def forward(self, 
                features: torch.Tensor,
                labels: torch.Tensor) -> torch.Tensor:
        """
        Compute NT-Xent contrastive loss.
        
        Args:
            features (torch.Tensor): Encoded features [B, D]
            labels (torch.Tensor): Ground truth labels [B]
            
        Returns:
            torch.Tensor: Loss value
        """
        # Normalize features
        features = F.normalize(features, dim=1)
        
        # Compute similarity matrix
        similarity = torch.matmul(features, features.T) / self.temperature
        
        # Mask for positive pairs
        labels = labels.view(-1, 1)
        mask = torch.eq(labels, labels.T).float()
        mask = mask - torch.eye(mask.shape[0], device=mask.device)
        
        # Compute NT-Xent loss
        exp_sim = torch.exp(similarity)
        log_prob = similarity - torch.log(exp_sim.sum(dim=1, keepdim=True))
        
        mean_log_prob = (mask * log_prob).sum(dim=1) / mask.sum(dim=1)
        loss = -mean_log_prob.mean()
        
        return loss

# model_config.py
class ModelConfig:
    """Configuration for electron micrograph encoder."""
    
    def __init__(self,
                 image_size: Tuple[int, int] = (224, 224),
                 patch_size: int = 32,
                 in_channels: int = 1,
                 embed_dim: int = 128,
                 num_layers: int = 12,
                 num_heads: int = 4,
                 mlp_ratio: int = 4,
                 qk_dim: int = 32,
                 dropout: float = 0.1,
                 learning_rate: float = 1e-4,
                 weight_decay: float = 0.05,
                 batch_size: int = 32,
                 num_epochs: int = 100,
                 temperature: float = 0.07):
        """
        Initialize model configuration.
        
        Args:
            image_size (tuple): Input image dimensions
            patch_size (int): Size of image patches
            in_channels (int): Number of input channels
            embed_dim (int): Embedding dimension
            num_layers (int): Number of transformer layers
            num_heads (int): Number of attention heads
            mlp_ratio (int): MLP hidden dimension ratio
            qk_dim (int): Query/Key dimension
            dropout (float): Dropout rate
            learning_rate (float): Initial learning rate
            weight_decay (float): Weight decay coefficient
            batch_size (int): Training batch size
            num_epochs (int): Number of training epochs
            temperature (float): Temperature for NT-Xent loss
        """
        self.image_size = image_size
        self.patch_size = patch_size
        self.in_channels = in_channels
        self.embed_dim = embed_dim
        self.num_layers = num_layers
        self.num_heads = num_heads
        self.mlp_ratio = mlp_ratio
        self.qk_dim = qk_dim
        self.dropout = dropout
        self.learning_rate = learning_rate
        self.weight_decay = weight_decay
        self.batch_size = batch_size
        self.num_epochs = num_epochs
        self.temperature = temperature

# trainer.py
class ModelTrainer:
    """Trainer for electron micrograph encoder."""
    
    def __init__(self,
                 model: ElectronMicrographEncoder,
                 config: ModelConfig,
                 train_loader: DataLoader,
                 val_loader: Optional[DataLoader] = None,
                 device: str = 'cuda'):
        """
        Initialize model trainer.
        
        Args:
            model (ElectronMicrographEncoder): Model to train
            config (ModelConfig): Model configuration
            train_loader (DataLoader): Training data loader
            val_loader (DataLoader, optional): Validation data loader
            device (str): Device to train on
        """
        self.model = model
        self.config = config
        self.train_loader = train_loader
        self.val_loader = val_loader
        self.device = device
        
        # Move model to device
        self.model = self.model.to(device)
        
        # Setup loss function
        self.criterion = LossFunction(temperature=config.temperature).to(device)
        
        # Setup optimizer with cosine learning rate schedule
        self.optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=config.learning_rate,
            weight_decay=config.weight_decay
        )
        
        self.scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(
            self.optimizer,
            T_max=config.num_epochs
        )

    def train_epoch(self) -> float:
        """
        Train for one epoch.
        
        Returns:
            float: Average loss for the epoch
        """
        self.model.train()
        total_loss = 0
        num_batches = len(self.train_loader)
        
        for batch_idx, (images, labels) in enumerate(self.train_loader):
            # Move batch to device
            images = images.to(self.device)
            labels = labels.to(self.device)
            
            # Forward pass
            features = self.model(images)
            loss = self.criterion(features[:, 0], labels)  # Use CLS token
            
            # Backward pass
            self.optimizer.zero_grad()
            loss.backward()
            self.optimizer.step()
            
            # Update metrics
            total_loss += loss.item()
            
            # Log progress
            if batch_idx % 10 == 0:
                print(f'Batch [{batch_idx}/{num_batches}] Loss: {loss.item():.4f}')
        
        # Update learning rate
        self.scheduler.step()
        
        return total_loss / num_batches

    def validate(self) -> float:
        """
        Validate the model.
        
        Returns:
            float: Average validation loss
        """
        if self.val_loader is None:
            return 0.0
            
        self.model.eval()
        total_loss = 0
        num_batches = len(self.val_loader)
        
        with torch.no_grad():
            for images, labels in self.val_loader:
                # Move batch to device
                images = images.to(self.device)
                labels = labels.to(self.device)
                
                # Forward pass
                features = self.model(images)
                loss = self.criterion(features[:, 0], labels)
                
                total_loss += loss.item()
        
        return total_loss / num_batches

    def train(self, save_dir: Optional[str] = None) -> Dict[str, List[float]]:
        """
        Train the model for specified number of epochs.
        
        Args:
            save_dir (str, optional): Directory to save model checkpoints
            
        Returns:
            Dict[str, List[float]]: Training history
        """
        history = {
            'train_loss': [],
            'val_loss': []
        }
        
        best_val_loss = float('inf')
        
        for epoch in range(self.config.num_epochs):
            print(f'\nEpoch {epoch+1}/{self.config.num_epochs}')
            
            # Train
            train_loss = self.train_epoch()
            history['train_loss'].append(train_loss)
            
            # Validate
            val_loss = self.validate()
            history['val_loss'].append(val_loss)
            
            print(f'Train Loss: {train_loss:.4f}, Val Loss: {val_loss:.4f}')
            
            # Save best model
            if save_dir and val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save_checkpoint(os.path.join(save_dir, 'best_model.pt'))
                
        return history

    def save_checkpoint(self, path: str):
        """Save model checkpoint."""
        torch.save({
            'model_state_dict': self.model.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'scheduler_state_dict': self.scheduler.state_dict(),
            'config': self.config.__dict__
        }, path)

    def load_checkpoint(self, path: str):
        """Load model checkpoint."""
        checkpoint = torch.load(path)
        self.model.load_state_dict(checkpoint['model_state_dict'])
        self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        self.scheduler.load_state_dict(checkpoint['scheduler_state_dict'])
        
# inference.py
class ModelInference:
    """Inference utilities for electron micrograph encoder."""
    
    def __init__(self,
                 model: ElectronMicrographEncoder,
                 device: str = 'cuda'):
        """
        Initialize inference module.
        
        Args:
            model (ElectronMicrographEncoder): Trained model
            device (str): Device to run inference on
        """
        self.model = model.to(device)
        self.device = device
        self.model.eval()

    @torch.no_grad()
    def encode_image(self, image: torch.Tensor) -> torch.Tensor:
        """
        Encode single image.
        
        Args:
            image (torch.Tensor): Input image [1, C, H, W]
            
        Returns:
            torch.Tensor: Encoded features
        """
        image = image.to(self.device)
        features = self.model(image)
        return features[:, 0]  # Return CLS token features

    @torch.no_grad()
    def compute_similarity(self,
                         query_image: torch.Tensor,
                         support_images: torch.Tensor) -> torch.Tensor:
        """
        Compute similarity between query and support images.
        
        Args:
            query_image (torch.Tensor): Query image [1, C, H, W]
            support_images (torch.Tensor): Support images [N, C, H, W]
            
        Returns:
            torch.Tensor: Similarity scores [N]
        """
        # Encode images
        query_features = self.encode_image(query_image)
        support_features = self.encode_image(support_images)
        
        # Normalize features
        query_features = F.normalize(query_features, dim=1)
        support_features = F.normalize(support_features, dim=1)
        
        # Compute cosine similarity
        similarity = torch.matmul(query_features, support_features.T).squeeze()
        
        return similarity

    def get_nearest_neighbors(self,
                            query_image: torch.Tensor,
                            support_images: torch.Tensor,
                            k: int = 5) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Find k-nearest neighbors of query image.
        
        Args:
            query_image (torch.Tensor): Query image [1, C, H, W]
            support_images (torch.Tensor): Support images [N, C, H, W]
            k (int): Number of neighbors to return
            
        Returns:
            Tuple[torch.Tensor, torch.Tensor]: Indices and similarity scores of nearest neighbors
        """
        similarity = self.compute_similarity(query_image, support_images)
        scores, indices = torch.topk(similarity, k=k)
        return indices, scores