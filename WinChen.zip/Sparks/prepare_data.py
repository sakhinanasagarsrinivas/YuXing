# prepare_data.py
import os
import cv2
import numpy as np
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.model_selection import train_test_split

class DataPreprocessor:
    def __init__(self, image_size=(224, 224), seed=42):
        """
        Initialize the data preprocessor.
        
        Args:
            image_size (tuple): Target size for image resizing
            seed (int): Random seed for reproducibility
        """
        self.image_size = image_size
        self.seed = seed
        np.random.seed(seed)
        
    def load_and_preprocess(self, data_dir, dataset_name):
        """
        Load and preprocess all images from the dataset.
        
        Args:
            data_dir (str): Directory containing the dataset
            dataset_name (str): Name of the dataset
            
        Returns:
            dict: Processed data with images and labels
        """
        processed_data = {
            'images': [],
            'labels': [],
            'paths': []
        }
        
        # Load images based on dataset structure
        if dataset_name == 'sem':
            self._load_sem_data(data_dir, processed_data)
        elif dataset_name == 'neu_sdd':
            self._load_neu_sdd_data(data_dir, processed_data)
        elif dataset_name == 'cmi':
            self._load_cmi_data(data_dir, processed_data)
        elif dataset_name == 'kth_tips':
            self._load_kth_tips_data(data_dir, processed_data)
            
        return processed_data
    
    def _load_sem_data(self, data_dir, processed_data):
        """Load SEM dataset images and labels."""
        for class_name in sorted(os.listdir(data_dir)):
            class_dir = os.path.join(data_dir, class_name)
            if not os.path.isdir(class_dir):
                continue
                
            for img_name in os.listdir(class_dir):
                img_path = os.path.join(class_dir, img_name)
                try:
                    img = self._load_and_resize_image(img_path)
                    processed_data['images'].append(img)
                    processed_data['labels'].append(class_name)
                    processed_data['paths'].append(img_path)
                except Exception as e:
                    print(f"Error loading {img_path}: {str(e)}")
                    
    def _load_and_resize_image(self, img_path):
        """Load and resize an image."""
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        img = cv2.resize(img, self.image_size)
        img = self._normalize_image(img)
        return img
    
    def _normalize_image(self, img):
        """Normalize image values."""
        img = img.astype(np.float32)
        img = (img - img.mean()) / (img.std() + 1e-8)
        return img
    
    def split_data(self, data, test_split):
        """
        Split data into train and test sets.
        
        Args:
            data (dict): Dictionary containing images and labels
            test_split (float): Proportion of data for testing
            
        Returns:
            tuple: (train_data, test_data)
        """
        # Convert to numpy arrays
        X = np.array(data['images'])
        y = np.array(data['labels'])
        paths = np.array(data['paths'])
        
        # Find hard-to-classify samples
        hard_samples_idx = self._find_hard_samples(X)
        
        # Create test set from hard samples
        test_size = int(len(X) * test_split)
        test_idx = hard_samples_idx[:test_size]
        train_idx = np.array([i for i in range(len(X)) if i not in test_idx])
        
        # Split the data
        train_data = {
            'images': X[train_idx],
            'labels': y[train_idx],
            'paths': paths[train_idx]
        }
        
        test_data = {
            'images': X[test_idx],
            'labels': y[test_idx],
            'paths': paths[test_idx]
        }
        
        return train_data, test_data
    
    def _find_hard_samples(self, X):
        """
        Find hard-to-classify samples using PCA and K-Means.
        
        Args:
            X (np.ndarray): Array of images
            
        Returns:
            np.ndarray: Indices of hard-to-classify samples
        """
        # Flatten images
        X_flat = X.reshape(X.shape[0], -1)
        
        # Apply PCA
        pca = PCA(n_components=50)
        X_pca = pca.fit_transform(X_flat)
        
        # Apply K-Means
        kmeans = KMeans(n_clusters=10, random_state=self.seed)
        clusters = kmeans.fit_predict(X_pca)
        
        # Calculate distances to cluster centers
        distances = kmeans.transform(X_pca)
        
        # Find samples far from their cluster centers
        hard_samples = []
        for i in range(len(X)):
            cluster_idx = clusters[i]
            dist_to_center = distances[i, cluster_idx]
            hard_samples.append((i, dist_to_center))
        
        # Sort by distance and get indices
        hard_samples.sort(key=lambda x: x[1], reverse=True)
        hard_indices = [x[0] for x in hard_samples]
        
        return np.array(hard_indices)