# main.py
import os
import torch
from typing import Dict, List, Tuple
import logging
from pathlib import Path

from data_module import DataModule
from gpt4v_vqa import GPT4VQAModule
from dalle_generator import DALLEGenerator
from models.micrograph_encoder import ElectronMicrographEncoder
from models.model_config import ModelConfig
from models.trainer import ModelTrainer

class GDLNMIDPipeline:
    """Main pipeline integrating all components of the GDL-NMID framework."""
    
    def __init__(self,
                 data_dir: str,
                 output_dir: str,
                 openai_api_key: str,
                 config: ModelConfig):
        """
        Initialize GDL-NMID pipeline.
        
        Args:
            data_dir (str): Directory containing dataset
            output_dir (str): Directory for outputs
            openai_api_key (str): OpenAI API key
            config (ModelConfig): Model configuration
        """
        self.data_dir = data_dir
        self.output_dir = output_dir
        self.config = config
        
        # Ensure output directory exists
        os.makedirs(output_dir, exist_ok=True)
        
        # Setup logging
        self.setup_logging()
        
        # Initialize components
        self.data_module = DataModule(
            data_dir=data_dir,
            dataset_name="sem",
            batch_size=config.batch_size
        )
        
        self.gpt4v = GPT4VQAModule(api_key=openai_api_key)
        self.dalle = DALLEGenerator(api_key=openai_api_key)
        
        self.model = ElectronMicrographEncoder(
            image_size=config.image_size,
            patch_size=config.patch_size,
            embed_dim=config.embed_dim,
            num_layers=config.num_layers,
            num_heads=config.num_heads,
            mlp_ratio=config.mlp_ratio,
            qk_dim=config.qk_dim,
            dropout=config.dropout
        )

    def setup_logging(self):
        """Setup logging configuration."""
        log_path = os.path.join(self.output_dir, 'pipeline.log')
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_path),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)

    def generate_synthetic_data(self) -> Tuple[List[str], List[str]]:
        """
        Generate synthetic data using GPT-4V and DALL-E 3.
        
        Returns:
            Tuple[List[str], List[str]]: Paths to real and synthetic images
        """
        self.logger.info("Starting synthetic data generation...")
        
        # Setup data module
        self.data_module.setup()
        class_names = self.data_module.get_class_names()
        
        synthetic_images = []
        real_images = []
        
        # Process each class
        for class_name in class_names:
            self.logger.info(f"Processing class: {class_name}")
            
            # Get sample images for the class
            class_samples = self.data_module.get_class_samples(class_name, n=5)
            real_images.extend(class_samples)
            
            for img_path in class_samples:
                # Generate Q&A pairs using GPT-4V
                qa_pairs = self.gpt4v.generate_questions(img_path)
                
                # Generate synthetic images using DALL-E 3
                synthetic_paths = self.dalle.generate_images(
                    qa_pairs,
                    num_images=2,
                    output_dir=os.path.join(self.output_dir, "synthetic", class_name)
                )
                synthetic_images.extend(synthetic_paths)
                
        self.logger.info(f"Generated {len(synthetic_images)} synthetic images")
        return real_images, synthetic_images

    def train(self, synthetic_data: bool = True) -> Dict:
        """
        Train the model.
        
        Args:
            synthetic_data (bool): Whether to use synthetic data augmentation
            
        Returns:
            Dict: Training history
        """
        self.logger.info("Starting model training...")
        
        # Generate synthetic data if requested
        if synthetic_data:
            real_images, synthetic_images = self.generate_synthetic_data()
            # Update data module with synthetic data
            self.data_module.add_synthetic_data(synthetic_images)
        
        # Get dataloaders
        train_loader = self.data_module.train_dataloader()
        test_loader = self.data_module.test_dataloader()
        
        # Create trainer
        trainer = ModelTrainer(
            model=self.model,
            config=self.config,
            train_loader=train_loader,
            val_loader=test_loader
        )
        
        # Train model
        history = trainer.train(
            save_dir=os.path.join(self.output_dir, "checkpoints")
        )
        
        self.logger.info("Training completed")
        return history

    def evaluate(self) -> Dict[str, float]:
        """
        Evaluate the trained model.
        
        Returns:
            Dict[str, float]: Evaluation metrics
        """
        self.logger.info("Starting model evaluation...")
        
        # Load best model
        best_model_path = os.path.join(self.output_dir, "checkpoints", "best_model.pt")
        trainer = ModelTrainer(
            model=self.model,
            config=self.config,
            train_loader=None,
            val_loader=self.data_module.test_dataloader()
        )
        trainer.load_checkpoint(best_model_path)
        
        # Evaluate
        metrics = trainer.evaluate()
        
        self.logger.info(f"Evaluation metrics: {metrics}")
        return metrics

def main():
    # Set configuration
    config = ModelConfig(
        image_size=(224, 224),
        patch_size=32,
        embed_dim=128,
        num_layers=12,
        num_heads=4,
        mlp_ratio=4,
        qk_dim=32,
        dropout=0.1,
        learning_rate=1e-4,
        weight_decay=0.05,
        batch_size=32,
        num_epochs=100
    )
    
    # Initialize pipeline
    pipeline = GDLNMIDPipeline(
        data_dir="path/to/data",
        output_dir="path/to/output",
        openai_api_key="your-api-key",
        config=config
    )
    
    # Run training with synthetic data augmentation
    history = pipeline.train(synthetic_data=True)
    
    # Evaluate model
    metrics = pipeline.evaluate()
    
    # Save results
    results = {
        "history": history,
        "metrics": metrics
    }
    torch.save(results, os.path.join(pipeline.output_dir, "results.pt"))

if __name__ == "__main__":
    main()