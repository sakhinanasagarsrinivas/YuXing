# gpt4v_vqa.py
import os
import requests
import base64
from typing import List, Dict, Any, Optional
import json

class GPT4VQAModule:
    """GPT-4V Visual Question Answering module for nanomaterial analysis."""
    
    def __init__(self, api_key: str, api_base: str = "https://api.openai.com/v1"):
        """
        Initialize GPT-4V VQA module.
        
        Args:
            api_key (str): OpenAI API key
            api_base (str): Base URL for OpenAI API
        """
        self.api_key = api_key
        self.api_base = api_base
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        # Define standard question templates
        self.question_templates = [
            "**Basics** What type of nanomaterial is depicted in the image? What is the scale?",
            "**Morphology and Structure** What is the general shape or morphology? Are there distinct layers or phases?",
            "**Size and Distribution** What is the approximate size range? How are the nanomaterials distributed?",
            "**Surface Characteristics** What is the surface texture like? Are there visible defects?",
            "**Composition and Elements** Are there compositional variations visible? Any specific elements marked?",
            "**Interactions and Boundaries** How do nanostructures interact? Are boundaries clear?",
            "**External Environment** Is there interaction with surroundings? What other structures are visible?",
            "**Image Technique** What imaging technique was used? Any post-processing visible?",
            "**Functional Features** Are there functional features visible? Is it a static representation?",
            "**Context and Application** What is the intended application? Is this experimental or theoretical?"
        ]

    def encode_image(self, image_path: str) -> str:
        """
        Encode image to base64 string.
        
        Args:
            image_path (str): Path to image file
            
        Returns:
            str: Base64 encoded image
        """
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')

    def generate_questions(self, image_path: str) -> Dict[str, str]:
        """
        Generate questions and answers for nanomaterial image using GPT-4V.
        
        Args:
            image_path (str): Path to nanomaterial image
            
        Returns:
            Dict[str, str]: Dictionary of questions and their answers
        """
        # Encode image
        base64_image = self.encode_image(image_path)
        
        # Prepare conversation messages
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "data": base64_image
                        }
                    },
                    {
                        "type": "text",
                        "text": "Please analyze this nanomaterial image by answering the following questions:"
                    }
                ]
            }
        ]
        
        # Add each question template
        for template in self.question_templates:
            messages[0]["content"].append({
                "type": "text",
                "text": template
            })
        
        # Make API request
        response = requests.post(
            f"{self.api_base}/chat/completions",
            headers=self.headers,
            json={
                "model": "gpt-4-vision-preview",
                "messages": messages,
                "max_tokens": 1000
            }
        )
        
        # Process response
        qa_pairs = {}
        if response.status_code == 200:
            response_text = response.json()["choices"][0]["message"]["content"]
            qa_pairs = self._parse_response(response_text)
            
        return qa_pairs

    def _parse_response(self, response_text: str) -> Dict[str, str]:
        """Parse GPT-4V response into Q&A pairs."""
        qa_pairs = {}
        current_question = None
        
        for line in response_text.split('\n'):
            if line.startswith('**'):
                current_question = line
                qa_pairs[current_question] = ""
            elif current_question and line.strip():
                qa_pairs[current_question] += line + " "
                
        return qa_pairs


# dalle_generator.py
class DALLEGenerator:
    """DALL-E 3 image generation module for nanomaterials."""
    
    def __init__(self, api_key: str, api_base: str = "https://api.openai.com/v1"):
        """
        Initialize DALL-E generator.
        
        Args:
            api_key (str): OpenAI API key
            api_base (str): Base URL for OpenAI API
        """
        self.api_key = api_key
        self.api_base = api_base
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

    def generate_images(self, 
                       qa_pairs: Dict[str, str], 
                       num_images: int = 1,
                       size: str = "1024x1024") -> List[str]:
        """
        Generate synthetic nanomaterial images from Q&A pairs.
        
        Args:
            qa_pairs (Dict[str, str]): Q&A pairs from GPT-4V analysis
            num_images (int): Number of images to generate
            size (str): Image size ("1024x1024", "512x512", etc.)
            
        Returns:
            List[str]: List of paths to generated images
        """
        # Construct prompt from Q&A pairs
        prompt = self._construct_dalle_prompt(qa_pairs)
        
        # Make API request
        response = requests.post(
            f"{self.api_base}/images/generations",
            headers=self.headers,
            json={
                "model": "dall-e-3",
                "prompt": prompt,
                "n": num_images,
                "size": size
            }
        )
        
        # Save and return image paths
        image_paths = []
        if response.status_code == 200:
            data = response.json()
            for i, image_data in enumerate(data["data"]):
                image_url = image_data["url"]
                image_path = f"generated_image_{i}.png"
                self._download_image(image_url, image_path)
                image_paths.append(image_path)
                
        return image_paths

    def _construct_dalle_prompt(self, qa_pairs: Dict[str, str]) -> str:
        """Construct DALL-E prompt from Q&A pairs."""
        prompt_parts = [
            "Generate a scientifically accurate electron microscope image of a nanomaterial with the following characteristics:",
        ]
        
        # Add relevant details from Q&A pairs
        for question, answer in qa_pairs.items():
            if any(key in question for key in ["Morphology", "Size", "Surface", "Structure"]):
                prompt_parts.append(answer.strip())
                
        return " ".join(prompt_parts)

    def _download_image(self, url: str, save_path: str):
        """Download image from URL and save to path."""
        response = requests.get(url)
        if response.status_code == 200:
            with open(save_path, 'wb') as f:
                f.write(response.content)


# few_shot_classifier.py
import torch
import torch.nn as nn
from typing import List, Tuple, Optional
import numpy as np
from PIL import Image
from torchvision import transforms

class FewShotGPT4VClassifier:
    """Few-shot classifier using GPT-4V for nanomaterial identification."""
    
    def __init__(self, api_key: str, api_base: str = "https://api.openai.com/v1"):
        """
        Initialize few-shot classifier.
        
        Args:
            api_key (str): OpenAI API key
            api_base (str): Base URL for OpenAI API
        """
        self.api_key = api_key
        self.api_base = api_base
        self.headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        # Define image transforms
        self.transform = transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])

    def classify(self, 
                query_image_path: str, 
                support_images: List[Tuple[str, str]], 
                k_shot: int = 5) -> str:
        """
        Classify query image using few-shot learning with GPT-4V.
        
        Args:
            query_image_path (str): Path to query image
            support_images (List[Tuple[str, str]]): List of (image_path, label) pairs
            k_shot (int): Number of support examples per class
            
        Returns:
            str: Predicted class label
        """
        # Encode query image
        query_image = self.encode_image(query_image_path)
        
        # Select k-shot support images
        selected_support = self._select_support_images(support_images, k_shot)
        
        # Construct prompt
        messages = self._construct_few_shot_prompt(query_image, selected_support)
        
        # Make API request
        response = requests.post(
            f"{self.api_base}/chat/completions",
            headers=self.headers,
            json={
                "model": "gpt-4-vision-preview",
                "messages": messages,
                "max_tokens": 100
            }
        )
        
        # Parse response
        if response.status_code == 200:
            prediction = response.json()["choices"][0]["message"]["content"]
            return self._parse_prediction(prediction)
            
        return None

    def _select_support_images(self, 
                             support_images: List[Tuple[str, str]], 
                             k_shot: int) -> List[Tuple[str, str]]:
        """Select support images for few-shot learning."""
        # Group by class
        class_groups = {}
        for img_path, label in support_images:
            if label not in class_groups:
                class_groups[label] = []
            class_groups[label].append(img_path)
        
        # Select k examples per class
        selected = []
        for label, images in class_groups.items():
            selected.extend([(img, label) for img in 
                           np.random.choice(images, min(k_shot, len(images)), 
                                          replace=False)])
            
        return selected

    def _construct_few_shot_prompt(self, 
                                 query_image: str, 
                                 support_images: List[Tuple[str, str]]) -> List[Dict]:
        """Construct few-shot prompt with support images."""
        messages = []
        
        # Add system message
        messages.append({
            "role": "system",
            "content": "You are an expert in nanomaterial analysis. Your task is to classify the query image based on the provided support examples."
        })
        
        # Add support examples
        for img_path, label in support_images:
            support_image = self.encode_image(img_path)
            messages.append({
                "role": "user",
                "content": [
                    {
                        "type": "image",
                        "source": {
                            "type": "base64",
                            "data": support_image
                        }
                    },
                    {
                        "type": "text",
                        "text": f"This is an example of class: {label}"
                    }
                ]
            })
        
        # Add query image
        messages.append({
            "role": "user",
            "content": [
                {
                    "type": "image",
                    "source": {
                        "type": "base64",
                        "data": query_image
                    }
                },
                {
                    "type": "text",
                    "text": "What class does this nanomaterial belong to?"
                }
            ]
        })
        
        return messages

    def encode_image(self, image_path: str) -> str:
        """Encode image to base64 string."""
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')

    def _parse_prediction(self, response_text: str) -> str:
        """Parse GPT-4V response to get predicted class."""
        # Simple parsing - could be made more robust
        response_text = response_text.lower()
        return response_text.split("class:")[-1].strip()


# gdl_nmid.py
class GDLNMID:
    """Main GDL-NMID framework integrating all components."""
    
    def __init__(self, api_key: str):
        """
        Initialize GDL-NMID framework.
        
        Args:
            api_key (str): OpenAI API key
        """
        self.vqa_module = GPT4VQAModule(api_key)
        self.dalle_generator = DALLEGenerator(api_key)
        self.classifier = FewShotGPT4VClassifier(api_key)
        
    def analyze_and_generate(self, 
                           image_path: str, 
                           num_synthetic: int = 1) -> Tuple[Dict[str, str], List[str]]:
        """
        Analyze image and generate synthetic samples.
        
        Args:
            image_path (str): Path to input image
            num_synthetic (int): Number of synthetic images to generate
            
        Returns:
            Tuple[Dict[str, str], List[str]]: Q&A pairs and paths to synthetic images
        """
        # Generate Q&A pairs using GPT-4V
        qa_pairs = self.vqa_module.generate_questions(image_path)
        
        # Generate synthetic images using DALL-E 3
        synthetic_paths = self.dalle_generator.generate_images(
            qa_pairs, 
            num_synthetic
        )
        
        return qa_pairs, synthetic_paths
    
    def classify_image(self, 
                      query_image: str, 
                      support_images: List[Tuple[str, str]], 
                      k_shot: int = 5) -> str:
        """
        Classify query image using few-shot learning.
        
        Args:
            query_image (str): Path to query image
            support_images (List[Tuple[str, str]]): Support image paths and labels
            k_shot (int): Number of support examples per class
            
        Returns:
            str: Predicted class label
        """
        return self.classifier.classify(query_image, support_images, k_shot)