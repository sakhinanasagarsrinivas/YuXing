# data_module.py
import os
import torch
from torch.utils.data import DataLoader
from torchvision import transforms
import numpy as np
from sem_dataset import SEMDataset, NEUSDDDataset, CMIDataset, KTHTipsDataset
from prepare_data import DataPreprocessor

class DataModule:
    def __init__(self, 
                 data_dir: str,
                 dataset_name: str = 'sem',
                 batch_size: int = 32,
                 num_workers: int = 4,
                 image_size: tuple = (224, 224),
                 test_split: float = 0.1,
                 seed: int = 42):
        """
        Initialize the data module for handling various datasets.
        
        Args:
            data_dir (str): Directory containing the dataset
            dataset_name (str): Name of dataset ('sem', 'neu_sdd', 'cmi', 'kth_tips')
            batch_size (int): Batch size for dataloaders
            num_workers (int): Number of workers for dataloaders
            image_size (tuple): Target size for image resizing
            test_split (float): Proportion of data for testing
            seed (int): Random seed for reproducibility
        """
        self.data_dir = data_dir
        self.dataset_name = dataset_name
        self.batch_size = batch_size
        self.num_workers = num_workers
        self.image_size = image_size
        self.test_split = test_split
        self.seed = seed
        
        # Initialize data preprocessor
        self.preprocessor = DataPreprocessor(
            image_size=image_size,
            seed=seed
        )
        
        # Set up transforms
        self.transform = transforms.Compose([
            transforms.Resize(image_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])
        
        self.dataset_classes = {
            'sem': SEMDataset,
            'neu_sdd': NEUSDDDataset,
            'cmi': CMIDataset,
            'kth_tips': KTHTipsDataset
        }

    def setup(self):
        """
        Set up train and test datasets.
        """
        # Get appropriate dataset class
        dataset_class = self.dataset_classes[self.dataset_name]
        
        # Load and preprocess all data
        all_data = self.preprocessor.load_and_preprocess(
            self.data_dir, 
            self.dataset_name
        )
        
        # Split data into train and test
        train_data, test_data = self.preprocessor.split_data(
            all_data, 
            self.test_split
        )
        
        # Create datasets
        self.train_dataset = dataset_class(
            data=train_data,
            transform=self.transform,
            train=True
        )
        
        self.test_dataset = dataset_class(
            data=test_data,
            transform=self.transform,
            train=False
        )
        
    def train_dataloader(self):
        """Create the training dataloader."""
        return DataLoader(
            self.train_dataset,
            batch_size=self.batch_size,
            shuffle=True,
            num_workers=self.num_workers,
            pin_memory=True
        )
    
    def test_dataloader(self):
        """Create the test dataloader."""
        return DataLoader(
            self.test_dataset,
            batch_size=self.batch_size,
            shuffle=False,
            num_workers=self.num_workers,
            pin_memory=True
        )
    
    def get_class_names(self):
        """Get list of class names for the dataset."""
        return self.train_dataset.get_class_names()
    
    def get_num_classes(self):
        """Get number of classes in the dataset."""
        return len(self.get_class_names())






