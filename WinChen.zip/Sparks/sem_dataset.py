import torch
from torch.utils.data import Dataset
import numpy as np

class BaseDataset(Dataset):
    def __init__(self, data, transform=None, train=True):
        """
        Initialize base dataset.
        
        Args:
            data (dict): Dictionary containing images and labels
            transform: Torchvision transforms for data augmentation
            train (bool): Whether this is training data
        """
        self.images = data['images']
        self.labels = data['labels']
        self.paths = data['paths']
        self.transform = transform
        self.train = train
        
        # Create label encoder
        self.class_to_idx = {
            class_name: idx for idx, class_name 
            in enumerate(sorted(set(self.labels)))
        }
        
    def __len__(self):
        return len(self.images)
    
    def __getitem__(self, idx):
        image = self.images[idx]
        label = self.labels[idx]
        
        # Convert image to tensor
        image = torch.from_numpy(image).float()
        
        # Add channel dimension if necessary
        if len(image.shape) == 2:
            image = image.unsqueeze(0)
            
        # Apply transforms if any
        if self.transform is not None:
            image = self.transform(image)
            
        # Convert label to index
        label_idx = self.class_to_idx[label]
        
        return image, label_idx
    
    def get_class_names(self):
        """Get list of class names."""
        return sorted(self.class_to_idx.keys())


class SEMDataset(BaseDataset):
    """Dataset class for SEM nanomaterial images."""
    def __init__(self, data, transform=None, train=True):
        super().__init__(data, transform, train)


class NEUSDDDataset(BaseDataset):
    """Dataset class for NEU-SDD surface defect images."""
    def __init__(self, data, transform=None, train=True):
        super().__init__(data, transform, train)


class CMIDataset(BaseDataset):
    """Dataset class for CMI corrosion images."""
    def __init__(self, data, transform=None, train=True):
        super().__init__(data, transform, train)


class KTHTipsDataset(BaseDataset):
    """Dataset class for KTH-TIPS texture images."""
    def __init__(self, data, transform=None, train=True):
        super().__init__(data, transform, train)