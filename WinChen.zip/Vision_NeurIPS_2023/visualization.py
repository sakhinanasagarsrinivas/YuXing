

import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import torch
from typing import List, Dict
import wandb

class Visualizer:
    def __init__(self, config):
        self.config = config
        
    def plot_confusion_matrix(
        self,
        confusion_matrix: np.ndarray,
        class_names: List[str],
        output_path: str
    ):
        """Plots confusion matrix."""
        plt.figure(figsize=(10, 8))
        sns.heatmap(
            confusion_matrix,
            xticklabels=class_names,
            yticklabels=class_names,
            annot=True,
            fmt='d',
            cmap='Blues'
        )
        plt.title('Confusion Matrix')
        plt.ylabel('True Label')
        plt.xlabel('Predicted Label')
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        
    def plot_learning_curves(
        self,
        train_losses: List[float],
        val_losses: List[float],
        output_path: str
    ):
        """Plots training and validation learning curves."""
        plt.figure(figsize=(10, 6))
        plt.plot(train_losses, label='Train Loss')
        plt.plot(val_losses, label='Validation Loss')
        plt.title('Learning Curves')
        plt.xlabel('Epoch')
        plt.ylabel('Loss')
        plt.legend()
        plt.grid(True)
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()
        
    def plot_attention_maps(
        self,
        attention_weights: torch.Tensor,
        patch_size: int,
        output_path: str
    ):
        """Plots attention maps for visualization."""
        # Reshape attention weights
        attention = attention_weights.cpu().numpy()
        
        # Create grid plot
        n_heads = attention.shape[0]
        fig, axes = plt.subplots(
            2, n_heads//2,
            figsize=(15, 8)
        )
        
        for i, ax in enumerate(axes.flat):
            if i < n_heads:
                im = ax.imshow(attention[i], cmap='viridis')
                ax.set_title(f'Head {i+1}')
            ax.axis('off')
            
        plt.colorbar(im, ax=axes.ravel().tolist())
        plt.tight_layout()
        plt.savefig(output_path)
        plt.close()

class WandBLogger:
    """Weights & Biases logger for experiment tracking."""
    def __init__(self, config):
        self.config = config
        wandb.init(
            project=config.project_name,
            config=config.__dict__
        )
        
    def log_metrics(self, metrics: Dict[str, float], step: int):
        """Logs metrics to W&B."""
        wandb.log(metrics, step=step)
        
    def log_image(self, image: torch.Tensor, caption: str):
        """Logs image to W&B."""
        wandb.log({caption: wandb.Image(image)})
        
    def log_confusion_matrix(
        self,
        confusion_matrix: np.ndarray,
        class_names: List[str]
    ):
        """Logs confusion matrix to W&B."""
        wandb.log({
            "confusion_matrix": wandb.plots.HeatMap(
                class_names,
                class_names,
                confusion_matrix,
                show_text=True
            )
        })
```