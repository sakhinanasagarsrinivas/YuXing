import torch
import torch.nn as nn
from .hnf import HNF
from .language_models import LanguageModelIntegration

class MultiFusionLLM(nn.Module):
    def __init__(self, config):
        super().__init__()
        self.config = config
        
        # Main components
        self.hnf = HNF(config)
        self.language_model = LanguageModelIntegration(config)
        
        # Cross-modal fusion
        self.cross_attention = CrossModalAttention(
            config.hidden_dim,
            config.num_heads
        )
        
        # Output
        self.classifier = nn.Linear(config.hidden_dim, config.num_classes)
        
    def forward(self, image, prompt):
        # Get visual features
        visual_features = self.hnf(image)
        
        # Get language features
        text_features = self.language_model(prompt)
        
        # Cross-modal fusion
        fused = self.cross_attention(
            visual_features[-1][0],  # Use final layer patch sequence
            text_features,
            text_features
        )
        
        return self.classifier(fused)

class CrossModalAttention(nn.Module):
    def __init__(self, dim, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        
        self.q_proj = nn.Linear(dim, dim)
        self.k_proj = nn.Linear(dim, dim)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        
    def forward(self, q, k, v, mask=None):
        batch_size = q.size(0)
        
        # Project and reshape
        q = self.reshape_heads(self.q_proj(q), batch_size)
        k = self.reshape_heads(self.k_proj(k), batch_size)
        v = self.reshape_heads(self.v_proj(v), batch_size)
        
        # Scaled dot-product attention
        attn = torch.matmul(q, k.transpose(-2, -1)) / (self.head_dim ** 0.5)
        if mask is not None:
            attn = attn.masked_fill(mask == 0, -1e9)
        attn = torch.softmax(attn, dim=-1)
        
        # Apply attention to values
        out = torch.matmul(attn, v)
        
        # Reshape and project
        out = self.reshape_sequence(out, batch_size)
        return self.out_proj(out)
        
    def reshape_heads(self, x, batch_size):
        return x.view(batch_size, -1, self.num_heads, self.head_dim).transpose(1, 2)
        
    def reshape_sequence(self, x, batch_size):
        return x.transpose(1, 2).contiguous().view(batch_size, -1, self.num_heads * self.head_dim)