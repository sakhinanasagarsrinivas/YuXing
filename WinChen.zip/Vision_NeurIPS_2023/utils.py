# utils/utils.py

import torch
import yaml
import logging
import os
import random
import numpy as np
from pathlib import Path
from typing import Dict, Any

def set_seed(seed: int):
    """Sets random seed for reproducibility."""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True

def setup_logging(output_dir: str) -> None:
    """Sets up logging configuration."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(output_dir, 'train.log')),
            logging.StreamHandler()
        ]
    )

def load_config(config_path: str) -> Dict[str, Any]:
    """Loads configuration from YAML file."""
    with open(config_path) as f:
        config = yaml.safe_load(f)
    return config

def save_config(config: Dict[str, Any], output_dir: str) -> None:
    """Saves configuration to YAML file."""
    config_path = os.path.join(output_dir, 'config.yaml')
    with open(config_path, 'w') as f:
        yaml.dump(config, f)

class AverageMeter:
    """Computes and stores the average and current value."""
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0
        
    def update(self, val: float, n: int = 1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count

class Timer:
    """Simple timer for tracking runtime."""
    def __init__(self):
        self.reset()
        
    def reset(self):
        self.start_time = None
        self.total_time = 0
        
    def start(self):
        self.start_time = torch.cuda.Event(enable_timing=True)
        self.end_time = torch.cuda.Event(enable_timing=True)
        self.start_time.record()
        
    def stop(self):
        if self.start_time is None:
            return 0
        self.end_time.record()
        torch.cuda.synchronize()
        self.total_time = self.start_time.elapsed_time(self.end_time)
        return self.total_time

def count_parameters(model: torch.nn.Module) -> int:
    """Counts number of trainable parameters in model."""
    return sum(p.numel() for p in model.parameters() if p.requires_grad)


