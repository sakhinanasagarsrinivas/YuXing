import torch
import torch.nn as nn
import torch.nn.functional as F

class GraphChebyshevConv(nn.Module):
    def __init__(self, in_channels, out_channels, K=3):
        super().__init__()
        self.K = K
        self.weights = nn.Parameter(torch.Tensor(K, in_channels, out_channels))
        self.bias = nn.Parameter(torch.Tensor(out_channels))
        self.reset_parameters()
        
    def reset_parameters(self):
        nn.init.kaiming_uniform_(self.weights)
        nn.init.zeros_(self.bias)
        
    def forward(self, x, edge_index, edge_weight=None):
        # Compute normalized Laplacian
        L = self.compute_laplacian(edge_index, edge_weight, x.size(0))
        
        # Chebyshev polynomials
        Tk = [x]  # T_0(L)
        if self.K > 1:
            Tk.append(torch.matmul(L, x))  # T_1(L)
            for k in range(2, self.K):
                # T_k(L) = 2L T_{k-1}(L) - T_{k-2}(L)
                Tk.append(2 * torch.matmul(L, Tk[-1]) - Tk[-2])
                
        # Linear combination
        out = sum(torch.matmul(t, self.weights[i]) for i, t in enumerate(Tk))
        return out + self.bias
        
    def compute_laplacian(self, edge_index, edge_weight, num_nodes):
        # Compute normalized Laplacian matrix
        adj = torch.zeros((num_nodes, num_nodes), device=edge_index.device)
        adj[edge_index[0], edge_index[1]] = 1 if edge_weight is None else edge_weight
        deg = adj.sum(dim=1)
        deg_inv_sqrt = deg.pow(-0.5)
        deg_inv_sqrt[deg_inv_sqrt == float('inf')] = 0
        return torch.eye(num_nodes, device=edge_index.device) - (
            deg_inv_sqrt.unsqueeze(-1) * adj * deg_inv_sqrt.unsqueeze(-2)
        )