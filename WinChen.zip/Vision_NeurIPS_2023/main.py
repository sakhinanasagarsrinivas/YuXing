
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import argparse
import yaml
import logging
from tqdm import tqdm
import os
from datetime import datetime
from models.multifusion import MultiFusionLLM
from data.dataset import SEMDataset
from config.config import Config

def setup_logging(config):
    # Create experiment directory
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    exp_dir = os.path.join(config.output_dir, f'experiment_{timestamp}')
    os.makedirs(exp_dir, exist_ok=True)
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(exp_dir, 'train.log')),
            logging.StreamHandler()
        ]
    )
    return exp_dir

def train_epoch(model, loader, criterion, optimizer, config):
    model.train()
    total_loss = 0
    pbar = tqdm(loader, desc='Training')
    
    for batch_idx, (images, prompts, labels) in enumerate(pbar):
        images = images.to(config.device)
        labels = labels.to(config.device)
        
        # Zero gradients
        optimizer.zero_grad()
        
        # Forward pass
        outputs = model(images, prompts)
        loss = criterion(outputs, labels)
        
        # Backward pass and optimize
        loss.backward()
        if config.grad_clip:
            torch.nn.utils.clip_grad_norm_(model.parameters(), config.grad_clip)
        optimizer.step()
        
        # Update metrics
        total_loss += loss.item()
        pbar.set_postfix({'loss': loss.item()})
        
    return total_loss / len(loader)

def evaluate(model, loader, config):
    model.eval()
    correct = {k: 0 for k in ['top1', 'top2', 'top3', 'top5']}
    total = 0
    total_loss = 0
    criterion = nn.CrossEntropyLoss()
    
    with torch.no_grad():
        for images, prompts, labels in tqdm(loader, desc='Evaluating'):
            images = images.to(config.device)
            labels = labels.to(config.device)
            
            # Forward pass
            outputs = model(images, prompts)
            loss = criterion(outputs, labels)
            total_loss += loss.item()
            
            # Calculate top-k accuracy
            _, predicted = outputs.topk(5, 1, True, True)
            total += labels.size(0)
            
            # Compare predictions with labels
            labels = labels.view(-1, 1).expand_as(predicted)
            correct_mask = predicted.eq(labels)
            
            # Update accuracy metrics
            for k in [1, 2, 3, 5]:
                correct[f'top{k}'] += correct_mask[:, :k].any(1).sum().item()
    
    # Calculate metrics
    metrics = {
        f'top{k}_acc': correct[f'top{k}'] / total 
        for k in [1, 2, 3, 5]
    }
    metrics['val_loss'] = total_loss / len(loader)
    
    return metrics

def save_checkpoint(model, optimizer, epoch, metrics, exp_dir, is_best=False):
    checkpoint = {
        'epoch': epoch,
        'model_state_dict': model.state_dict(),
        'optimizer_state_dict': optimizer.state_dict(),
        'metrics': metrics
    }
    
    # Save latest checkpoint
    torch.save(
        checkpoint,
        os.path.join(exp_dir, 'checkpoint_latest.pth')
    )
    
    # Save best checkpoint
    if is_best:
        torch.save(
            checkpoint,
            os.path.join(exp_dir, 'checkpoint_best.pth')
        )

def main():
    # Parse arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='config.yaml')
    parser.add_argument('--resume', type=str, help='path to checkpoint')
    args = parser.parse_args()
    
    # Load config
    with open(args.config) as f:
        config = Config(**yaml.safe_load(f))
    
    # Setup experiment
    exp_dir = setup_logging(config)
    logging.info(f'Config:\n{yaml.dump(config.__dict__)}')
    
    # Set random seeds
    torch.manual_seed(config.seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(config.seed)
    
    # Initialize model
    model = MultiFusionLLM(config).to(config.device)
    
    # Initialize optimizer and scheduler
    optimizer = optim.Adam(
        model.parameters(),
        lr=config.learning_rate,
        weight_decay=config.weight_decay
    )
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(
        optimizer,
        mode='max',
        factor=0.5,
        patience=5,
        verbose=True
    )
    
    # Initialize criterion
    criterion = nn.CrossEntropyLoss()
    
    # Initialize datasets and dataloaders
    train_dataset = SEMDataset(config.train_dir, split='train')
    val_dataset = SEMDataset(config.val_dir, split='val')
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=config.batch_size,
        shuffle=True,
        num_workers=config.num_workers,
        pin_memory=True
    )
    
    val_loader = DataLoader(
        val_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
        pin_memory=True
    )
    
    # Resume from checkpoint if specified
    start_epoch = 0
    best_acc = 0
    if args.resume:
        logging.info(f'Loading checkpoint from {args.resume}')
        checkpoint = torch.load(args.resume)
        model.load_state_dict(checkpoint['model_state_dict'])
        optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
        start_epoch = checkpoint['epoch']
        best_acc = checkpoint['metrics']['top1_acc']
    
    # Training loop
    logging.info('Starting training')
    for epoch in range(start_epoch, config.num_epochs):
        logging.info(f'\nEpoch {epoch + 1}/{config.num_epochs}')
        
        # Train
        train_loss = train_epoch(model, train_loader, criterion, optimizer, config)
        logging.info(f'Training loss: {train_loss:.4f}')
        
        # Evaluate
        metrics = evaluate(model, val_loader, config)
        logging.info('Validation metrics:')
        for k, v in metrics.items():
            logging.info(f'{k}: {v:.4f}')
        
        # Update scheduler
        scheduler.step(metrics['top1_acc'])
        
        # Save checkpoint
        is_best = metrics['top1_acc'] > best_acc
        if is_best:
            best_acc = metrics['top1_acc']
        save_checkpoint(model, optimizer, epoch, metrics, exp_dir, is_best)
        
        # Early stopping
        if optimizer.param_groups[0]['lr'] < config.min_lr:
            logging.info('Learning rate too small - stopping training')
            break
    
    # Final evaluation on test set
    logging.info('\nEvaluating on test set')
    test_dataset = SEMDataset(config.test_dir, split='test')
    test_loader = DataLoader(
        test_dataset,
        batch_size=config.batch_size,
        shuffle=False,
        num_workers=config.num_workers,
        pin_memory=True
    )
    test_metrics = evaluate(model, test_loader, config)
    logging.info('Test metrics:')
    for k, v in test_metrics.items():
        logging.info(f'{k}: {v:.4f}')

if __name__ == '__main__':
    main()
```