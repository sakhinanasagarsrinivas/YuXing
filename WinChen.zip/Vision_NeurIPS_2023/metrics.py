# utils/metrics.py

import torch
import numpy as np
from sklearn.metrics import precision_recall_fscore_support
from typing import Dict, List, Tuple

class MetricCalculator:
    def __init__(self):
        self.metrics = {
            'acc': Accuracy(),
            'precision': Precision(),
            'recall': Recall(),
            'f1': F1Score(),
            'confusion_matrix': ConfusionMatrix()
        }
        
    def update(self, outputs: torch.Tensor, targets: torch.Tensor):
        """Updates all metrics with batch results."""
        for metric in self.metrics.values():
            metric.update(outputs, targets)
            
    def compute(self) -> Dict[str, float]:
        """Computes all metrics."""
        return {
            name: metric.compute()
            for name, metric in self.metrics.items()
        }
        
    def reset(self):
        """Resets all metrics."""
        for metric in self.metrics.values():
            metric.reset()

class Accuracy:
    def __init__(self):
        self.correct = 0
        self.total = 0
        
    def update(self, outputs: torch.Tensor, targets: torch.Tensor):
        pred = outputs.argmax(dim=1)
        self.correct += (pred == targets).sum().item()
        self.total += targets.size(0)
        
    def compute(self) -> float:
        return self.correct / self.total if self.total > 0 else 0
        
    def reset(self):
        self.correct = 0
        self.total = 0

class TopKAccuracy:
    def __init__(self, k: List[int] = [1, 2, 3, 5]):
        self.k = k
        self.correct = {k: 0 for k in self.k}
        self.total = 0
        
    def update(self, outputs: torch.Tensor, targets: torch.Tensor):
        # Get top-k predictions
        _, pred = outputs.topk(max(self.k), 1, True, True)
        
        # Expand targets for comparison
        targets = targets.view(-1, 1).expand_as(pred)
        
        # Calculate correct predictions for each k
        correct = pred.eq(targets)
        for k in self.k:
            self.correct[k] += correct[:, :k].any(1).sum().item()
        
        self.total += targets.size(0)
        
    def compute(self) -> Dict[int, float]:
        return {
            k: self.correct[k] / self.total if self.total > 0 else 0
            for k in self.k
        }
        
    def reset(self):
        self.correct = {k: 0 for k in self.k}
        self.total = 0

