# data/preprocessing.py

import torch
import numpy as np
import cv2
from PIL import Image
from torchvision import transforms
from torch_geometric.nn import knn_graph

class ImagePreprocessor:
    def __init__(self, config):
        self.config = config
        self.transform = self.get_transforms()
        
    def get_transforms(self):
        return transforms.Compose([
            transforms.Resize((224, 224)),
            transforms.ToTensor(),
            transforms.Normalize(mean=[0.5], std=[0.5])
        ])
        
    def create_patches(self, image, patch_size):
        """Creates non-overlapping patches from image."""
        # Convert to array if PIL Image
        if isinstance(image, Image.Image):
            image = np.array(image)
            
        # Get dimensions
        H, W = image.shape[:2]
        
        # Calculate number of patches
        n_h = H // patch_size
        n_w = W // patch_size
        
        # Create patches
        patches = []
        for i in range(n_h):
            for j in range(n_w):
                patch = image[
                    i*patch_size:(i+1)*patch_size,
                    j*patch_size:(j+1)*patch_size
                ]
                patches.append(patch)
                
        return torch.stack([self.transform(Image.fromarray(p)) for p in patches])
        
    def build_vision_graph(self, patches, k_neighbors):
        """Builds k-nearest neighbor graph from patches."""
        # Flatten patches
        flat_patches = patches.view(patches.size(0), -1)
        
        # Compute KNN graph
        edge_index = knn_graph(
            flat_patches,
            k=k_neighbors,
            loop=True,
            cosine=True
        )
        
        # Compute edge weights
        row, col = edge_index
        edge_weights = torch.cosine_similarity(
            flat_patches[row],
            flat_patches[col]
        )
        
        return edge_index, edge_weights
        
    def process_sem_image(self, image):
        """Complete processing pipeline for SEM images."""
        # Apply image enhancement
        enhanced = self.enhance_sem_image(image)
        
        # Create multi-scale patches
        patch_features = []
        for patch_size in self.config.patch_sizes:
            # Create patches
            patches = self.create_patches(enhanced, patch_size)
            
            # Build graph
            edge_index, edge_weights = self.build_vision_graph(
                patches,
                self.config.k_neighbors
            )
            
            patch_features.append({
                'patches': patches,
                'edge_index': edge_index,
                'edge_weights': edge_weights
            })
            
        return patch_features
        
    def enhance_sem_image(self, image):
        """Applies SEM-specific image enhancement."""
        # Convert to grayscale if needed
        if len(image.shape) == 3:
            image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
        # Apply CLAHE for contrast enhancement
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8,8))
        enhanced = clahe.apply(image)
        
        # Denoise
        enhanced = cv2.fastNlMeansDenoising(enhanced)
        
        return enhanced

