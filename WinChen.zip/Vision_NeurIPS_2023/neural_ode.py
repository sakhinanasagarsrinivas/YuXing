# models/neural_ode.py

import torch
import torch.nn as nn
from torchdiffeq import odeint, odeint_adjoint

class BidirectionalNeuralODE(nn.Module):
    def __init__(self, dim, num_layers=3):
        super().__init__()
        self.forward_ode = ODEFunc(dim, num_layers)
        self.backward_ode = ODEFunc(dim, num_layers)
        self.gating = GatingMechanism(dim)
        
    def forward(self, x, integration_times=torch.linspace(0, 1, 3)):
        # Forward pass
        forward_features = odeint(
            self.forward_ode,
            x,
            integration_times,
            method='dopri5'
        )
        
        # Backward pass
        backward_features = odeint(
            self.backward_ode,
            x,
            torch.flip(integration_times, [0]),
            method='dopri5'
        )
        
        # Combine using gating mechanism
        return self.gating(forward_features[-1], backward_features[-1])

class ODEFunc(nn.Module):
    def __init__(self, dim, num_layers):
        super().__init__()
        self.layers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(dim, dim),
                nn.LayerNorm(dim),
                nn.ReLU(),
            ) for _ in range(num_layers)
        ])
        
    def forward(self, t, x):
        for layer in self.layers:
            x = layer(x)
        return x

class GatingMechanism(nn.Module):
    def __init__(self, dim):
        super().__init__()
        self.gate_net = nn.Sequential(
            nn.Linear(dim * 2, dim),
            nn.Sigmoid()
        )
        
    def forward(self, forward_features, backward_features):
        combined = torch.cat([forward_features, backward_features], dim=-1)
        gate = self.gate_net(combined)
        return gate * forward_features + (1 - gate) * backward_features